#!/usr/bin/env node
'use strict';
/**
 * تجهيز الملفات الثنائية قبل البناء (لا تُحفظ في المستودع، تُولّد عند البناء):
 *   1) نسخ الخطوط العربية من حزم @fontsource إلى مجلد الواجهة
 *   2) توليد أيقونة البرنامج .ico و .png من ملف build/icon.svg
 *
 * التشغيل:  npm run prepare-assets
 */
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');
const FONT_DIR = path.join(ROOT, 'src', 'renderer', 'vendor', 'fonts');
const BUILD_DIR = path.join(ROOT, 'build');

const FONTS = ['cairo', 'tajawal', 'almarai', 'ibm-plex-sans-arabic'];
const WEIGHTS = ['400', '500', '600', '700'];
const SUBSETS = ['arabic', 'latin'];

function copyFonts() {
  fs.mkdirSync(FONT_DIR, { recursive: true });
  let copied = 0, missing = 0;
  FONTS.forEach((fam) => {
    const base = path.join(ROOT, 'node_modules', '@fontsource', fam, 'files');
    if (!fs.existsSync(base)) {
      console.warn(`  ! الحزمة غير مثبّتة: @fontsource/${fam}`);
      return;
    }
    WEIGHTS.forEach((w) => SUBSETS.forEach((s) => {
      const name = `${fam}-${s}-${w}-normal.woff2`;
      const src = path.join(base, name);
      if (fs.existsSync(src)) { fs.copyFileSync(src, path.join(FONT_DIR, name)); copied++; }
      else missing++;
    }));
  });
  console.log(`  ✓ الخطوط: نُسخ ${copied} ملف (${missing} وزن غير متوفر وهذا طبيعي)`);
}

async function buildIcon() {
  const svgPath = path.join(BUILD_DIR, 'icon.svg');
  if (!fs.existsSync(svgPath)) throw new Error('build/icon.svg غير موجود');

  let sharp;
  try { sharp = require('sharp'); }
  catch (_) { console.warn('  ! حزمة sharp غير مثبّتة — تخطّي توليد الأيقونة'); return; }
  const icoMod = require('png-to-ico');
  const pngToIco = typeof icoMod === 'function' ? icoMod : (icoMod.default || icoMod.imagesToIco);

  const svg = fs.readFileSync(svgPath);
  const png512 = await sharp(svg, { density: 384 }).resize(512, 512).png().toBuffer();
  fs.writeFileSync(path.join(BUILD_DIR, 'icon.png'), png512);

  const sizes = [16, 24, 32, 48, 64, 128, 256];
  const buffers = [];
  for (const s of sizes) {
    buffers.push(await sharp(svg, { density: 384 }).resize(s, s).png().toBuffer());
  }
  fs.writeFileSync(path.join(BUILD_DIR, 'icon.ico'), await pngToIco(buffers));
  console.log('  ✓ الأيقونة: build/icon.ico و build/icon.png');
}

function copyVendor() {
  const src = path.join(ROOT, 'node_modules', 'qrcode-generator', 'dist', 'qrcode.js');
  const dest = path.join(ROOT, 'src', 'renderer', 'vendor', 'qrcode.js');
  if (!fs.existsSync(src)) { console.warn('  ! حزمة qrcode-generator غير مثبّتة'); return; }
  fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(src, dest);
  console.log('  ✓ مكتبة رمز QR');
}

(async () => {
  console.log('تجهيز ملفات البناء…');
  copyFonts();
  copyVendor();
  await buildIcon();
  console.log('تم.');
})().catch((e) => { console.error('فشل التجهيز:', e.message); process.exit(1); });
