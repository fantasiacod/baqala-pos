/* سجل الصفحات - تسجّل نفسها فيه عند التحميل */
window.Pages = window.Pages || {};

/* أدوات الواجهة المشتركة */
const UI = (() => {
  /* ------------------------------ DOM ------------------------------ */
  function h(html) {
    const tpl = document.createElement('template');
    tpl.innerHTML = String(html).trim();
    return tpl.content.firstElementChild;
  }
  function frag(html) {
    const tpl = document.createElement('template');
    tpl.innerHTML = String(html).trim();
    return tpl.content;
  }
  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

  function esc(s) {
    return String(s === null || s === undefined ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  /* --------------------------- التنسيق --------------------------- */
  let CURRENCY = '\u20C0';   // رمز الريال السعودي الجديد
  let DECIMALS = 2;
  function setCurrency(c, d) { CURRENCY = c || '\u20C0'; DECIMALS = d === undefined ? 2 : Number(d); }

  function money(n, withCurrency = true) {
    const v = Number(n || 0);
    const s = v.toLocaleString('en-US', { minimumFractionDigits: DECIMALS, maximumFractionDigits: DECIMALS });
    return withCurrency ? `${s} ${CURRENCY}` : s;
  }
  function moneyHTML(n, withCurrency = true) {
    return `<span class="num">${esc(money(n, false))}</span>${withCurrency ? ' ' + esc(CURRENCY) : ''}`;
  }
  function qty(n) {
    const v = Number(n || 0);
    return Number.isInteger(v) ? String(v) : v.toFixed(3).replace(/0+$/, '').replace(/\.$/, '');
  }
  function pct(n) { return `${Number(n || 0).toFixed(1)}%`; }

  function dateStr(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    if (isNaN(d)) return String(iso);
    const p = (x) => String(x).padStart(2, '0');
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
  }
  function timeStr(iso) {
    if (!iso) return '-';
    const d = new Date(iso);
    if (isNaN(d)) return String(iso);
    let hh = d.getHours();
    const mm = String(d.getMinutes()).padStart(2, '0');
    const ap = I18N.isRTL() ? (hh < 12 ? 'ص' : 'م') : (hh < 12 ? 'AM' : 'PM');
    hh = hh % 12 || 12;
    return `${hh}:${mm} ${ap}`;
  }
  function dateTimeStr(iso) { return `${dateStr(iso)} - ${timeStr(iso)}`; }

  function todayStr(offsetDays = 0) {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    const p = (x) => String(x).padStart(2, '0');
    return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
  }
  function monthStart() { return todayStr().substring(0, 8) + '01'; }
  function yearStart() { return todayStr().substring(0, 4) + '-01-01'; }

  const DAY_NAMES_AR = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const DAY_NAMES_EN = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  function dayName(dateStr) {
    const d = new Date(dateStr + 'T12:00:00');
    return (I18N.isRTL() ? DAY_NAMES_AR : DAY_NAMES_EN)[d.getDay()] || '';
  }

  /* --------------------------- التنبيهات --------------------------- */
  function toast(msg, kind = 'ok', ms = 3200) {
    const icons = { ok: Icons.check, err: Icons.alert, warn: Icons.warning, info: Icons.info };
    const el = h(`<div class="toast ${kind}">${icons[kind] || icons.info}<span>${esc(msg)}</span></div>`);
    $('#toasts').appendChild(el);
    setTimeout(() => {
      el.style.transition = 'opacity .25s, transform .25s';
      el.style.opacity = '0'; el.style.transform = 'translateY(-8px)';
      setTimeout(() => el.remove(), 260);
    }, ms);
    return el;
  }
  const ok = (m) => toast(m, 'ok');
  const err = (m) => toast(m, 'err', 4600);
  const warn = (m) => toast(m, 'warn', 4000);

  /* ---------------------------- النوافذ ---------------------------- */
  function modal({ title, body, footer, width = '', onClose, closeOnBackdrop = true }) {
    const back = h(`<div class="modal-backdrop"></div>`);
    const m = h(`
      <div class="modal ${width}">
        <div class="modal-head">
          <h3>${esc(title || '')}</h3>
          <div class="spacer"></div>
          <button class="btn ghost icon sm" data-close title="${esc(t('close'))}">${Icons.x}</button>
        </div>
        <div class="modal-body"></div>
        ${footer !== null ? '<div class="modal-foot"></div>' : ''}
      </div>`);
    const bodyEl = $('.modal-body', m);
    if (typeof body === 'string') bodyEl.innerHTML = body;
    else if (body) bodyEl.appendChild(body);
    const footEl = $('.modal-foot', m);
    if (footEl && footer) {
      if (typeof footer === 'string') footEl.innerHTML = footer;
      else footEl.appendChild(footer);
    }
    back.appendChild(m);
    $('#modals').appendChild(back);

    const close = () => {
      back.remove();
      document.removeEventListener('keydown', onKey);
      if (onClose) onClose();
    };
    const onKey = (e) => { if (e.key === 'Escape') { e.stopPropagation(); close(); } };
    document.addEventListener('keydown', onKey);
    $('[data-close]', m).onclick = close;
    if (closeOnBackdrop) back.onclick = (e) => { if (e.target === back) close(); };

    setTimeout(() => {
      const f = m.querySelector('input:not([type=hidden]),select,textarea');
      if (f) f.focus();
    }, 60);

    return { el: m, body: bodyEl, foot: footEl, close, backdrop: back };
  }

  function confirm({ title, message, confirmText, cancelText, danger = true, input }) {
    return new Promise((resolve) => {
      const inputHTML = input
        ? `<div class="field mt12"><label>${esc(input.label || '')}</label>
             <input class="input" id="cnf-input" placeholder="${esc(input.placeholder || '')}" value="${esc(input.value || '')}"></div>`
        : '';
      const m = modal({
        title: title || t('confirm'),
        width: 'narrow',
        body: `<div style="font-size:14px;line-height:1.7">${message || ''}</div>${inputHTML}`,
        footer: `
          <button class="btn" data-no>${esc(cancelText || t('cancel'))}</button>
          <button class="btn ${danger ? 'danger' : 'primary'}" data-yes>${esc(confirmText || t('confirm'))}</button>`,
        onClose: () => resolve(null),
      });
      $('[data-no]', m.el).onclick = () => { m.close(); resolve(null); };
      $('[data-yes]', m.el).onclick = () => {
        const val = input ? $('#cnf-input', m.el).value : true;
        m.backdrop.remove();
        resolve(val);
      };
      const inp = $('#cnf-input', m.el);
      if (inp) { inp.focus(); inp.onkeydown = (e) => { if (e.key === 'Enter') $('[data-yes]', m.el).click(); }; }
    });
  }

  function prompt(opts) {
    return confirm({ ...opts, danger: false, input: opts.input || { label: opts.label, placeholder: opts.placeholder, value: opts.value } });
  }

  /* ---------------------------- الجداول ---------------------------- */
  function emptyState(text, icon) {
    return `<div class="empty">${icon || Icons.box}<div class="t">${esc(text || t('no_data'))}</div></div>`;
  }

  function table({ columns, rows, onRowClick, footer, compact, empty }) {
    if (!rows || !rows.length) return h(`<div>${emptyState(empty)}</div>`);
    const thead = columns.map((c) => `<th class="${c.align ? 'ta-' + c.align : ''}" ${c.width ? `style="width:${c.width}"` : ''}>${esc(c.title)}</th>`).join('');
    const tbody = rows.map((r, i) => {
      const tds = columns.map((c) => {
        const v = c.render ? c.render(r, i) : esc(r[c.key] === undefined ? '' : r[c.key]);
        return `<td class="${c.align ? 'ta-' + c.align : ''}">${v}</td>`;
      }).join('');
      return `<tr data-i="${i}" class="${onRowClick ? 'clickable' : ''}">${tds}</tr>`;
    }).join('');
    const tfoot = footer ? `<tfoot><tr>${footer}</tr></tfoot>` : '';
    const wrap = h(`<div class="table-wrap"><table class="tbl ${compact ? 'compact' : ''}">
      <thead><tr>${thead}</tr></thead><tbody>${tbody}</tbody>${tfoot}</table></div>`);
    if (onRowClick) {
      $$('tbody tr', wrap).forEach((tr) => {
        tr.onclick = (e) => {
          if (e.target.closest('button,a,input,select')) return;
          onRowClick(rows[Number(tr.dataset.i)], Number(tr.dataset.i));
        };
      });
    }
    return wrap;
  }

  /* --------------------------- أدوات أخرى --------------------------- */
  function debounce(fn, ms = 260) {
    let tmr;
    return (...a) => { clearTimeout(tmr); tmr = setTimeout(() => fn(...a), ms); };
  }

  function initials(name) {
    const s = String(name || '').trim();
    if (!s) return '؟';
    const parts = s.split(/\s+/);
    return (parts[0][0] + (parts[1] ? parts[1][0] : '')).toUpperCase();
  }

  function colorFor(str) {
    const colors = ['#0f9d58', '#1a73e8', '#ea4335', '#f29900', '#9c27b0', '#00897b', '#5e35b1', '#d81b60'];
    let n = 0;
    String(str || '').split('').forEach((c) => { n = (n + c.charCodeAt(0)) % 997; });
    return colors[n % colors.length];
  }

  function toCSV(rows, headers) {
    if (!rows.length) return '';
    const keys = headers ? headers.map((h) => h.key) : Object.keys(rows[0]);
    const titles = headers ? headers.map((h) => h.title) : keys;
    const esc2 = (v) => {
      const s = v === null || v === undefined ? '' : String(v);
      return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
    };
    return '﻿' + [titles.join(','), ...rows.map((r) => keys.map((k) => esc2(r[k])).join(','))].join('\n');
  }

  function parseCSV(text) {
    const clean = text.replace(/^﻿/, '');
    const rows = [];
    let cur = [], field = '', inQ = false;
    for (let i = 0; i < clean.length; i++) {
      const c = clean[i];
      if (inQ) {
        if (c === '"' && clean[i + 1] === '"') { field += '"'; i++; }
        else if (c === '"') inQ = false;
        else field += c;
      } else if (c === '"') inQ = true;
      else if (c === ',') { cur.push(field); field = ''; }
      else if (c === '\n') { cur.push(field); rows.push(cur); cur = []; field = ''; }
      else if (c !== '\r') field += c;
    }
    if (field || cur.length) { cur.push(field); rows.push(cur); }
    if (!rows.length) return [];
    const head = rows[0].map((x) => x.trim());
    return rows.slice(1).filter((r) => r.some((x) => String(x).trim())).map((r) => {
      const o = {};
      head.forEach((k, i) => { o[k] = (r[i] || '').trim(); });
      return o;
    });
  }

  function dateRangeBar(state, onChange) {
    const bar = h(`
      <div class="row wrap gap10">
        <div class="seg">
          <button data-r="today">${esc(t('today'))}</button>
          <button data-r="yesterday">${esc(t('yesterday'))}</button>
          <button data-r="week">${esc(t('week'))}</button>
          <button data-r="month">${esc(t('month'))}</button>
          <button data-r="year">${esc(t('year'))}</button>
        </div>
        <input type="date" class="input" style="width:150px" id="dr-from" value="${esc(state.from)}">
        <span class="muted small">${esc(t('to'))}</span>
        <input type="date" class="input" style="width:150px" id="dr-to" value="${esc(state.to)}">
      </div>`);

    const setActive = (r) => $$('[data-r]', bar).forEach((b) => b.classList.toggle('active', b.dataset.r === r));
    setActive(state.range || 'today');

    $$('[data-r]', bar).forEach((b) => {
      b.onclick = () => {
        const r = b.dataset.r;
        let from = todayStr(), to = todayStr();
        if (r === 'yesterday') { from = to = todayStr(-1); }
        else if (r === 'week') { from = todayStr(-6); }
        else if (r === 'month') { from = monthStart(); }
        else if (r === 'year') { from = yearStart(); }
        state.from = from; state.to = to; state.range = r;
        $('#dr-from', bar).value = from; $('#dr-to', bar).value = to;
        setActive(r);
        onChange(state);
      };
    });
    $('#dr-from', bar).onchange = (e) => { state.from = e.target.value; state.range = 'custom'; setActive(''); onChange(state); };
    $('#dr-to', bar).onchange = (e) => { state.to = e.target.value; state.range = 'custom'; setActive(''); onChange(state); };
    return bar;
  }

  function barChart(data, { valueKey = 'total', labelKey = 'day', fmt } = {}) {
    const max = Math.max(1, ...data.map((d) => Number(d[valueKey]) || 0));
    const cols = data.map((d) => {
      const v = Number(d[valueKey]) || 0;
      const pctH = Math.max(2, (v / max) * 100);
      const label = labelKey === 'day' ? dayName(d[labelKey]) : d[labelKey];
      return `<div class="bar-col">
          <div class="bar-val">${fmt ? fmt(v) : money(v, false)}</div>
          <div class="bar" style="height:${pctH}%" data-v="${esc(money(v))}"></div>
          <div class="bar-lbl">${esc(label)}</div>
        </div>`;
    }).join('');
    return h(`<div class="bars">${cols}</div>`);
  }

  return {
    h, frag, $, $$, esc, money, moneyHTML, qty, pct, setCurrency,
    dateStr, timeStr, dateTimeStr, todayStr, monthStart, yearStart, dayName,
    toast, ok, err, warn, modal, confirm, prompt, table, emptyState,
    debounce, initials, colorFor, toCSV, parseCSV, dateRangeBar, barChart,
  };
})();
