/* بناء الفاتورة للطباعة (طابعة حرارية 80/58 ملم) + رمز QR للفاتورة الضريبية */
const Receipt = (() => {
  const esc = UI.esc;

  /* الترميز الافتراضي في المكتبة لاتيني، فنحوّله لـ UTF-8 حتى تُرمَّز
     الحروف العربية في رمز التحقق بشكل صحيح (النص اللاتيني ما يتأثر). */
  try {
    if (qrcode.stringToBytesFuncs && qrcode.stringToBytesFuncs['UTF-8']) {
      qrcode.stringToBytes = qrcode.stringToBytesFuncs['UTF-8'];
    }
  } catch (_) { /* نكمل بالافتراضي */ }

  /** توليد رمز QR بصيغة data:image من نص */
  function qrDataURL(text, cell = 3) {
    try {
      const qr = qrcode(0, 'M');
      qr.addData(String(text), 'Byte');
      qr.make();
      return qr.createDataURL(cell, 6);
    } catch (e) {
      console.error('QR failed', e);
      // نص طويل: نحاول بمستوى تصحيح أقل حتى يتسع
      try {
        const qr2 = qrcode(0, 'L');
        qr2.addData(String(text), 'Byte');
        qr2.make();
        return qr2.createDataURL(cell, 6);
      } catch (e2) {
        console.error('QR fallback failed', e2);
        return '';
      }
    }
  }

  function fmt(n, dec = 2) {
    return Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: dec, maximumFractionDigits: dec });
  }

  function dt(iso) {
    const d = new Date(iso || Date.now());
    const p = (x) => String(x).padStart(2, '0');
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  }

  /**
   * @param {object} sale  الفاتورة كما رجعت من النواة (مع items)
   * @param {object} s     الإعدادات
   * @param {string} qrB64 نص QR (Base64 TLV) - اختياري
   */
  function html(sale, s, qrB64, verifyText) {
    const width = String(s.receipt_width || '80') === '58' ? 58 : 80;
    const taxed = Number(sale.tax_enabled) === 1 && Number(sale.tax_amount) > 0;
    const isReturn = sale.type === 'return';
    const showQR = s.receipt_show_qr !== '0' && taxed && qrB64;
    const showVerify = s.receipt_show_verify_qr !== '0' && !!verifyText;
    const currency = s.currency_ar || Riyal.CHAR;

    const rows = (sale.items || []).map((it) => {
      const unitGross = Number(it.qty) ? Number(it.line_total) / Number(it.qty) : Number(it.line_total);
      return `<tr>
        <td class="r-name">${esc(it.name)}${it.barcode ? `<div class="r-bc">${esc(it.barcode)}</div>` : ''}</td>
        <td class="r-c">${esc(UI.qty(it.qty))}</td>
        <td class="r-c">${fmt(unitGross)}</td>
        <td class="r-e">${fmt(it.line_total)}</td>
      </tr>`;
    }).join('');

    const logo = s.receipt_show_logo !== '0' && s.logo
      ? `<img src="${esc(s.logo)}" class="r-logo">` : '';

    return `<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="utf-8">
<style>
  ${Riyal.FONT_CSS}
  @page { size: ${width}mm auto; margin: 0; }
  * { box-sizing: border-box; }
  body {
    font-family: 'SaudiRiyal','Cairo','Tajawal','Segoe UI',Tahoma,sans-serif;
    width: ${width}mm; margin: 0; padding: ${width === 58 ? '3mm 2mm' : '4mm 3mm'};
    color: #000; background: #fff;
    font-size: ${width === 58 ? '10px' : '11.5px'}; line-height: 1.5;
    -webkit-print-color-adjust: exact;
  }
  .c { text-align: center; }
  .b { font-weight: 700; }
  .r-logo { max-width: 42mm; max-height: 20mm; object-fit: contain; margin-bottom: 3px; }
  .store { font-size: ${width === 58 ? '14px' : '17px'}; font-weight: 700; margin: 2px 0; }
  .meta { font-size: ${width === 58 ? '9px' : '10.5px'}; }
  .title {
    font-weight: 700; font-size: ${width === 58 ? '11px' : '13px'};
    border: 1.5px solid #000; border-radius: 4px; padding: 3px 0; margin: 6px 0;
  }
  .sep { border-top: 1px dashed #000; margin: 5px 0; }
  .info { display: flex; justify-content: space-between; font-size: ${width === 58 ? '9px' : '10.5px'}; margin: 1px 0; }
  table { width: 100%; border-collapse: collapse; margin-top: 3px; }
  th { font-size: ${width === 58 ? '9px' : '10px'}; border-bottom: 1px solid #000; padding: 3px 1px; text-align: center; }
  th:first-child { text-align: start; }
  td { padding: 3px 1px; vertical-align: top; font-size: ${width === 58 ? '9.5px' : '11px'}; border-bottom: 1px dotted #bbb; }
  .r-name { text-align: start; }
  .r-bc { font-size: 8px; color: #444; }
  .r-c { text-align: center; white-space: nowrap; }
  .r-e { text-align: end; white-space: nowrap; font-weight: 600; }
  .tot { display: flex; justify-content: space-between; padding: 1.5px 0; font-size: ${width === 58 ? '10px' : '11.5px'}; }
  .tot.g { font-size: ${width === 58 ? '13px' : '15.5px'}; font-weight: 700; border-top: 1.5px solid #000; border-bottom: 1.5px solid #000; padding: 4px 0; margin: 4px 0; }
  .qr { text-align: center; margin: 7px 0 3px; }
  .qr img { width: ${width === 58 ? '28mm' : '34mm'}; height: auto; }
  .qr.vqr img { width: ${width === 58 ? '31mm' : '37mm'}; }
  .qr-cap { font-size: ${width === 58 ? '8px' : '9px'}; line-height: 1.35; margin-top: 1px; }
  .qr-cap.b { font-weight: 700; font-size: ${width === 58 ? '8.5px' : '10px'}; }
  .foot { text-align: center; font-size: ${width === 58 ? '9px' : '10.5px'}; margin-top: 5px; }
  .num { direction: ltr; unicode-bidi: isolate; display: inline-block; }
</style></head><body>
  <div class="c">
    ${logo}
    <div class="store">${esc(s.store_name || 'بقالة')}</div>
    ${s.store_name_en ? `<div class="meta">${esc(s.store_name_en)}</div>` : ''}
    ${s.address ? `<div class="meta">${esc(s.address)}</div>` : ''}
    ${s.phone ? `<div class="meta">هاتف: <span class="num">${esc(s.phone)}</span></div>` : ''}
    ${taxed && s.vat_number ? `<div class="meta b">الرقم الضريبي: <span class="num">${esc(s.vat_number)}</span></div>` : ''}
    ${s.cr_number ? `<div class="meta">س.ت: <span class="num">${esc(s.cr_number)}</span></div>` : ''}
    ${s.tax_register ? `<div class="meta">س.ض: <span class="num">${esc(s.tax_register)}</span></div>` : ''}
  </div>

  <div class="title c">
    ${isReturn ? 'إشعار دائن / إرجاع' : (taxed ? 'فاتورة ضريبية مبسطة' : 'فاتورة مبيعات')}
    ${taxed ? '<div style="font-size:8.5px;font-weight:400">Simplified Tax Invoice</div>' : ''}
  </div>

  <div class="info"><span>رقم الفاتورة</span><span class="b num">${esc(sale.invoice_no)}</span></div>
  <div class="info"><span>التاريخ</span><span class="num">${esc(dt(sale.created_at))}</span></div>
  <div class="info"><span>الكاشير</span><span>${esc(sale.user_name || '-')}</span></div>
  ${sale.customer_name ? `<div class="info"><span>العميل</span><span>${esc(sale.customer_name)}</span></div>` : ''}
  ${sale.customer_vat ? `<div class="info"><span>الرقم الضريبي للعميل</span><span class="num">${esc(sale.customer_vat)}</span></div>` : ''}

  <table>
    <thead><tr><th>الصنف</th><th>الكمية</th><th>السعر</th><th>الإجمالي</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>

  <div class="sep"></div>
  ${taxed
    ? `<div class="tot"><span>الإجمالي قبل الضريبة</span><span class="num">${fmt(sale.subtotal)}</span></div>`
    : `<div class="tot"><span>المجموع</span><span class="num">${fmt(sale.subtotal)}</span></div>`}
  ${Number(sale.discount) > 0 ? `<div class="tot"><span>الخصم</span><span class="num">- ${fmt(sale.discount)}</span></div>` : ''}
  ${taxed ? `<div class="tot"><span>ضريبة القيمة المضافة <span class="num">(${fmt(sale.tax_rate, 0)}%)</span></span><span class="num">${fmt(sale.tax_amount)}</span></div>` : ''}
  <div class="tot g"><span>${isReturn ? 'المبلغ المسترجع' : 'الإجمالي المستحق'}</span><span class="num">${fmt(sale.total)} ${esc(currency)}</span></div>

  ${Number(sale.cash_amount) > 0 ? `<div class="tot"><span>نقداً</span><span class="num">${fmt(sale.cash_amount)}</span></div>` : ''}
  ${Number(sale.card_amount) > 0 ? `<div class="tot"><span>شبكة</span><span class="num">${fmt(sale.card_amount)}</span></div>` : ''}
  ${Number(sale.credit_amount) > 0 ? `<div class="tot b"><span>آجل على الحساب</span><span class="num">${fmt(sale.credit_amount)}</span></div>` : ''}
  ${Number(sale.change_due) > 0 ? `<div class="tot b"><span>الباقي</span><span class="num">${fmt(sale.change_due)}</span></div>` : ''}

  ${showQR ? `<div class="qr">
    <img src="${qrDataURL(qrB64, width === 58 ? 3 : 4)}">
    <div class="qr-cap">هيئة الزكاة والضريبة والجمارك</div>
  </div>` : ''}

  ${showVerify ? `<div class="qr vqr">
    <img src="${qrDataURL(verifyText, width === 58 ? 3 : 4)}">
    <div class="qr-cap b">رمز التحقق من صحة الفاتورة</div>
    <div class="qr-cap">امسح الرمز لعرض بيانات المحل ورقم السجل التجاري</div>
  </div>` : ''}

  <div class="foot">
    <div>عدد الأصناف: <span class="num">${(sale.items || []).length}</span></div>
    ${s.receipt_footer ? `<div style="margin-top:3px">${esc(s.receipt_footer)}</div>` : ''}
  </div>
</body></html>`;
  }

  /** فاتورة A4 للعملاء والشركات */
  function htmlA4(sale, s, qrB64, verifyText) {
    const showVerify = s.receipt_show_verify_qr !== '0' && !!verifyText;
    const taxed = Number(sale.tax_enabled) === 1 && Number(sale.tax_amount) > 0;
    const rows = (sale.items || []).map((it, i) => `
      <tr>
        <td class="c">${i + 1}</td>
        <td>${esc(it.name)}</td>
        <td class="c">${esc(UI.qty(it.qty))}</td>
        <td class="e">${fmt(it.unit_price)}</td>
        <td class="e">${fmt(Number(it.line_total) - Number(it.tax_amount))}</td>
        <td class="e">${fmt(it.tax_amount)}</td>
        <td class="e b">${fmt(it.line_total)}</td>
      </tr>`).join('');

    return `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
      ${Riyal.FONT_CSS}
      @page { size: A4; margin: 14mm; }
      body { font-family: 'SaudiRiyal','Cairo','Tajawal',sans-serif; color:#111; font-size:12px; }
      .head { display:flex; justify-content:space-between; align-items:flex-start; border-bottom:2px solid #111; padding-bottom:10px; }
      .store { font-size:20px; font-weight:700; }
      .muted { color:#555; font-size:11px; }
      h1 { font-size:17px; margin:14px 0 10px; text-align:center; }
      .box { border:1px solid #ccc; border-radius:6px; padding:9px 12px; font-size:11.5px; }
      .grid { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin:10px 0; }
      table { width:100%; border-collapse:collapse; margin-top:10px; }
      th { background:#f0f2f4; border:1px solid #ccc; padding:7px 6px; font-size:11px; }
      td { border:1px solid #ddd; padding:6px; }
      .c { text-align:center } .e { text-align:end } .b { font-weight:700 }
      .totals { width:290px; margin-inline-start:auto; margin-top:12px; }
      .totals div { display:flex; justify-content:space-between; padding:5px 0; border-bottom:1px dashed #ccc; }
      .totals .g { font-size:16px; font-weight:700; border-bottom:none; border-top:2px solid #111; padding-top:8px; }
      .num { direction:ltr; unicode-bidi:isolate; display:inline-block; }
      .foot { margin-top:26px; display:flex; justify-content:space-between; align-items:flex-end; }
    </style></head><body>
      <div class="head">
        <div>
          <div class="store">${esc(s.store_name || 'بقالة')}</div>
          <div class="muted">${esc(s.address || '')}</div>
          <div class="muted">${s.phone ? 'هاتف: ' + esc(s.phone) : ''}</div>
          ${taxed && s.vat_number ? `<div class="muted b">الرقم الضريبي: <span class="num">${esc(s.vat_number)}</span></div>` : ''}
          ${s.cr_number ? `<div class="muted">السجل التجاري: <span class="num">${esc(s.cr_number)}</span></div>` : ''}
          ${s.tax_register ? `<div class="muted">السجل الضريبي: <span class="num">${esc(s.tax_register)}</span></div>` : ''}
        </div>
        ${qrB64 && taxed ? `<img src="${qrDataURL(qrB64, 4)}" style="width:100px">` : ''}
      </div>
      <h1>${taxed ? 'فاتورة ضريبية' : 'فاتورة مبيعات'}${sale.type === 'return' ? ' - إشعار دائن' : ''}</h1>
      <div class="grid">
        <div class="box">
          <div><b>رقم الفاتورة:</b> <span class="num">${esc(sale.invoice_no)}</span></div>
          <div><b>التاريخ:</b> <span class="num">${esc(dt(sale.created_at))}</span></div>
          <div><b>الكاشير:</b> ${esc(sale.user_name || '-')}</div>
        </div>
        <div class="box">
          <div><b>العميل:</b> ${esc(sale.customer_name || 'عميل نقدي')}</div>
          <div><b>الجوال:</b> <span class="num">${esc(sale.customer_phone || '-')}</span></div>
          ${sale.customer_vat ? `<div><b>الرقم الضريبي:</b> <span class="num">${esc(sale.customer_vat)}</span></div>` : ''}
        </div>
      </div>
      <table>
        <thead><tr><th style="width:34px">#</th><th>الصنف</th><th style="width:60px">الكمية</th>
          <th style="width:80px">السعر</th><th style="width:85px">قبل الضريبة</th>
          <th style="width:75px">الضريبة</th><th style="width:90px">الإجمالي</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
      <div class="totals">
        <div><span>الإجمالي قبل الضريبة</span><span class="num">${fmt(sale.subtotal)}</span></div>
        ${Number(sale.discount) > 0 ? `<div><span>الخصم</span><span class="num">- ${fmt(sale.discount)}</span></div>` : ''}
        ${taxed ? `<div><span>ضريبة القيمة المضافة <span class="num">${fmt(sale.tax_rate, 0)}%</span></span><span class="num">${fmt(sale.tax_amount)}</span></div>` : ''}
        <div class="g"><span>الإجمالي</span><span class="num">${fmt(sale.total)} ${esc(s.currency_ar || Riyal.CHAR)}</span></div>
      </div>
      <div class="foot">
        <div class="muted">${esc(s.receipt_footer || '')}</div>
        ${showVerify ? `<div style="text-align:center">
          <img src="${qrDataURL(verifyText, 3)}" style="width:96px">
          <div class="muted" style="font-weight:700;margin-top:2px">رمز التحقق من صحة الفاتورة</div>
          <div class="muted" style="font-size:10px">امسح الرمز لعرض بيانات المحل ورقم السجل التجاري</div>
        </div>` : ''}
        <div class="muted">التوقيع: ________________</div>
      </div>
    </body></html>`;
  }

  /** نص رمز التحقق — يُبنى في النواة لأن التوقيع يحتاج المفتاح السري */
  async function verifyCode(sale, s) {
    if (s && s.receipt_show_verify_qr === '0') return '';
    const r = await API.safe('invoice.verifyCode', {
      invoice_no: sale.invoice_no,
      created_at: sale.created_at,
      total: sale.total,
    }, { silent: true });
    return r ? r.text : '';
  }

  /** طباعة فاتورة: يجلب رمز QR من النواة ثم يطبع */
  async function print(sale, { a4 = false, silent } = {}) {
    const s = API.settings;
    let qr = '';
    if (Number(sale.tax_enabled) === 1 && Number(sale.tax_amount) > 0) {
      const r = await API.safe('invoice.qr', {
        timestamp: sale.created_at, total: sale.total, vat: sale.tax_amount,
      }, { silent: true });
      qr = r ? r.qr : '';
    }
    const verifyText = await verifyCode(sale, s);
    const doc = a4 ? htmlA4(sale, s, qr, verifyText) : html(sale, s, qr, verifyText);
    const res = await window.baqala.print(doc, {
      silent: silent === undefined ? s.print_auto !== '0' : silent,
      width: a4 ? 210 : Number(s.receipt_width || 80),
    });
    if (!res.ok) {
      const msg = (res.error && res.error.ar) || '';
      if (/printer|enumerate|no printers/i.test(msg)) {
        // ما فيه طابعة مركبة - ننبه مرة وحدة بس عشان ما نزعج الكاشير
        if (!window.__noPrinterWarned) {
          window.__noPrinterWarned = true;
          UI.warn('ما لقينا طابعة مركبة على الجهاز. ركّب الطابعة من إعدادات ويندوز، وتقدر تطبع أي فاتورة لاحقاً من شاشة الفواتير.');
        }
      } else {
        UI.err('تعذّرت الطباعة: ' + msg);
      }
    }
    return res;
  }

  async function preview(sale) {
    const s = API.settings;
    let qr = '';
    if (Number(sale.tax_enabled) === 1 && Number(sale.tax_amount) > 0) {
      const r = await API.safe('invoice.qr', { timestamp: sale.created_at, total: sale.total, vat: sale.tax_amount }, { silent: true });
      qr = r ? r.qr : '';
    }
    const verifyText = await verifyCode(sale, s);
    return html(sale, s, qr, verifyText);
  }

  return { html, htmlA4, print, preview, qrDataURL, verifyCode };
})();
