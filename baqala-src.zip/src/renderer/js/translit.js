/* ------------------------------------------------------------------
   الترجمة الفورية بين العربي والإنجليزي لأسماء الأصناف
   تشتغل بدون إنترنت: قاموس مدمج لمفردات البقالات + نقل حروف للكلمات
   غير المعروفة (مثل أسماء العلامات التجارية الجديدة)، مع ترتيب
   الكلمات حسب المتعارف عليه في كل لغة.
------------------------------------------------------------------- */
const Translit = (() => {

  /* ============================ الأصناف ============================ */
  const NOUNS = {
    /* ألبان وبيض */
    'حليب': 'Milk', 'لبن': 'Laban', 'زبادي': 'Yogurt', 'روب': 'Yogurt',
    'جبن': 'Cheese', 'جبنة': 'Cheese', 'لبنة': 'Labneh', 'قشطة': 'Cream',
    'كريمة': 'Cream', 'زبدة': 'Butter', 'سمن': 'Ghee', 'بيض': 'Eggs',
    'مثلثات': 'Triangles', 'موزاريلا': 'Mozzarella', 'شيدر': 'Cheddar',
    /* لحوم وأسماك */
    'دجاج': 'Chicken', 'دجاجة': 'Chicken', 'فروج': 'Chicken', 'لحم': 'Meat',
    'لحمة': 'Meat', 'لحوم': 'Meat', 'سمك': 'Fish', 'أسماك': 'Fish',
    'تونة': 'Tuna', 'سردين': 'Sardines', 'روبيان': 'Shrimp', 'جمبري': 'Shrimp',
    'مرتديلا': 'Mortadella', 'نقانق': 'Sausage', 'سجق': 'Sausage',
    'برجر': 'Burger', 'كباب': 'Kebab', 'كبدة': 'Liver', 'صدور': 'Breast',
    'فخذ': 'Thigh', 'أجنحة': 'Wings', 'شاورما': 'Shawarma', 'ناجتس': 'Nuggets',
    /* حبوب ومعكرونة */
    'أرز': 'Rice', 'رز': 'Rice', 'دقيق': 'Flour', 'طحين': 'Flour',
    'برغل': 'Bulgur', 'جريش': 'Jareesh', 'شعيرية': 'Vermicelli',
    'معكرونة': 'Pasta', 'مكرونة': 'Pasta', 'سباغيتي': 'Spaghetti',
    'نودلز': 'Noodles', 'عدس': 'Lentils', 'حمص': 'Chickpeas',
    'فول': 'Fava Beans', 'فاصوليا': 'Beans', 'لوبيا': 'Cowpeas',
    'نشا': 'Starch', 'سميد': 'Semolina', 'شوفان': 'Oats', 'ذرة': 'Corn',
    'قمح': 'Wheat', 'كورن فليكس': 'Corn Flakes', 'حبوب': 'Cereal',
    'فول سوداني': 'Peanut',
    /* مخبوزات */
    'خبز': 'Bread', 'توست': 'Toast', 'صامولي': 'Samoli', 'تميس': 'Tamees',
    'كعك': 'Cake', 'كيك': 'Cake', 'بسكويت': 'Biscuits', 'معجنات': 'Pastry',
    'فطائر': 'Pies', 'رقاق': 'Filo', 'عجينة': 'Dough', 'خميرة': 'Yeast',
    'كرواسون': 'Croissant', 'دونات': 'Donut', 'بقسماط': 'Rusk',
    'سمبوسة': 'Samosa',
    /* مشروبات */
    'ماء': 'Water', 'مياه': 'Water', 'عصير': 'Juice', 'شراب': 'Drink',
    'شاي': 'Tea', 'قهوة': 'Coffee', 'كابتشينو': 'Cappuccino',
    'مشروب': 'Drink', 'مشروبات': 'Beverages', 'كولا': 'Cola',
    'شعير': 'Malt', 'ينسون': 'Anise', 'كركديه': 'Hibiscus',
    'قرفة': 'Cinnamon', 'زنجبيل': 'Ginger', 'نعناع': 'Mint',
    'طاقة': 'Energy',
    /* زيوت وبهارات وصلصات */
    'زيت': 'Oil', 'زيتون': 'Olive', 'خل': 'Vinegar', 'ملح': 'Salt',
    'فلفل': 'Pepper', 'بهارات': 'Spices', 'توابل': 'Seasoning',
    'كمون': 'Cumin', 'كركم': 'Turmeric', 'هيل': 'Cardamom',
    'زعفران': 'Saffron', 'قرنفل': 'Cloves', 'سمسم': 'Sesame',
    'ثوم': 'Garlic', 'بصل': 'Onion', 'صلصة': 'Sauce', 'كاتشب': 'Ketchup',
    'مايونيز': 'Mayonnaise', 'خردل': 'Mustard', 'طحينة': 'Tahini',
    'معجون': 'Paste', 'طماطم': 'Tomato', 'بندورة': 'Tomato', 'شطة': 'Chili',
    'صويا': 'Soy', 'دبس': 'Molasses', 'مرق': 'Stock', 'مكعبات': 'Cubes',
    'دوار الشمس': 'Sunflower', 'ذرة وعباد الشمس': 'Corn & Sunflower',
    /* حلويات وتسالي */
    'سكر': 'Sugar', 'حلاوة': 'Halawa', 'شوكولاتة': 'Chocolate',
    'شوكولا': 'Chocolate', 'حلويات': 'Sweets', 'حلوى': 'Candy',
    'شيبس': 'Chips', 'مقرمشات': 'Crisps', 'عسل': 'Honey', 'مربى': 'Jam',
    'تمر': 'Dates', 'تمور': 'Dates', 'مكسرات': 'Nuts', 'لوز': 'Almonds',
    'كاجو': 'Cashew', 'فستق': 'Pistachio', 'بندق': 'Hazelnut',
    'بذر': 'Seeds', 'علكة': 'Gum', 'آيس كريم': 'Ice Cream',
    'ايس كريم': 'Ice Cream', 'بوظة': 'Ice Cream', 'مصاص': 'Popsicle',
    'ويفر': 'Wafer', 'كراميل': 'Caramel', 'فانيلا': 'Vanilla',
    /* خضار وفواكه */
    'خضار': 'Vegetables', 'خضروات': 'Vegetables', 'فواكه': 'Fruits',
    'تفاح': 'Apple', 'موز': 'Banana', 'برتقال': 'Orange', 'ليمون': 'Lemon',
    'عنب': 'Grapes', 'بطيخ': 'Watermelon', 'شمام': 'Melon', 'مانجو': 'Mango',
    'فراولة': 'Strawberry', 'رمان': 'Pomegranate', 'كيوي': 'Kiwi',
    'أناناس': 'Pineapple', 'خوخ': 'Peach', 'مشمش': 'Apricot', 'تين': 'Fig',
    'خيار': 'Cucumber', 'جزر': 'Carrot', 'بطاطس': 'Potato', 'بطاطا': 'Potato',
    'باذنجان': 'Eggplant', 'كوسة': 'Zucchini', 'ملفوف': 'Cabbage',
    'خس': 'Lettuce', 'بقدونس': 'Parsley', 'كزبرة': 'Coriander',
    'جرجير': 'Arugula', 'فجل': 'Radish', 'قرع': 'Pumpkin', 'بامية': 'Okra',
    'بازلاء': 'Peas',
    /* منظفات ومنزلية */
    'منظف': 'Cleaner', 'صابون': 'Soap', 'شامبو': 'Shampoo',
    'معجون أسنان': 'Toothpaste', 'فرشاة أسنان': 'Toothbrush',
    'مناديل': 'Tissues', 'منديل': 'Tissue', 'مناديل مبللة': 'Wet Wipes',
    'مناشف': 'Towels', 'أكياس': 'Bags', 'قفازات': 'Gloves',
    'مطهر': 'Disinfectant', 'معطر': 'Freshener', 'مبيض': 'Bleach',
    'غسيل': 'Laundry', 'مسحوق': 'Powder', 'أطباق': 'Dishes',
    'ملابس': 'Clothes', 'فرشاة': 'Brush', 'إسفنج': 'Sponge', 'ورق': 'Paper',
    'ألمنيوم': 'Aluminum', 'قصدير': 'Foil', 'فويل': 'Foil',
    'بلاستيك': 'Plastic', 'كوب': 'Cup', 'أكواب': 'Cups', 'صحن': 'Plate',
    'صحون': 'Plates', 'ملعقة': 'Spoon', 'ملاعق': 'Spoons', 'شوكة': 'Fork',
    'سكين': 'Knife', 'بطارية': 'Battery', 'بطاريات': 'Batteries',
    'ولاعة': 'Lighter', 'شمعة': 'Candle', 'مبيد': 'Insecticide',
    'حشرات': 'Insects', 'مكنسة': 'Broom', 'ممسحة': 'Mop', 'دلو': 'Bucket',
    'فحم': 'Charcoal', 'كبريت': 'Matches', 'بخور': 'Incense', 'عود': 'Oud',
    /* عناية وأطفال */
    'حفاظات': 'Diapers', 'حفائض': 'Diapers', 'رضاعة': 'Feeding Bottle',
    'أطفال': 'Baby', 'حليب أطفال': 'Baby Formula', 'مرطب': 'Moisturizer',
    'عطر': 'Perfume', 'مزيل عرق': 'Deodorant', 'شفرات': 'Razors',
    'حلاقة': 'Shaving', 'مشط': 'Comb', 'قطن': 'Cotton', 'لصقات': 'Plasters',
    'بلسم': 'Conditioner', 'أسنان': 'Teeth',
    /* عامة */
    'نوع': 'Type', 'حجم': 'Size', 'لون': 'Color', 'طعم': 'Flavor',
    'نكهة': 'Flavor', 'عرض': 'Offer', 'هدية': 'Gift', 'منتج': 'Product',
    'صنف': 'Item',
    /* أنواع اللحوم */
    'بقري': 'Beef', 'غنم': 'Lamb', 'ضاني': 'Lamb', 'خروف': 'Lamb',
    'عجل': 'Veal', 'حاشي': 'Camel',
    /* تراكيب شائعة (تُطابق كعبارة كاملة) */
    'لحم بقري': 'Beef', 'لحم غنم': 'Lamb', 'لحم ضاني': 'Lamb',
    'صدور دجاج': 'Chicken Breast', 'أجنحة دجاج': 'Chicken Wings',
    'زيت زيتون': 'Olive Oil', 'زيت ذرة': 'Corn Oil',
    'زيت دوار الشمس': 'Sunflower Oil', 'عصير برتقال': 'Orange Juice',
    'عصير تفاح': 'Apple Juice', 'عصير مانجو': 'Mango Juice',
    'معجون طماطم': 'Tomato Paste', 'صلصة طماطم': 'Tomato Sauce',
    'ورق ألمنيوم': 'Aluminum Foil', 'أكياس قمامة': 'Garbage Bags',
    'مناديل مطبخ': 'Kitchen Towels', 'ورق تواليت': 'Toilet Paper',
    'حليب مكثف': 'Condensed Milk', 'حليب مجفف': 'Powdered Milk',
    'جبنة كريمية': 'Cream Cheese', 'ماء غازي': 'Sparkling Water',
    'سكر ناعم': 'Fine Sugar', 'بيكنج بودر': 'Baking Powder',
  };

  /* ============================ العلامات ============================ */
  const BRANDS = {
    'المراعي': 'Almarai', 'نادك': 'Nadec', 'السعودية': 'Saudia',
    'الصافي': 'Al Safi', 'نستله': 'Nestle', 'أميرة': 'Amira',
    'أبو كاس': 'Abu Kass', 'الشرق': 'Al Sharq', 'اللوزة': 'Al Louza',
    'عافية': 'Afia', 'الأسرة': 'Al Osra', 'فاين': 'Fine',
    'سنبلة': 'Sunbulah', 'لوزين': 'Luzine', 'هرفي': 'Herfy',
    'ديتول': 'Dettol', 'فيري': 'Fairy', 'برسيل': 'Persil', 'تايد': 'Tide',
    'داوني': 'Downy', 'كولجيت': 'Colgate', 'سيجنال': 'Signal',
    'بامبرز': 'Pampers', 'هجيز': 'Huggies', 'نوفا': 'Nova', 'هنا': 'Hana',
    'بيرين': 'Berain', 'الحياة': 'Al Hayat', 'أكوافينا': 'Aquafina',
    'الطائف': 'Taif', 'ليبتون': 'Lipton', 'الوطنية': 'Al Watania',
    'الطازج': 'Al Tazaj', 'نسكافيه': 'Nescafe', 'ماجي': 'Maggi',
    'كنور': 'Knorr', 'هاينز': 'Heinz', 'أوريو': 'Oreo', 'كيت كات': 'Kit Kat',
    'جالكسي': 'Galaxy', 'مارس': 'Mars', 'سنيكرز': 'Snickers', 'ليز': 'Lays',
    'دوريتوس': 'Doritos', 'تانج': 'Tang', 'ريتز': 'Ritz',
    'برينجلز': 'Pringles', 'كلوركس': 'Clorox', 'فينيش': 'Finish',
    'أريال': 'Ariel', 'سانسيلك': 'Sunsilk', 'فازلين': 'Vaseline',
    'نيفيا': 'Nivea', 'جونسون': 'Johnson', 'كوكاكولا': 'Coca-Cola',
    'بيبسي': 'Pepsi', 'سفن أب': '7UP', 'ميرندا': 'Mirinda', 'فانتا': 'Fanta',
    'سبرايت': 'Sprite', 'ريد بول': 'Red Bull', 'اندومي': 'Indomie',
    'بسمتي': 'Basmati', 'مزة': 'Mazza', 'جولد': 'Gold',
  };

  /* ============================== الصفات ============================ */
  const ADJS = {
    'طازج': 'Fresh', 'طازجة': 'Fresh', 'مجمد': 'Frozen', 'مجمدة': 'Frozen',
    'مبشور': 'Grated', 'مطحون': 'Ground', 'مطحونة': 'Ground',
    'محمص': 'Roasted', 'مملح': 'Salted', 'مفروم': 'Minced',
    'حار': 'Spicy', 'حلو': 'Sweet', 'مالح': 'Salty', 'قليل': 'Low',
    'دسم': 'Fat', 'خالي': 'Free', 'كامل': 'Full', 'طويل': 'Long',
    'طويل الأجل': 'Long Life', 'الأجل': 'Life',
    'أبيض': 'White', 'بيضاء': 'White', 'أسمر': 'Brown', 'سمراء': 'Brown',
    'أحمر': 'Red', 'حمراء': 'Red', 'أخضر': 'Green', 'خضراء': 'Green',
    'أسود': 'Black', 'سوداء': 'Black', 'أصفر': 'Yellow', 'صفراء': 'Yellow',
    'صغير': 'Small', 'صغيرة': 'Small', 'كبير': 'Large', 'كبيرة': 'Large',
    'وسط': 'Medium', 'فاخر': 'Premium', 'فاخرة': 'Premium', 'عادي': 'Regular',
    'مقشر': 'Peeled', 'مسلوق': 'Boiled', 'مقلي': 'Fried', 'مجفف': 'Dried',
    'معلب': 'Canned', 'مكرر': 'Refined', 'طبيعي': 'Natural',
    'عضوي': 'Organic', 'مستورد': 'Imported', 'بلدي': 'Local',
    'سادة': 'Plain', 'محشي': 'Stuffed', 'مبرد': 'Chilled', 'دايت': 'Diet',
    'خفيف': 'Light', 'غني': 'Rich', 'مضاعف': 'Double', 'ثلاثي': 'Triple',
    'متعدد': 'Multi', 'مشكل': 'Assorted', 'مشكلة': 'Assorted',
    'جديد': 'New', 'يدوي': 'Manual', 'كهربائي': 'Electric',
    'غازي': 'Sparkling', 'غازية': 'Sparkling', 'إضافي': 'Extra',
    'أصلي': 'Original', 'بارد': 'Cold', 'ساخن': 'Hot',
    'سائل': 'Liquid', 'ناعم': 'Fine', 'خشن': 'Coarse', 'مثلج': 'Iced',
  };

  /* ============================== الوحدات =========================== */
  const UNITS = {
    'كيلو': 'Kg', 'كجم': 'Kg', 'كغم': 'Kg', 'جرام': 'g', 'جم': 'g',
    'غرام': 'g', 'لتر': 'L', 'مل': 'ml', 'حبة': 'Piece', 'حبات': 'Pieces',
    'علبة': 'Pack', 'علب': 'Packs', 'كرتون': 'Carton', 'كرتونة': 'Carton',
    'كيس': 'Bag', 'ربطة': 'Bundle', 'طبق': 'Tray', 'درزن': 'Dozen',
    'عبوة': 'Pack', 'زجاجة': 'Bottle', 'قارورة': 'Bottle', 'صندوق': 'Box',
    'باكيت': 'Packet', 'شريط': 'Strip', 'دبة': 'Jerrycan', 'جالون': 'Gallon',
  };

  /* كلمات وصل تُحذف أو تُترجم كما هي */
  const GLUE = { 'مع': 'with', 'بدون': 'without', 'و': '&' };

  /* مفردات أسماء المحلات والمنشآت (تُستعمل في اسم المحل بالإعدادات) */
  const SHOP = {
    'بقالة': 'Grocery', 'بقاله': 'Grocery', 'بقالتي': 'My Grocery',
    'تموينات': 'Supplies', 'ميني ماركت': 'Mini Market', 'سوبرماركت': 'Supermarket',
    'سوبر ماركت': 'Supermarket', 'هايبر': 'Hyper', 'هايبر ماركت': 'Hypermarket',
    'ماركت': 'Market', 'سوق': 'Market', 'أسواق': 'Markets', 'مركز': 'Center',
    'محل': 'Shop', 'متجر': 'Store', 'دكان': 'Store', 'مخبز': 'Bakery',
    'ملحمة': 'Butchery', 'مطعم': 'Restaurant', 'مقهى': 'Cafe', 'كافيه': 'Cafe',
    'صيدلية': 'Pharmacy', 'مغسلة': 'Laundry', 'ورشة': 'Workshop',
    'مؤسسة': 'Est.', 'شركة': 'Company', 'فرع': 'Branch', 'فروع': 'Branches',
    'للتجارة': 'Trading', 'تجارية': 'Trading', 'التجارية': 'Trading',
    'تجاري': 'Trading', 'التجاري': 'Trading', 'للمواد الغذائية': 'Foodstuff',
    'الغذائية': 'Foodstuff', 'المواد الغذائية': 'Foodstuff',
    'العامة': 'General', 'الحديثة': 'Modern', 'المتحدة': 'United',
  };

  /* ===================== أسماء الأشخاص والعائلات ===================== */
  /* أغلب أسماء المحلات اسم صاحبها، ونقل الحروف وحده ما يضبطها،
     فنعتمد قائمة بالأسماء الشائعة وكتابتها المتعارف عليها. */
  const NAMES = {
    /* تراكيب «عبد…» */
    'عبدالله': 'Abdullah', 'عبدالعزيز': 'Abdulaziz', 'عبدالرحمن': 'Abdulrahman',
    'عبدالمجيد': 'Abdulmajeed', 'عبدالكريم': 'Abdulkarim', 'عبدالرحيم': 'Abdulrahim',
    'عبداللطيف': 'Abdullatif', 'عبدالملك': 'Abdulmalik', 'عبدالوهاب': 'Abdulwahab',
    'عبدالسلام': 'Abdulsalam', 'عبدالرزاق': 'Abdulrazzaq', 'عبدالحميد': 'Abdulhamid',
    'عبدالغني': 'Abdulghani', 'عبدالهادي': 'Abdulhadi', 'عبدالجبار': 'Abduljabbar',
    'عبدالقادر': 'Abdulqader', 'عبدالخالق': 'Abdulkhaliq', 'عبدالناصر': 'Abdulnasser',
    'عبدالمحسن': 'Abdulmohsen', 'عبدالمنعم': 'Abdulmonem', 'عبدالإله': 'Abdulilah',
    'عبدالفتاح': 'Abdulfattah', 'عبدالباري': 'Abdulbari', 'عبدالشكور': 'Abdulshakoor',
    'عبدالصمد': 'Abdulsamad', 'عبدالودود': 'Abdulwadood', 'عبدالنور': 'Abdulnoor',
    'عبدالسميع': 'Abdulsamee', 'عبدالحكيم': 'Abdulhakim', 'عبدالعليم': 'Abdulalim',
    'عبدالقدوس': 'Abdulquddus', 'عبدالرؤوف': 'Abdulraouf', 'عبدالستار': 'Abdulsattar',
    'عبدالمطلب': 'Abdulmuttalib', 'عبدالحق': 'Abdulhaq', 'عبدالواحد': 'Abdulwahid',
    'عبدالغفور': 'Abdulghafoor', 'عبدالعظيم': 'Abdulazim', 'عبدالجليل': 'Abduljalil',
    'عبدالحفيظ': 'Abdulhafeez', 'عبدالصبور': 'Abdulsaboor', 'عبدالمعين': 'Abdulmoeen',
    'عبدالمحيي': 'Abdulmohyi', 'عبدالبديع': 'Abdulbadee', 'عبدالمتين': 'Abdulmateen',
    'عبدالمقصود': 'Abdulmaqsood', 'عبدالتواب': 'Abdultawwab', 'عبدالمعز': 'Abdulmoez',
    'عبدالمولى': 'Abdulmawla', 'عبدالمتعال': 'Abdulmutaal', 'عبدالحي': 'Abdulhay',
    /* كنى وألقاب تُكتب قبل الاسم */
    'أبو': 'Abu', 'أبا': 'Abu', 'أم': 'Um', 'ابن': 'Bin', 'بن': 'Bin',
    'بنت': 'Bint', 'آل': 'Al', 'الشيخ': 'Al-Sheikh',
    /* أسماء رجال */
    'محمد': 'Mohammed', 'أحمد': 'Ahmed', 'علي': 'Ali', 'عمر': 'Omar',
    'خالد': 'Khalid', 'فهد': 'Fahad', 'سعد': 'Saad', 'سعيد': 'Saeed',
    'سلمان': 'Salman', 'سلطان': 'Sultan', 'ناصر': 'Nasser', 'نايف': 'Naif',
    'بندر': 'Bandar', 'تركي': 'Turki', 'فيصل': 'Faisal', 'ماجد': 'Majed',
    'مشعل': 'Mishal', 'متعب': 'Mutaib', 'منصور': 'Mansour', 'مازن': 'Mazen',
    'مهند': 'Muhannad', 'معاذ': 'Muath', 'مصعب': 'Musab', 'ياسر': 'Yasser',
    'يوسف': 'Yousef', 'إبراهيم': 'Ibrahim', 'إسماعيل': 'Ismail', 'يحيى': 'Yahya',
    'موسى': 'Musa', 'عيسى': 'Isa', 'داود': 'Dawood', 'سليمان': 'Sulaiman',
    'صالح': 'Saleh', 'يونس': 'Younis', 'حمد': 'Hamad', 'حامد': 'Hamed',
    'حمزة': 'Hamza', 'حسن': 'Hassan', 'حسين': 'Hussein', 'جعفر': 'Jaafar',
    'عباس': 'Abbas', 'طلال': 'Talal', 'وليد': 'Waleed', 'زياد': 'Ziyad',
    'رائد': 'Raed', 'رامي': 'Rami', 'سامي': 'Sami', 'سامر': 'Samer',
    'طارق': 'Tariq', 'عادل': 'Adel', 'عامر': 'Amer', 'عاصم': 'Asem',
    'عبيد': 'Obaid', 'عثمان': 'Othman', 'عدنان': 'Adnan', 'عزام': 'Azzam',
    'عقيل': 'Aqeel', 'عصام': 'Essam', 'عوض': 'Awad', 'غازي': 'Ghazi',
    'فارس': 'Fares', 'فراس': 'Firas', 'فواز': 'Fawaz', 'قاسم': 'Qasem',
    'مالك': 'Malek', 'محسن': 'Mohsen', 'محمود': 'Mahmoud', 'مروان': 'Marwan',
    'مصطفى': 'Mustafa', 'معتز': 'Moataz', 'مبارك': 'Mubarak', 'مطلق': 'Mutlaq',
    'نبيل': 'Nabil', 'نواف': 'Nawaf', 'هاني': 'Hani', 'هشام': 'Hisham',
    'هيثم': 'Haitham', 'وائل': 'Wael', 'وسام': 'Wesam', 'يزيد': 'Yazid',
    'أنس': 'Anas', 'أسامة': 'Osama', 'أمجد': 'Amjad', 'أيمن': 'Ayman',
    'باسم': 'Basem', 'بدر': 'Badr', 'بشار': 'Bashar', 'ثامر': 'Thamer',
    'جابر': 'Jaber', 'جاسم': 'Jassem', 'جمال': 'Jamal', 'حاتم': 'Hatem',
    'خليل': 'Khalil', 'راشد': 'Rashed', 'رياض': 'Riyad', 'زيد': 'Zaid',
    'سيف': 'Saif', 'شاكر': 'Shaker', 'صابر': 'Saber', 'صقر': 'Saqr',
    'ضاري': 'Dhari', 'طلحة': 'Talha', 'ظافر': 'Dhafer', 'عزيز': 'Aziz',
    'علاء': 'Alaa', 'عمار': 'Ammar', 'عماد': 'Emad', 'فادي': 'Fadi',
    'كمال': 'Kamal', 'ماهر': 'Maher', 'مشاري': 'Mishari', 'مصلح': 'Musleh',
    'منيف': 'Munif', 'نادر': 'Nader', 'نزار': 'Nizar', 'هزاع': 'Hazza',
    'هلال': 'Hilal', 'وضاح': 'Waddah', 'زاهر': 'Zaher', 'شايع': 'Shayea',
    'بسام': 'Bassam', 'أيوب': 'Ayoub', 'زكريا': 'Zakaria', 'هارون': 'Haroun',
    'إسحاق': 'Ishaq', 'إدريس': 'Idris', 'لؤي': 'Louay', 'مراد': 'Murad',
    'نضال': 'Nidal', 'فتحي': 'Fathi', 'مجدي': 'Magdy', 'مختار': 'Mukhtar',
    'معن': 'Maan', 'يعقوب': 'Yaqoub', 'أنور': 'Anwar', 'رشيد': 'Rasheed',
    'سالم': 'Salem', 'شريف': 'Sharif', 'صادق': 'Sadeq', 'لطفي': 'Lutfi',
    'سعود': 'Saud', 'مشهور': 'Mashhour', 'جزاع': 'Jazza', 'دخيل': 'Dakhil',
    'مسفر': 'Musfer', 'مفرح': 'Mufreh', 'معيض': 'Mueed', 'نهار': 'Nahar',
    'سطام': 'Sattam', 'عايض': 'Ayed', 'غرم': 'Gharm', 'فالح': 'Faleh',
    /* أسماء نساء */
    'فاطمة': 'Fatima', 'عائشة': 'Aisha', 'خديجة': 'Khadija', 'مريم': 'Maryam',
    'زينب': 'Zainab', 'سارة': 'Sarah', 'نورة': 'Noura', 'نور': 'Noor',
    'هيا': 'Haya', 'لولوة': 'Lulwah', 'منيرة': 'Munira', 'موضي': 'Moudi',
    'الجوهرة': 'Al-Jawhara', 'هند': 'Hind', 'ريم': 'Reem', 'دانة': 'Dana',
    'جواهر': 'Jawaher', 'أروى': 'Arwa', 'أسماء': 'Asma', 'رغد': 'Raghad',
    'رهف': 'Rahaf', 'غادة': 'Ghada', 'ليلى': 'Layla', 'مها': 'Maha',
    'نجلاء': 'Najla', 'وفاء': 'Wafa', 'هناء': 'Hanaa', 'أمل': 'Amal',
    'إيمان': 'Eman', 'هدى': 'Huda', 'سلمى': 'Salma', 'سميرة': 'Samira',
    'عبير': 'Abeer', 'علياء': 'Alia', 'فاتن': 'Faten', 'لبنى': 'Lubna',
    'نادية': 'Nadia', 'ندى': 'Nada', 'نوال': 'Nawal', 'هالة': 'Hala',
    'يارا': 'Yara', 'جنى': 'Jana', 'لين': 'Leen', 'رزان': 'Razan',
    'دلال': 'Dalal', 'بشاير': 'Bashayer', 'تهاني': 'Tahani', 'حصة': 'Hessa',
    'سعاد': 'Suad', 'شذى': 'Shatha', 'صفية': 'Safiya', 'عهود': 'Ohoud',
    'فرح': 'Farah', 'لطيفة': 'Latifa', 'مشاعل': 'Mashael', 'نوف': 'Nouf',
    /* أسماء عائلات وقبائل */
    'العتيبي': 'Al-Otaibi', 'القحطاني': 'Al-Qahtani', 'الغامدي': 'Al-Ghamdi',
    'الزهراني': 'Al-Zahrani', 'الشهري': 'Al-Shehri', 'الدوسري': 'Al-Dosari',
    'الحربي': 'Al-Harbi', 'المطيري': 'Al-Mutairi', 'الشمري': 'Al-Shammari',
    'العنزي': 'Al-Anazi', 'الجهني': 'Al-Juhani', 'البقمي': 'Al-Baqami',
    'السبيعي': 'Al-Subaie', 'الرشيدي': 'Al-Rashidi', 'العمري': 'Al-Omari',
    'السلمي': 'Al-Salmi', 'المالكي': 'Al-Malki', 'الأحمدي': 'Al-Ahmadi',
    'الثبيتي': 'Al-Thubaiti', 'القرني': 'Al-Qarni', 'الأسمري': 'Al-Asmari',
    'الشمراني': 'Al-Shamrani', 'الخالدي': 'Al-Khalidi', 'الحارثي': 'Al-Harthi',
    'البلوي': 'Al-Balawi', 'العسيري': 'Al-Asiri', 'الصاعدي': 'Al-Saedi',
    'الحازمي': 'Al-Hazmi', 'اليامي': 'Al-Yami', 'الشريف': 'Al-Sharif',
    'الأنصاري': 'Al-Ansari', 'الصبحي': 'Al-Subhi', 'اللهيبي': 'Al-Luhaibi',
  };
  /* ===================== المدن والأحياء الشائعة ===================== */
  const PLACES = {
    'الرياض': 'Riyadh', 'جدة': 'Jeddah', 'مكة': 'Makkah', 'المدينة': 'Madinah',
    'المدينة المنورة': 'Madinah', 'مكة المكرمة': 'Makkah', 'الدمام': 'Dammam',
    'الخبر': 'Khobar', 'الظهران': 'Dhahran', 'أبها': 'Abha', 'تبوك': 'Tabuk',
    'حائل': 'Hail', 'بريدة': 'Buraidah', 'عنيزة': 'Unaizah', 'القصيم': 'Qassim',
    'جازان': 'Jazan', 'جيزان': 'Jazan', 'نجران': 'Najran', 'الباحة': 'Al-Baha',
    'عرعر': 'Arar', 'سكاكا': 'Sakaka', 'ينبع': 'Yanbu', 'الجبيل': 'Jubail',
    'الأحساء': 'Al-Ahsa', 'الهفوف': 'Hofuf', 'القطيف': 'Qatif', 'رابغ': 'Rabigh',
    'بيشة': 'Bisha', 'الخرج': 'Al-Kharj', 'المجمعة': 'Majmaah', 'الزلفي': 'Zulfi',
    'شقراء': 'Shaqra', 'الدوادمي': 'Dawadmi', 'خميس مشيط': 'Khamis Mushait',
    'حفر الباطن': 'Hafar Al-Batin', 'وادي الدواسر': 'Wadi Al-Dawasir',
    'الرس': 'Ar-Rass', 'ضباء': 'Duba', 'أملج': 'Umluj', 'صبيا': 'Sabya',
    'محايل': 'Muhayil', 'النماص': 'Al-Namas', 'القنفذة': 'Al-Qunfudhah',
    'الليث': 'Al-Lith', 'الطائف': 'Taif', 'الأفلاج': 'Al-Aflaj',
    /* أحياء */
    'العليا': 'Al-Olaya', 'الملز': 'Al-Malaz', 'النسيم': 'Al-Naseem',
    'الربوة': 'Al-Rabwah', 'السلام': 'Al-Salam', 'الروضة': 'Al-Rawdah',
    'النرجس': 'Al-Narjis', 'الياسمين': 'Al-Yasmin', 'الملقا': 'Al-Malqa',
    'النخيل': 'Al-Nakheel', 'الشفا': 'Al-Shifa', 'المروج': 'Al-Muruj',
    'الصحافة': 'Al-Sahafah', 'قرطبة': 'Qurtubah', 'الحمراء': 'Al-Hamra',
    'الفيصلية': 'Al-Faisaliyah', 'الشاطئ': 'Al-Shati', 'الصفا': 'Al-Safa',
  };

  /* «عبد الله» مكتوبة بمسافة تُعامل مثل «عبدالله» */
  Object.keys(NAMES).forEach((ar) => {
    if (ar.startsWith('عبدال')) NAMES['عبد ' + ar.slice(3)] = NAMES[ar];
  });

  /* ------------------------- بناء القواميس ------------------------- */
  function normAr(w) {
    return String(w)
      .replace(/[ً-ْٰـ]/g, '')
      .replace(/[أإآٱ]/g, 'ا').replace(/ى/g, 'ي')
      .replace(/ؤ/g, 'و').replace(/ئ/g, 'ي').replace(/ة/g, 'ه')
      .trim();
  }
  function normEn(w) {
    return String(w).toLowerCase().replace(/[^a-z0-9&+]/g, '').trim();
  }

  const AR2EN = {};   // عربي مطبّع → { en, kind }
  const EN2AR = {};   // إنجليزي مطبّع → { ar, kind }

  /* المفتاح يُبنى بنفس طريقة المطابقة: كل كلمة تُطبّع ثم تُوصل بمسافة */
  const keyAr = (s) => String(s).trim().split(/\s+/).map(normAr).filter(Boolean).join(' ');
  const keyEn = (s) => String(s).trim().split(/\s+/).map(normEn).filter(Boolean).join(' ');

  function register(map, kind) {
    Object.keys(map).forEach((ar) => {
      const en = map[ar];
      const kar = keyAr(ar);
      if (kar && !AR2EN[kar]) AR2EN[kar] = { en, kind };
      const ken = keyEn(en);
      if (ken && !EN2AR[ken]) EN2AR[ken] = { ar, kind };
    });
  }
  register(NOUNS, 'noun');
  register(BRANDS, 'brand');
  register(ADJS, 'adj');
  register(UNITS, 'unit');
  register(SHOP, 'noun');
  register(GLUE, 'glue');
  // الأسماء والمدن آخر القائمة: كلمات البقالة لها الأولوية عند التشابه
  register(PLACES, 'name');
  register(NAMES, 'name');

  /* --------------------------- نقل الحروف --------------------------- */
  const AR_LATIN = {
    'ا': 'a', 'ب': 'b', 'ت': 't', 'ث': 'th', 'ج': 'j', 'ح': 'h', 'خ': 'kh',
    'د': 'd', 'ذ': 'dh', 'ر': 'r', 'ز': 'z', 'س': 's', 'ش': 'sh', 'ص': 's',
    'ض': 'd', 'ط': 't', 'ظ': 'z', 'ع': 'a', 'غ': 'gh', 'ف': 'f', 'ق': 'q',
    'ك': 'k', 'ل': 'l', 'م': 'm', 'ن': 'n', 'ه': 'h', 'و': 'w', 'ي': 'y',
    'ء': '', 'پ': 'p', 'چ': 'ch', 'ڤ': 'v', 'گ': 'g',
  };
  const LATIN_AR = {
    'a': 'ا', 'b': 'ب', 'c': 'ك', 'd': 'د', 'e': 'ي', 'f': 'ف', 'g': 'ج',
    'h': 'ه', 'i': 'ي', 'j': 'ج', 'k': 'ك', 'l': 'ل', 'm': 'م', 'n': 'ن',
    'o': 'و', 'p': 'ب', 'q': 'ق', 'r': 'ر', 's': 'س', 't': 'ت', 'u': 'و',
    'v': 'ف', 'w': 'و', 'x': 'كس', 'y': 'ي', 'z': 'ز',
  };
  const PAIRS = [['sh', 'ش'], ['ch', 'تش'], ['th', 'ث'], ['kh', 'خ'],
    ['gh', 'غ'], ['ph', 'ف'], ['oo', 'و'], ['ee', 'ي'], ['aa', 'ا'], ['ck', 'ك']];

  const isArabic = (s) => /[؀-ۿ]/.test(String(s));
  const isLatin = (s) => /[A-Za-z]/.test(String(s));
  const hasDigit = (s) => /[0-9٠-٩]/.test(String(s));
  const titleCase = (s) => String(s).replace(/\b[a-z]/g, (c) => c.toUpperCase());

  /**
   * نقل الكلمة العربية إلى حروف لاتينية بشكل يُقرأ:
   * يفصل "ال" التعريف، ويطوّل حروف المد (و ← oo، ي ← ee)،
   * ويُدخل حركة قصيرة بين السواكن حتى لا تخرج الكلمة متكتّلة.
   * مثال: النخيل ← Al-Nakheel، بقالة ← Baqalah
   */
  /** يحوّل حروف كلمة عربية مطبّعة إلى لاتينية صغيرة (بدون «ال» ولا تاء مربوطة) */
  function latinize(s) {
    const units = [];
    const chars = [...s];
    chars.forEach((ch, i) => {
      const prev = chars[i - 1];
      const next = chars[i + 1];
      if (ch === 'ا') { units.push({ v: 'a', vowel: true }); return; }
      // العين تُكتب حركة لا ساكناً، وإلا صار «سعيد» ← Saaeed
      if (ch === 'ع') { units.push({ v: 'a', vowel: true }); return; }
      // الواو والياء قبل ألف تُنطق حرفاً لا مدّاً: رياض ← Riyad
      if (ch === 'و') {
        if (next === 'ا') units.push({ v: 'w', vowel: false });
        else if (i > 0 && next !== undefined) units.push({ v: 'oo', vowel: true });
        else if (i === chars.length - 1 && i > 0) units.push({ v: 'u', vowel: true });
        else units.push({ v: 'w', vowel: false });
        return;
      }
      if (ch === 'ي') {
        if (next === 'ا') units.push({ v: 'y', vowel: false });
        else if (i > 0 && next !== undefined) units.push({ v: 'ee', vowel: true });
        else if (i === chars.length - 1 && i > 0) units.push({ v: 'i', vowel: true });
        else units.push({ v: 'y', vowel: false });
        return;
      }
      const lat = AR_LATIN[ch];
      if (lat === undefined) { units.push({ v: ch, vowel: false }); return; }
      if (lat === '') return;                       // الهمزة المفردة
      units.push({ v: lat, vowel: false, dup: prev === ch });
    });

    // حركة قصيرة بين ساكنين متتاليين، عدا آخر ساكنين في الكلمة (فهد ← Fahd)
    let out = '';
    units.forEach((u, i) => {
      const nxt = units[i + 1];
      out += u.v;
      const lastPair = i === units.length - 2;
      if (!u.vowel && nxt && !nxt.vowel && !nxt.dup && !lastPair) out += 'a';
    });
    return out;
  }

  function translitAr(w) {
    const s = normAr(w);
    // «عبد الـ…» اسم مركّب: عبدالمجيد ← Abdulmajeed لا Aabadalamajeed
    const abd = s.match(/^عبدال(.{2,})$/);
    if (abd) return titleCase('abdul' + latinize(abd[1]));

    let root = s;
    let prefix = '';
    // أل التعريف تُكتب Al- إذا بقي بعدها جذر معقول
    if (root.length > 3 && root.startsWith('ال')) { prefix = 'Al-'; root = root.slice(2); }

    const endsTaa = /ة\s*$/.test(String(w).replace(/[ً-ْٰـ]/g, ''));
    let out = latinize(root);
    if (endsTaa && /h$/.test(out)) out = out.replace(/a*h$/, 'ah');
    return prefix + titleCase(out);
  }
  function translitEn(w) {
    let s = String(w).toLowerCase();
    PAIRS.forEach(([a, b]) => { s = s.split(a).join('\u0001' + b + '\u0001'); });
    let out = '';
    s.split('\u0001').forEach((chunk) => {
      if (isArabic(chunk)) { out += chunk; return; }
      for (const ch of chunk) {
        if (LATIN_AR[ch] !== undefined) out += LATIN_AR[ch];
        else if (/[0-9]/.test(ch)) out += ch;
      }
    });
    return out;
  }

  /* مطابقة عبارة (حتى ٣ كلمات، الأطول أولاً) */
  function match(tokens, i, dict, norm) {
    for (let len = Math.min(3, tokens.length - i); len >= 1; len--) {
      const key = tokens.slice(i, i + len).map(norm).filter(Boolean).join(' ');
      if (dict[key]) return { hit: dict[key], len };
    }
    return null;
  }

  /** يحوّل النص إلى قائمة أجزاء مصنّفة */
  function parse(text, dir) {
    const tokens = String(text || '').trim().split(/\s+/).filter(Boolean);
    const dict = dir === 'ar2en' ? AR2EN : EN2AR;
    const norm = dir === 'ar2en' ? normAr : normEn;
    const srcTest = dir === 'ar2en' ? isArabic : isLatin;
    const fallback = dir === 'ar2en' ? translitAr : translitEn;
    const parts = [];
    let i = 0;
    while (i < tokens.length) {
      const tk = tokens[i];
      if (hasDigit(tk) || !srcTest(tk)) { parts.push({ v: tk, kind: 'num' }); i++; continue; }
      const m = match(tokens, i, dict, norm);
      if (m) {
        parts.push({ v: dir === 'ar2en' ? m.hit.en : m.hit.ar, kind: m.hit.kind });
        i += m.len;
        continue;
      }
      if (dir === 'ar2en') {
        const bare = normAr(tk).replace(/^ال/, '');
        if (AR2EN[bare]) { parts.push({ v: AR2EN[bare].en, kind: AR2EN[bare].kind }); i++; continue; }
      }
      parts.push({ v: fallback(tk), kind: 'noun' });
      i++;
    }
    return parts;
  }

  /** يحذف التكرار المتجاور (مناديل … منديل) */
  function dedupe(arr) {
    const out = [];
    arr.forEach((v) => {
      const last = out[out.length - 1];
      const a = String(v).toLowerCase();
      const b = String(last || '').toLowerCase();
      if (last && (a === b || a.startsWith(b) || b.startsWith(a))) return;
      out.push(v);
    });
    return out;
  }

  /** ترتيب الكلمات حسب لغة الهدف */
  function arrange(parts, target) {
    const take = (k) => parts.filter((p) => p.kind === k).map((p) => p.v);
    const brands = dedupe(take('brand'));
    const adjs = dedupe(take('adj'));
    // أسماء الأشخاص والمدن تبقى بترتيبها: محمد العتيبي لا العتيبي محمد
    const names = dedupe(take('name'));
    // المضاف والمضاف إليه ينعكسان بين اللغتين: زيت زيتون ↔ Olive Oil
    const nouns = dedupe(take('noun')).reverse();
    const units = parts.filter((p) => p.kind === 'num' || p.kind === 'unit').map((p) => p.v);
    const glue = take('glue');
    // بدون علامة أو صفة أو اسم أو أكثر من اسم عام: نحافظ على الترتيب الأصلي
    if (!brands.length && !adjs.length && !names.length && nouns.length < 2) {
      return dedupe(parts.map((p) => p.v)).join(' ');
    }
    const ordered = target === 'en'
      // Abdulmajeed Grocery · Almarai Long Life Milk 1 L
      ? [...names, ...brands, ...adjs, ...nouns, ...glue, ...units]
      // بقالة عبدالمجيد · حليب المراعي طويل الأجل 1 لتر
      : [...nouns, ...names, ...brands, ...adjs, ...glue, ...units];
    return ordered.filter(Boolean).join(' ');
  }

  /** عربي → إنجليزي */
  function toEnglish(text) {
    if (!String(text || '').trim()) return '';
    return arrange(parse(text, 'ar2en'), 'en').replace(/\s+/g, ' ').trim();
  }

  /** إنجليزي → عربي */
  function toArabic(text) {
    if (!String(text || '').trim()) return '';
    return arrange(parse(text, 'en2ar'), 'ar').replace(/\s+/g, ' ').trim();
  }

  /** يترجم حسب لغة النص المدخل */
  function auto(text) { return isArabic(text) ? toEnglish(text) : toArabic(text); }

  /* --------------------- ربط خانتي الاسم ببعض --------------------- */
  function flash(el) {
    if (!el) return;
    el.style.transition = 'background-color .35s';
    el.style.backgroundColor = 'color-mix(in srgb, var(--accent) 14%, transparent)';
    setTimeout(() => { el.style.backgroundColor = ''; }, 380);
  }

  /**
   * الكتابة في أي خانة تملأ الأخرى فوراً.
   * إذا عدّل المستخدم الخانة الأخرى بنفسه، يتوقف البرنامج عن استبدال ما كتبه.
   */
  function bindPair(arInput, enInput, opts = {}) {
    if (!arInput || !enInput) return;
    // "auto" يعني أن الخانة لم يعدّلها المستخدم بنفسه، فيجوز تعبئتها تلقائياً.
    // ويمكن فرض ذلك من الخارج إذا كانت القيمة الحالية مولّدة أصلاً أو قيمة افتراضية.
    let autoAr = opts.startAutoAr !== undefined ? !!opts.startAutoAr : !String(arInput.value || '').trim();
    let autoEn = opts.startAutoEn !== undefined ? !!opts.startAutoEn : !String(enInput.value || '').trim();

    arInput.addEventListener('input', () => {
      autoAr = false;
      const v = String(arInput.value).trim();
      if (!v) { autoAr = true; if (autoEn) enInput.value = ''; return; }
      if (autoEn) { enInput.value = toEnglish(v); flash(enInput); }
    });

    enInput.addEventListener('input', () => {
      autoEn = false;
      const v = String(enInput.value).trim();
      if (!v) { autoEn = true; if (autoAr) arInput.value = ''; return; }
      if (autoAr) { arInput.value = toArabic(v); flash(arInput); }
    });

    if (opts.regenEn) opts.regenEn.onclick = (e) => {
      e.preventDefault(); autoEn = true;
      enInput.value = toEnglish(arInput.value); flash(enInput);
    };
    if (opts.regenAr) opts.regenAr.onclick = (e) => {
      e.preventDefault(); autoAr = true;
      arInput.value = toArabic(enInput.value); flash(arInput);
    };
  }

  return { toEnglish, toArabic, auto, bindPair, isArabic, normAr, AR2EN, EN2AR };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Translit;
