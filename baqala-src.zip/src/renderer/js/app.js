/* الهيكل العام والتنقل */
const App = (() => {
  const { h, $, $$, esc } = UI;
  let currentRoute = null;
  let alertsCache = { counts: { low: 0, out: 0, expiring: 0, expired: 0 } };

  const ROUTES = {
    pos: { title: () => t('pos'), icon: () => Icons.cart, perm: 'pos', page: () => Pages.pos, group: 'sales', flush: true },
    dashboard: { title: () => t('dashboard'), icon: () => Icons.dashboard, perm: 'dashboard', page: () => Pages.dashboard, group: 'sales' },
    sales: { title: () => t('sales_list'), icon: () => Icons.receipt, perm: 'sales_view', page: () => Pages.sales, group: 'sales' },
    shifts: { title: () => t('shifts'), icon: () => Icons.clock, perm: 'pos', page: () => Pages.shifts, group: 'sales' },

    products: { title: () => t('products'), icon: () => Icons.tag, perm: 'products_view', page: () => Pages.products, group: 'inv' },
    inventory: { title: () => t('inventory'), icon: () => Icons.pkg, perm: 'inventory', page: () => Pages.inventory, group: 'inv' },
    purchases: { title: () => t('purchases'), icon: () => Icons.truck, perm: 'purchases', page: () => Pages.purchases, group: 'inv' },

    customers: { title: () => t('customers'), icon: () => Icons.users, perm: 'customers', page: () => Pages.customers, group: 'acc' },
    suppliers: { title: () => t('suppliers'), icon: () => Icons.store, perm: 'suppliers', page: () => Pages.suppliers, group: 'acc' },
    debts: { title: () => t('debts'), icon: () => Icons.credit, perm: 'debts', page: () => Pages.debts, group: 'acc' },
    expenses: { title: () => t('expenses'), icon: () => Icons.wallet, perm: 'expenses', page: () => Pages.expenses, group: 'acc' },

    reports: { title: () => t('reports'), icon: () => Icons.chart, perm: 'reports', page: () => Pages.reports, group: 'admin' },
    forms: { title: () => t('forms'), icon: () => Icons.doc, perm: null, page: () => Pages.forms, group: 'admin' },
    users: { title: () => t('users'), icon: () => Icons.shield, perm: 'users', page: () => Pages.users, group: 'admin' },
    activity: { title: () => t('activity'), icon: () => Icons.history, perm: 'activity_log', page: () => Pages.activity, group: 'admin' },
    settings: { title: () => t('settings'), icon: () => Icons.settings, perm: 'settings', page: () => Pages.settings, group: 'admin' },
  };

  const GROUPS = [
    { key: 'sales', title: () => t('nav_sales') },
    { key: 'inv', title: () => t('nav_inventory') },
    { key: 'acc', title: () => t('nav_accounts') },
    { key: 'admin', title: () => t('nav_admin') },
  ];

  /* ------------------------------ المظهر ------------------------------ */
  function applyTheme(s) {
    const r = document.documentElement;
    r.setAttribute('data-theme', s.theme === 'dark' ? 'dark' : 'light');
    r.style.setProperty('--accent', s.accent || '#0f9d58');
    r.style.setProperty('--accent-2', s.accent2 || '#1a73e8');
    r.style.setProperty('--radius', (s.radius || 14) + 'px');
    // 'SaudiRiyal' أولاً: خط فيه رمز الريال فقط، وبقية الحروف ترجع لخط البرنامج
    r.style.setProperty('--font', `'SaudiRiyal', '${s.font_family || 'Cairo'}', system-ui, sans-serif`);
    r.style.setProperty('--fs', (15 * (Number(s.font_scale || 100) / 100)).toFixed(1) + 'px');
    r.style.setProperty('--accent-fg', contrastOn(s.accent || '#0f9d58'));
    UI.setCurrency(
      I18N.current() === 'en' ? (s.currency_en || Riyal.CHAR) : (s.currency_ar || Riyal.CHAR),
      Number(s.decimals || 2)
    );
  }

  function contrastOn(hex) {
    try {
      const c = hex.replace('#', '');
      const r = parseInt(c.substring(0, 2), 16), g = parseInt(c.substring(2, 4), 16), b = parseInt(c.substring(4, 6), 16);
      return (r * 299 + g * 587 + b * 114) / 1000 > 165 ? '#10241a' : '#ffffff';
    } catch (_) { return '#ffffff'; }
  }

  /* ------------------------------ الهيكل ------------------------------ */
  function shell() {
    const u = API.user;
    const s = API.settings;
    const navHTML = GROUPS.map((g) => {
      const items = Object.entries(ROUTES).filter(([k, r]) => r.group === g.key && (!r.perm || API.can(r.perm)));
      if (!items.length) return '';
      return `<div class="nav-group-title">${esc(g.title())}</div>` + items.map(([k, r]) =>
        `<button class="nav-item" data-route="${k}">${r.icon()}<span>${esc(r.title())}</span><span class="badge-slot" data-badge="${k}"></span></button>`
      ).join('');
    }).join('');

    const root = h(`
      <div id="root">
        <aside class="sidebar">
          <div class="sidebar-brand">
            <div class="brand-logo">${s.logo ? `<img src="${esc(s.logo)}">` : esc((s.store_name || 'ب').charAt(0))}</div>
            <div class="brand-text">
              <div class="brand-title">${esc(s.store_name || t('app_name'))}</div>
              <div class="brand-sub">${esc(t('app_sub'))}</div>
            </div>
          </div>
          <nav class="nav">${navHTML}</nav>
          <div class="sidebar-foot">
            <button class="user-chip" id="user-menu">
              <div class="avatar" style="background:${esc(u.color || UI.colorFor(u.name))}">${esc(UI.initials(u.name))}</div>
              <div style="min-width:0;flex:1">
                <div class="nm">${esc(u.name)}</div>
                <div class="rl">${esc(roleName(u.role))}</div>
              </div>
              ${Icons.settings}
            </button>
          </div>
        </aside>
        <div class="main">
          <header class="topbar">
            <h1 id="page-title"></h1>
            <div class="spacer"></div>
            <div id="top-extra" class="row gap10"></div>
            <div class="clock" id="clock"></div>
            <button class="btn ghost icon sm" id="theme-toggle" title="${esc(t('theme'))}">${s.theme === 'dark' ? Icons.sun : Icons.moon}</button>
            <button class="btn ghost icon sm" id="lang-toggle" title="${esc(t('language'))}">${Icons.globe}</button>
          </header>
          <main class="view" id="view"></main>
        </div>
      </div>`);

    document.getElementById('root').replaceWith(root);

    $$('[data-route]', root).forEach((b) => { b.onclick = () => go(b.dataset.route); });
    $('#user-menu', root).onclick = userMenu;
    $('#theme-toggle', root).onclick = toggleTheme;
    $('#lang-toggle', root).onclick = toggleLang;

    tickClock();
    setInterval(tickClock, 20000);
    refreshAlerts();
    setInterval(refreshAlerts, 120000);
  }

  function roleName(r) {
    if (I18N.current() === 'en') return { owner: 'Owner', manager: 'Manager', cashier: 'Cashier' }[r] || r;
    return { owner: 'صاحب المحل', manager: 'مدير', cashier: 'كاشير' }[r] || r;
  }

  function tickClock() {
    const el = $('#clock');
    if (!el) return;
    const d = new Date();
    el.textContent = `${UI.dayName(UI.todayStr())} ${UI.dateStr(d.toISOString())} · ${UI.timeStr(d.toISOString())}`;
  }

  async function refreshAlerts() {
    if (!API.user) return;
    const a = await API.safe('products.alerts', {}, { silent: true });
    if (!a) return;
    alertsCache = a;
    const n = a.counts.low + a.counts.out + a.counts.expired + a.counts.expiring;
    const slot = $('[data-badge="inventory"]') || $('[data-badge="products"]');
    if (slot) slot.innerHTML = n ? `<span class="badge ${a.counts.out || a.counts.expired ? 'danger' : 'warn'}">${n}</span>` : '';
  }

  function toggleTheme() {
    const next = API.settings.theme === 'dark' ? 'light' : 'dark';
    API.settings.theme = next;
    applyTheme(API.settings);
    $('#theme-toggle').innerHTML = next === 'dark' ? Icons.sun : Icons.moon;
    API.safe('settings.update', { theme: next }, { silent: true });
  }

  function toggleLang() {
    const next = I18N.current() === 'ar' ? 'en' : 'ar';
    I18N.setLang(next);
    API.settings.lang = next;
    API.safe('settings.update', { lang: next }, { silent: true });
    applyTheme(API.settings);
    shell();
    go(currentRoute || defaultRoute());
  }

  function userMenu() {
    const u = API.user;
    const m = UI.modal({
      title: u.name,
      width: 'narrow',
      body: `
        <div class="row gap10 mb16">
          <div class="avatar" style="width:46px;height:46px;font-size:17px;background:${esc(u.color || UI.colorFor(u.name))}">${esc(UI.initials(u.name))}</div>
          <div>
            <div class="bold">${esc(u.name)}</div>
            <div class="small muted">${esc(u.username)} · ${esc(roleName(u.role))}</div>
          </div>
        </div>
        <button class="btn block mb8" id="um-pass">${Icons.key} ${esc(t('change_password'))}</button>
        <button class="btn block mb8" id="um-shift">${Icons.clock} ${esc(t('shifts'))}</button>
        <button class="btn block danger" id="um-out">${Icons.logout} ${esc(t('logout'))}</button>`,
      footer: null,
    });
    $('#um-pass', m.el).onclick = () => { m.close(); changePassword(); };
    $('#um-shift', m.el).onclick = () => { m.close(); go('shifts'); };
    $('#um-out', m.el).onclick = async () => {
      m.close();
      await API.logout();
      showLogin();
    };
  }

  function changePassword() {
    const m = UI.modal({
      title: t('change_password'),
      width: 'narrow',
      body: `
        <div class="field mb12"><label>${esc(t('old_password'))}</label><input type="password" class="input" id="p-old"></div>
        <div class="field mb12"><label>${esc(t('new_password'))}</label><input type="password" class="input" id="p-new"></div>
        <div class="field"><label>تأكيد كلمة المرور</label><input type="password" class="input" id="p-new2"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('save'))}</button>`,
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const oldP = $('#p-old', m.el).value, n1 = $('#p-new', m.el).value, n2 = $('#p-new2', m.el).value;
      if (n1 !== n2) return UI.err('كلمتا المرور غير متطابقتين');
      const r = await API.safe('users.changeOwnPassword', { oldPassword: oldP, newPassword: n1 });
      if (r) { UI.ok('تم تغيير كلمة المرور'); m.close(); }
    };
  }

  /* ------------------------------ التنقل ------------------------------ */
  function defaultRoute() {
    if (API.can('pos')) return 'pos';
    if (API.can('dashboard')) return 'dashboard';
    const first = Object.keys(ROUTES).find((k) => API.can(ROUTES[k].perm));
    return first || 'pos';
  }

  async function go(route) {
    const r = ROUTES[route];
    if (!r || (r.perm && !API.can(r.perm))) return;
    currentRoute = route;
    $$('[data-route]').forEach((b) => b.classList.toggle('active', b.dataset.route === route));
    $('#page-title').textContent = r.title();
    $('#top-extra').innerHTML = '';
    const view = $('#view');
    view.classList.toggle('flush', !!r.flush);
    view.innerHTML = `<div class="loading-full"><span class="spin"></span></div>`;
    try {
      const page = r.page();
      if (!page) throw new Error('الصفحة غير متوفرة');
      await page.render(view, { topExtra: $('#top-extra') });
    } catch (e) {
      console.error(e);
      view.innerHTML = `<div class="empty"><div class="t">صار خطأ في فتح الصفحة</div><div class="small">${esc(e.message || '')}</div></div>`;
    }
  }

  /* ------------------------------ الإقلاع ----------------------------- */
  async function showLogin() {
    document.getElementById('root').innerHTML = '';
    await Pages.login.render(document.getElementById('root'), { onSuccess: boot });
  }

  async function boot() {
    await API.loadInfo();
    const s = await API.loadSettings();
    if (!s) return showLogin();
    I18N.setLang(s.lang || 'ar');
    applyTheme(s);
    shell();
    await go(defaultRoute());
    bindShortcuts();
    try { await Updater.init(); } catch (e) { console.error('updater ui', e); }
  }

  function bindShortcuts() {
    if (window.__shortcutsBound) return;
    window.__shortcutsBound = true;
    document.addEventListener('keydown', (e) => {
      if (e.key === 'F1' && API.can('pos')) { e.preventDefault(); go('pos'); }
      if (e.key === 'F2' && API.can('dashboard')) { e.preventDefault(); go('dashboard'); }
      if (e.key === 'F3' && API.can('products_view')) { e.preventDefault(); go('products'); }
      if (e.key === 'F4' && API.can('reports')) { e.preventDefault(); go('reports'); }
    });
  }

  async function start() {
    // وضع العميل يحتاج إعداد عنوان السيرفر قبل الدخول
    await API.loadInfo();
    if (API.token) {
      const s = await API.safe('settings.get', {}, { silent: true });
      if (s) { API.settings = s; return boot(); }
      API.setSession('', null);
    }
    const s = API.settings || {};
    I18N.setLang(s.lang || 'ar');
    applyTheme({ accent: '#0f9d58', accent2: '#1a73e8', font_family: 'Cairo', radius: 14, font_scale: 100, theme: 'light' });
    showLogin();
  }

  return { start, boot, go, showLogin, applyTheme, roleName, refreshAlerts, get alerts() { return alertsCache; }, ROUTES };
})();

document.addEventListener('DOMContentLoaded', () => {
  try { Riyal.inject(document); } catch (e) { console.error('riyal font', e); }
  App.start();
});
