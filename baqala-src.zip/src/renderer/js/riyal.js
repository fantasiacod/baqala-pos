/* رمز الريال السعودي الجديد.
   خط مدمج صغير (~1 كيلوبايت) فيه رمز واحد فقط، فتُرسم بقية الحروف والأرقام
   بخط البرنامج المعتاد تلقائياً عبر آلية الاحتياط في المتصفح. */
const Riyal = (() => {
  /** حرف الريال السعودي في يونيكود */
  const CHAR = '⃀';

  const FONT_B64 = 'T1RUTwAJAIAAAwAQQ0ZGIKaYjnAAAANUAAABG09TLzJ1YEJCAAABAAAAAGBjbWFwsVFY3AAAAvgAAAA8aGVhZC+o/+4AAACcAAAANmhoZWEGBQJdAAAA1AAAACRobXR4BT8ANwAABHAAAAAIbWF4cAACUAAAAAD4AAAABm5hbWX9/mE6AAABYAAAAZhwb3N0AAMAAAAAAzQAAAAgAAEAAAABAADaZh5wXw889QADA+gAAAAA5tfeKQAAAADm194pADcAAAKsArwAAAADAAIAAAAAAAAAAQAAAyD/OAAAAucANwA7AqwAAQAAAAAAAAAAAAAAAAAAAAIAAFAAAAIAAAADAqABkAAFAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAACAAAAAAAAAABCUUxBAAAgwOkAAyD/OAAAAyAAyAAAAAAAAAAAAfQCvAAAACAAAAAAAAwAlgABAAAAAAABAAoAAAABAAAAAAACAAcACgABAAAAAAADABYAEQABAAAAAAAEABIAJwABAAAAAAAFAAsAOQABAAAAAAAGABIARAADAAEECQABABQAVgADAAEECQACAA4AagADAAEECQADACwAeAADAAEECQAEACQApAADAAEECQAFABYAyAADAAEECQAGACQA3lNhdWRpUml5YWxSZWd1bGFyU2F1ZGlSaXlhbC1SZWd1bGFyLTEuMFNhdWRpUml5YWwgUmVndWxhclZlcnNpb24gMS4wU2F1ZGlSaXlhbC1SZWd1bGFyAFMAYQB1AGQAaQBSAGkAeQBhAGwAUgBlAGcAdQBsAGEAcgBTAGEAdQBkAGkAUgBpAHkAYQBsAC0AUgBlAGcAdQBsAGEAcgAtADEALgAwAFMAYQB1AGQAaQBSAGkAeQBhAGwAIABSAGUAZwB1AGwAYQByAFYAZQByAHMAaQBvAG4AIAAxAC4AMABTAGEAdQBkAGkAUgBpAHkAYQBsAC0AUgBlAGcAdQBsAGEAcgAAAAIAAAADAAAAFAADAAEAAAAUAAQAKAAAAAYABAABAAIgwOkA//8AACDA6QD//99BFwEAAQAAAAAAAAADAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAEAgABAQELU2F1ZGlSaXlhbAABAQEZ+BwC+B0D+BgEwov5QPlQBeUPi/evEugRAAMBAQYYInJpeWFsU2F1ZGkgUml5YWwgU3ltYm9sU2F1ZGlSaXlhbAAAAAGHAAIBAQS5+OwO+Xv4O/jtFYujpJygH52hko2LG4z8OfdMsQWLkYdpgB9pgIWDixv7gVYF+FoHovycFfeAvAWLjYNvhB9vhYJ6ixv7gloFi4uXo44fpI+an4sb+z34wBWLlpyfoh+lqZaLixuK/JAFi21VdHYfhoV9gosb+3VbBYuLpJ6RH6SRlpaLG/detIjsideN97YF+zr73BX4z/cOBYuMiG+FH2uFgHuLG/zP+w8Fi4mYppIfp5KVl4sbDgACWAAAAucANw==';

  const FONT_CSS = "@font-face{font-family:'SaudiRiyal';"
    + 'src:url(data:font/otf;base64,' + FONT_B64 + ") format('opentype');"
    + 'font-weight:normal;font-style:normal;font-display:block;}';

  /** مسارات الرمز لرسمه كـ SVG عند الحاجة */
  const PATHS = [
    'm 149.64835,51.66052 c 0,0 7.58886,-8.027536 14.42611,-13.666839 6.83725,-5.639303 9.36431,-6.327239 9.36431,-6.327239 l 0.25309,135.402938 59.22296,-12.40139 c 0,0 1.72913,1.47388 -1.77162,12.40139 -3.50074,10.9275 -5.31488,13.41375 -5.31488,13.41375 l -76.17997,16.957 z',
    'm 156.82685,218.76803 75.79385,-15.61418 c 0,0 0.64297,2.45546 -1.30119,11.38535 -1.94415,8.92988 -4.87943,14.63829 -4.87943,14.63829 l -76.44443,15.61418 c 0,0 -0.0565,-3.74569 0.97589,-11.71064 1.03237,-7.96494 5.85531,-14.313 5.85531,-14.313 z',
    'm 102.58196,40.095987 c 0,0 3.53724,-5.39757 11.05552,-11.907277 9.55592,-8.274005 13.12037,-8.397044 13.12037,-8.397044 l -0.52481,163.217544 c 0,0 -9.51818,17.49444 -16.26927,24.66631 -1.79861,1.91071 -6.29778,4.72334 -6.29778,4.72334 L 31.241491,227.6185 c 0,0 0.06517,-7.74719 1.772316,-14.10974 2.135768,-7.96001 5.575095,-11.60621 5.575095,-11.60621 l 65.077088,-13.12038 -1.04963,-30.9641 -0.52482,-24.66632 z',
    'M 49.362753,145.42852 232.67815,106.244 c 0,0 0.53618,0.94242 -1.36293,9.88132 -2.18521,10.28546 -5.45177,15.6738 -5.45177,15.6738 L 42.121298,171.06967 c 0,0 -0.540491,-3.90655 1.70702,-12.87589 2.247511,-8.86935 5.534435,-12.86526 5.534435,-12.86526 z',
  ];

  /** رسم الرمز كـ SVG — للأماكن اللي ما يُعتمد فيها على الخط */
  function svg(size, color) {
    const s = size || 14;
    return '<svg viewBox="0 0 264.58 264.58" width="' + s + '" height="' + s + '"'
      + ' fill="' + (color || 'currentColor') + '" style="vertical-align:-0.12em"'
      + ' role="img" aria-label="ريال سعودي">'
      + PATHS.map(function (d) { return '<path d="' + d + '"/>'; }).join('')
      + '</svg>';
  }

  /** حقن تعريف الخط داخل مستند (الصفحة الحالية أو نافذة الطباعة) */
  function inject(doc) {
    const d = doc || document;
    if (d.getElementById('riyal-font')) return;
    const st = d.createElement('style');
    st.id = 'riyal-font';
    st.textContent = FONT_CSS;
    (d.head || d.documentElement).appendChild(st);
  }

  function has(text) { return String(text == null ? '' : text).indexOf(CHAR) >= 0; }

  return { CHAR, FONT_CSS, FONT_B64, PATHS, svg, inject, has };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Riyal;
