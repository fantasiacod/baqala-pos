/* شاشة التحديث التلقائي */
const Updater = (() => {
  const { h, $, esc } = UI;
  let modal = null;
  let shownForVersion = null;
  let last = { status: 'idle' };

  function fmtSize(b) {
    if (!b) return '';
    const mb = b / 1048576;
    return mb >= 1 ? `${mb.toFixed(1)} ميجا` : `${(b / 1024).toFixed(0)} كيلو`;
  }
  function fmtSpeed(b) {
    if (!b) return '';
    const mb = b / 1048576;
    return mb >= 1 ? `${mb.toFixed(1)} م/ث` : `${(b / 1024).toFixed(0)} ك/ث`;
  }

  /* ------------------------------ الشاشة ------------------------------ */
  function open(state, { manual = false } = {}) {
    if (modal) { render(state); return; }
    modal = UI.modal({
      title: 'تحديث البرنامج',
      width: 'narrow',
      closeOnBackdrop: false,
      body: '<div id="upd-body"></div>',
      footer: '<div id="upd-foot" class="row gap6" style="width:100%;justify-content:flex-end"></div>',
      onClose: () => { modal = null; },
    });
    render(state, { manual });
  }

  function close() { if (modal) { modal.close(); modal = null; } }

  function render(s, { manual = false } = {}) {
    if (!modal) return;
    const body = $('#upd-body', modal.el);
    const foot = $('#upd-foot', modal.el);
    if (!body || !foot) return;
    const v = (s.info && s.info.version) || '';

    if (s.status === 'checking') {
      body.innerHTML = `<div class="center" style="padding:18px 0">
        <span class="spin" style="width:28px;height:28px"></span>
        <div class="mt12 muted">جاري البحث عن تحديث…</div></div>`;
      foot.innerHTML = '';
      return;
    }

    if (s.status === 'none') {
      body.innerHTML = `<div class="center" style="padding:14px 0">
        <div style="font-size:40px">${Icons.check}</div>
        <div class="bold mt12" style="font-size:16px">برنامجك محدّث</div>
        <div class="muted small mt8">النسخة الحالية ${esc(s.version || '')} هي الأحدث</div></div>`;
      foot.innerHTML = `<button class="btn primary" id="u-close">${esc(t('close'))}</button>`;
      $('#u-close', modal.el).onclick = close;
      return;
    }

    if (s.status === 'unset') {
      body.innerHTML = `<div class="alert-box info">${Icons.info}<div>
        ما تم ضبط عنوان سيرفر التحديثات بعد.<br>
        اضبطه من: <b>الإعدادات ← التحديثات</b> عشان يوصلك التحديث تلقائياً.</div></div>`;
      foot.innerHTML = `<button class="btn" id="u-close">${esc(t('close'))}</button>
        <button class="btn primary" id="u-go">فتح الإعدادات</button>`;
      $('#u-close', modal.el).onclick = close;
      $('#u-go', modal.el).onclick = () => { close(); App.go('settings'); setTimeout(() => Pages.settings.openTab('update'), 250); };
      return;
    }

    if (s.status === 'error') {
      body.innerHTML = `<div class="alert-box danger">${Icons.alert}<div>
        <b>تعذّر التحديث</b><div class="small mt8">${esc(s.error || '')}</div></div></div>`;
      foot.innerHTML = `<button class="btn" id="u-close">${esc(t('close'))}</button>
        <button class="btn primary" id="u-retry">${Icons.refresh} إعادة المحاولة</button>`;
      $('#u-close', modal.el).onclick = close;
      $('#u-retry', modal.el).onclick = () => window.baqala.update.check({ manual: true });
      return;
    }

    if (s.status === 'available') {
      body.innerHTML = `
        <div class="center mb16">
          <div style="width:64px;height:64px;border-radius:18px;margin:0 auto 12px;display:grid;place-items:center;
                      background:linear-gradient(135deg,var(--accent),var(--accent-2));color:#fff">
            ${Icons.download}</div>
          <div class="bold" style="font-size:17px">يتوفر تحديث جديد</div>
          <div class="row gap6 mt8" style="justify-content:center">
            <span class="badge">${esc(s.version || '')}</span>
            <span class="muted">←</span>
            <span class="badge ok">${esc(v)}</span>
          </div>
          ${s.info && s.info.size ? `<div class="muted small mt8">حجم التحديث ${esc(fmtSize(s.info.size))}</div>` : ''}
        </div>
        ${s.info && s.info.notes ? `<div class="card" style="padding:12px;max-height:180px;overflow:auto">
          <div class="bold small mb8">الجديد في هذا التحديث</div>
          <div class="small" style="white-space:pre-line">${esc(s.info.notes)}</div></div>` : ''}
        <div class="alert-box info mt12">${Icons.info}<div>
          بياناتك ما تتأثر — الأصناف والفواتير والموظفين تبقى كما هي.</div></div>`;
      foot.innerHTML = `<button class="btn" id="u-later">لاحقاً</button>
        <button class="btn primary" id="u-dl">${Icons.download} تنزيل التحديث</button>`;
      $('#u-later', modal.el).onclick = close;
      $('#u-dl', modal.el).onclick = () => window.baqala.update.download();
      return;
    }

    if (s.status === 'downloading') {
      const p = (s.progress && s.progress.percent) || 0;
      body.innerHTML = `
        <div class="center mb16"><div class="bold" style="font-size:16px">جاري تنزيل التحديث ${esc(v)}</div></div>
        <div class="progress" style="height:10px"><i style="width:${p}%"></i></div>
        <div class="row mt8" style="justify-content:space-between">
          <span class="bold num">${p}%</span>
          <span class="muted small">
            ${s.progress && s.progress.total ? esc(fmtSize(s.progress.transferred) + ' من ' + fmtSize(s.progress.total)) : ''}
            ${s.progress && s.progress.speed ? ' · ' + esc(fmtSpeed(s.progress.speed)) : ''}
          </span></div>
        <div class="muted small mt12 center">تقدر تكمل شغلك، البرنامج ينزّل في الخلفية</div>`;
      foot.innerHTML = `<button class="btn" id="u-hide">إخفاء</button>`;
      $('#u-hide', modal.el).onclick = close;
      return;
    }

    if (s.status === 'downloaded') {
      body.innerHTML = `
        <div class="center mb16">
          <div style="width:64px;height:64px;border-radius:18px;margin:0 auto 12px;display:grid;place-items:center;
                      background:var(--ok);color:#fff">${Icons.check}</div>
          <div class="bold" style="font-size:17px">التحديث ${esc(v)} جاهز للتثبيت</div>
          <div class="muted small mt8">البرنامج راح يقفل ويفتح من جديد خلال ثوانٍ</div>
        </div>
        <div class="alert-box warn">${Icons.warning}<div>
          تأكد إنك أنهيت أي فاتورة مفتوحة قبل التثبيت.</div></div>`;
      foot.innerHTML = `<button class="btn" id="u-later">عند إغلاق البرنامج</button>
        <button class="btn primary" id="u-install">${Icons.refresh} التثبيت الآن</button>`;
      $('#u-later', modal.el).onclick = close;
      $('#u-install', modal.el).onclick = () => window.baqala.update.install();
      return;
    }

    body.innerHTML = `<div class="center muted" style="padding:20px 0">جاري التحضير…</div>`;
    foot.innerHTML = `<button class="btn" id="u-close">${esc(t('close'))}</button>`;
    $('#u-close', modal.el).onclick = close;
  }

  /* ------------------------------ التشغيل ----------------------------- */
  async function init() {
    if (!window.baqala.update) return;
    const st = await window.baqala.update.state();
    last = st.ok ? st.data : last;

    window.baqala.update.onEvent((s) => {
      last = { ...last, ...s };
      // نعرض الشاشة تلقائياً مرة وحدة لكل إصدار جديد
      if (s.status === 'available') {
        const v = s.info && s.info.version;
        if (v && shownForVersion !== v) { shownForVersion = v; open(last); }
      } else if (s.status === 'downloaded') {
        open(last);
      } else if (modal) {
        render(last);
      }
      updateBadge();
    });
    updateBadge();
  }

  /** نقطة صغيرة على زر الإعدادات لما يكون فيه تحديث */
  function updateBadge() {
    const el = document.querySelector('[data-route="settings"] .badge-slot');
    if (!el) return;
    el.innerHTML = (last.status === 'available' || last.status === 'downloaded')
      ? '<span class="badge ok dot"></span>' : '';
  }

  async function checkNow() {
    const st = await window.baqala.update.state();
    const s = st.ok ? st.data : {};
    open({ ...s, status: 'checking' }, { manual: true });
    window.baqala.update.check({ manual: true });
  }

  function state() { return last; }

  return { init, checkNow, open, close, state };
})();
