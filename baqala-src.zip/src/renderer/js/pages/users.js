/* إدارة الموظفين والصلاحيات */
Pages.users = (() => {
  const { h, $, $$, esc, money } = UI;
  let container = null;
  let permsMeta = { all: [], presets: {} };

  const PERM_LABELS = {
    pos: 'شاشة الكاشير والبيع',
    sale_discount: 'إعطاء خصم على الفاتورة',
    sale_return: 'إرجاع فاتورة',
    sale_void: 'إلغاء فاتورة',
    sale_credit: 'البيع الآجل (على الحساب)',
    sales_view: 'الاطلاع على الفواتير',
    products_view: 'عرض الأصناف والأسعار',
    products_edit: 'إضافة وتعديل الأصناف',
    inventory: 'الجرد وتعديل الكميات',
    purchases: 'المشتريات وفواتير الموردين',
    suppliers: 'إدارة الموردين',
    customers: 'إدارة العملاء',
    debts: 'الديون والسداد',
    expenses: 'تسجيل المصروفات',
    reports: 'التقارير',
    dashboard: 'لوحة التحكم والأرباح',
    users: 'إدارة الموظفين',
    settings: 'إعدادات البرنامج',
    backup: 'النسخ الاحتياطي',
    activity_log: 'سجل نشاط الموظفين',
  };

  const PERM_GROUPS = [
    { title: 'البيع', keys: ['pos', 'sale_discount', 'sale_return', 'sale_void', 'sale_credit', 'sales_view'] },
    { title: 'المخزون', keys: ['products_view', 'products_edit', 'inventory', 'purchases'] },
    { title: 'الحسابات', keys: ['customers', 'suppliers', 'debts', 'expenses'] },
    { title: 'الإدارة', keys: ['dashboard', 'reports', 'activity_log', 'users', 'settings', 'backup'] },
  ];

  async function render(view) {
    container = view;
    permsMeta = (await API.safe('settings.permissions')) || permsMeta;
    const users = await API.safe('users.list');
    if (!users) return;

    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="alert-box info" style="flex:1">${Icons.info}<div>
          كل موظف له حساب خاص وكلمة مرور، وكل حركة يسويها تتسجل باسمه في سجل النشاط.</div></div>
        <button class="btn primary sm" id="new">${Icons.plus} موظف جديد</button>
      </div>
      <div class="grid g3" id="cards"></div>
    </div>`);
    view.appendChild(el);
    $('#new', el).onclick = () => editDialog(null);

    $('#cards', el).innerHTML = users.map((u) => `
      <div class="card" style="padding:16px">
        <div class="row gap10 mb12">
          <div class="avatar" style="width:44px;height:44px;font-size:16px;background:${esc(u.color || UI.colorFor(u.name))}">${esc(UI.initials(u.name))}</div>
          <div style="flex:1;min-width:0">
            <div class="bold">${esc(u.name)}</div>
            <div class="small muted num">${esc(u.username)}</div>
          </div>
          ${u.active ? '' : '<span class="badge danger">موقوف</span>'}
        </div>
        <div class="row gap6 mb12">
          <span class="badge ${u.role === 'owner' ? 'ok' : u.role === 'manager' ? 'info' : ''}">${esc(App.roleName(u.role))}</span>
          <span class="badge">${u.permissions.length} صلاحية</span>
        </div>
        <div class="small muted mb12">
          ${u.last_login ? 'آخر دخول: ' + esc(UI.dateTimeStr(u.last_login)) : 'ما سجّل دخول بعد'}
        </div>
        <div class="row gap6">
          <button class="btn sm" data-ed="${u.id}" style="flex:1">${Icons.edit} ${esc(t('edit'))}</button>
          <button class="btn sm" data-lg="${u.id}">${Icons.history}</button>
          ${u.role !== 'owner' ? `<button class="btn ghost icon sm" data-del="${u.id}">${Icons.trash}</button>` : ''}
        </div>
      </div>`).join('');

    $$('[data-ed]', el).forEach((b) => b.onclick = () => editDialog(users.find((u) => u.id === Number(b.dataset.ed))));
    $$('[data-lg]', el).forEach((b) => b.onclick = () => {
      App.go('activity');
      setTimeout(() => Pages.activity.filterUser(Number(b.dataset.lg)), 300);
    });
    $$('[data-del]', el).forEach((b) => b.onclick = async () => {
      const u = users.find((x) => x.id === Number(b.dataset.del));
      const ok = await UI.confirm({ title: 'حذف موظف', message: `حذف حساب «${esc(u.name)}»؟ لو عليه فواتير بيتم إيقافه بدل حذفه.` });
      if (!ok) return;
      const r = await API.safe('users.delete', { id: u.id });
      if (r) { UI.ok(r.disabled ? 'تم إيقاف الحساب' : 'تم الحذف'); render(container); }
    });
  }

  function editDialog(u) {
    const isNew = !u;
    u = u || { role: 'cashier', permissions: permsMeta.presets.cashier || [], active: true, color: '#1a73e8' };
    const isOwner = u.role === 'owner';

    const m = UI.modal({
      title: isNew ? 'موظف جديد' : u.name,
      width: 'wide',
      body: `
        <div class="grid g2 mb16">
          <div class="field"><label>الاسم الكامل *</label><input class="input" id="u-n" value="${esc(u.name || '')}"></div>
          <div class="field"><label>اسم المستخدم (للدخول) *</label>
            <input class="input num" id="u-u" value="${esc(u.username || '')}" ${isNew ? '' : 'disabled'} placeholder="ahmed">
            <span class="hint">حروف إنجليزية وأرقام فقط</span></div>
          <div class="field"><label>${isNew ? 'كلمة المرور *' : 'كلمة مرور جديدة (اتركها فاضية لو ما تبغى تغيير)'}</label>
            <input class="input" id="u-p" type="text" placeholder="${isNew ? '4 خانات على الأقل' : '••••'}"></div>
          <div class="field"><label>${esc(t('phone'))}</label><input class="input" id="u-ph" value="${esc(u.phone || '')}"></div>
          <div class="field"><label>الوظيفة</label>
            <select class="select" id="u-r" ${isOwner && !isNew ? 'disabled' : ''}>
              <option value="cashier" ${u.role === 'cashier' ? 'selected' : ''}>كاشير</option>
              <option value="manager" ${u.role === 'manager' ? 'selected' : ''}>مدير</option>
              <option value="owner" ${u.role === 'owner' ? 'selected' : ''}>صاحب المحل</option>
            </select>
            <span class="hint">اختيار الوظيفة يضبط الصلاحيات تلقائياً، وتقدر تعدلها تحت</span></div>
          <div class="field"><label>لون الحساب</label><input type="color" class="input" id="u-c" value="${esc(u.color || '#1a73e8')}" style="height:42px"></div>
        </div>

        <label class="switch mb16"><input type="checkbox" id="u-a" ${u.active !== false ? 'checked' : ''}><span class="track"></span>
          <span>الحساب فعّال ويقدر يسجّل دخول</span></label>

        <div class="divider"></div>
        <div class="row mb12"><h3 style="margin:0;font-size:14px">الصلاحيات</h3><div class="spacer"></div>
          <button class="btn sm" id="u-all">تحديد الكل</button>
          <button class="btn sm" id="u-none">إلغاء الكل</button></div>
        <div id="perms" class="grid g2 gap10"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${esc(t('save'))}</button>`,
    });

    const drawPerms = (selected) => {
      $('#perms', m.el).innerHTML = PERM_GROUPS.map((g) => `
        <div class="card" style="padding:12px">
          <div class="bold small mb8">${esc(g.title)}</div>
          ${g.keys.map((k) => `
            <label class="check" style="display:flex;padding:4px 0">
              <input type="checkbox" data-perm="${k}" ${selected.includes(k) ? 'checked' : ''}>
              <span>${esc(PERM_LABELS[k] || k)}</span></label>`).join('')}
        </div>`).join('');
    };
    drawPerms(u.permissions || []);

    $('#u-r', m.el).onchange = (e) => {
      const preset = permsMeta.presets[e.target.value] || [];
      drawPerms(preset);
    };
    $('#u-all', m.el).onclick = () => $$('[data-perm]', m.el).forEach((c) => { c.checked = true; });
    $('#u-none', m.el).onclick = () => $$('[data-perm]', m.el).forEach((c) => { c.checked = false; });

    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const payload = {
        id: u.id || 0,
        name: $('#u-n', m.el).value.trim(),
        username: $('#u-u', m.el).value.trim().toLowerCase(),
        password: $('#u-p', m.el).value,
        phone: $('#u-ph', m.el).value.trim(),
        role: $('#u-r', m.el).value,
        color: $('#u-c', m.el).value,
        active: $('#u-a', m.el).checked,
        permissions: $$('[data-perm]', m.el).filter((c) => c.checked).map((c) => c.dataset.perm),
      };
      if (!payload.name) return UI.err('اكتب اسم الموظف');
      if (isNew && !payload.username) return UI.err('اكتب اسم المستخدم');
      if (isNew && payload.password.length < 4) return UI.err('كلمة المرور لازم 4 خانات على الأقل');
      if (!isNew && !payload.password) delete payload.password;

      const r = await API.safe(isNew ? 'users.create' : 'users.update', payload);
      if (!r) return;
      UI.ok(isNew ? 'تم إنشاء الحساب' : 'تم حفظ التعديلات');
      m.close();
      render(container);
    };
  }

  return { render, editDialog, PERM_LABELS };
})();
