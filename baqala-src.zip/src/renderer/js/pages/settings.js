/* الإعدادات */
Pages.settings = (() => {
  const { h, $, $$, esc, money } = UI;
  let tab = 'store';
  let container = null;
  let S = {};

  const TABS = [
    { k: 'store', n: 'بيانات المحل', i: () => Icons.store },
    { k: 'tax', n: 'الضريبة', i: () => Icons.receipt },
    { k: 'look', n: 'شكل البرنامج', i: () => Icons.palette },
    { k: 'receipt', n: 'الفاتورة والطباعة', i: () => Icons.print },
    { k: 'alerts', n: 'التنبيهات', i: () => Icons.alert },
    { k: 'network', n: 'الأجهزة والاتصال', i: () => Icons.server },
    { k: 'update', n: 'التحديثات', i: () => Icons.download },
    { k: 'backup', n: 'النسخ والسجل', i: () => Icons.save },
  ];

  const ACCENTS = ['#0f9d58', '#1a73e8', '#7b1fa2', '#c2185b', '#e64a19', '#00897b', '#5d4037', '#455a64', '#d32f2f', '#f9a825'];
  const FONTS = [
    { v: 'Cairo', n: 'القاهرة (Cairo)' },
    { v: 'Tajawal', n: 'تجوال (Tajawal)' },
    { v: 'Almarai', n: 'المراعي (Almarai)' },
    { v: 'IBM Plex Sans Arabic', n: 'IBM Plex Arabic' },
  ];

  async function render(view) {
    container = view;
    S = (await API.safe('settings.get')) || {};
    API.settings = S;
    view.innerHTML = '';
    const el = h(`<div class="grid" style="grid-template-columns:230px 1fr;align-items:start">
      <div class="card"><div class="nav" style="padding:8px">
        ${TABS.map((x) => `<button class="nav-item ${tab === x.k ? 'active' : ''}" data-s="${x.k}">${x.i()}<span>${esc(x.n)}</span></button>`).join('')}
      </div></div>
      <div id="pane"></div>
    </div>`);
    view.appendChild(el);
    $$('[data-s]', el).forEach((b) => b.onclick = () => { tab = b.dataset.s; render(view); });
    pane();
  }

  function pane() {
    const box = $('#pane', container);
    box.innerHTML = '';
    ({ store: storeTab, tax: taxTab, look: lookTab, receipt: receiptTab,
      alerts: alertsTab, network: networkTab, update: updateTab, backup: backupTab })[tab](box);
  }

  /** فتح تبويب محدد من خارج الصفحة */
  function openTab(k) {
    if (!TABS.some((x) => x.k === k)) return;
    tab = k;
    if (container) render(container);
  }

  async function save(patch, msg) {
    const r = await API.safe('settings.update', patch);
    if (!r) return null;
    S = r;
    API.settings = r;
    App.applyTheme(r);
    if (msg !== false) UI.ok(msg || 'تم الحفظ');
    return r;
  }

  /* ---------------------------- بيانات المحل ---------------------------- */
  const CURRENCIES = [
    { v: Riyal.CHAR, n: `رمز الريال السعودي الجديد  ${Riyal.CHAR}` },
    { v: 'ر.س', n: 'ر.س (الرمز القديم)' },
    { v: 'SAR', n: 'SAR' },
  ];

  async function storeTab(box) {
    const comp = (await API.safe('settings.compliance', {}, { silent: true })) || {
      required: false, income12m: 0, branches: 1, byIncome: false, byBranches: false, threshold: 100000,
    };
    const needTax = !!comp.required;
    const curAr = S.currency_ar || Riyal.CHAR;
    const curKnown = CURRENCIES.some((c) => c.v === curAr);

    const el = h(`<div class="col gap14"><div class="card"><div class="card-head"><h3>بيانات المحل</h3></div>
      <div class="card-body">
        <div class="grid g2">
          <div class="field"><label>اسم المحل (يظهر بالفاتورة) *</label>
            <div class="row gap6">
              <input class="input" id="s-name" value="${esc(S.store_name || '')}">
              <button class="btn sm icon" id="s-gen-ar" type="button" title="ترجمة من الإنجليزي">${Icons.globe}</button>
            </div></div>
          <div class="field"><label>الاسم بالإنجليزي</label>
            <div class="row gap6">
              <input class="input" id="s-name-en" value="${esc(S.store_name_en || '')}">
              <button class="btn sm icon" id="s-gen-en" type="button" title="ترجمة من العربي">${Icons.globe}</button>
            </div>
            <span class="hint">يتعبّى تلقائياً وأنت تكتب الاسم بالعربي — وتقدر تعدّله</span></div>

          <div class="field"><label>رقم السجل التجاري (12 رقم)</label>
            <input class="input" id="s-cr" inputmode="numeric" maxlength="12" placeholder="12 رقم"
                   value="${esc(S.cr_number || '')}">
            <span class="hint" id="s-cr-hint"></span></div>

          <div class="field"><label>رقم الجوال (10 أرقام)</label>
            <input class="input" id="s-phone" inputmode="numeric" maxlength="10" placeholder="05xxxxxxxx"
                   value="${esc(S.phone || '')}">
            <span class="hint" id="s-phone-hint"></span></div>

          <div class="field"><label>عدد الفروع</label>
            <input class="input" id="s-branches" type="number" min="1" max="999" value="${esc(S.branches_count || '1')}">
            <span class="hint">أكثر من فرع يوجب إضافة السجل الضريبي</span></div>

          <div class="field"><label>العنوان</label><input class="input" id="s-addr" value="${esc(S.address || '')}"></div>
        </div>
        <div class="divider"></div>
        <div class="row gap14">
          <div>
            <label class="small bold">شعار المحل</label>
            <div class="mt8" style="width:110px;height:110px;border:2px dashed var(--border);border-radius:14px;display:grid;place-items:center;overflow:hidden" id="logo-box">
              ${S.logo ? `<img src="${esc(S.logo)}" style="width:100%;height:100%;object-fit:contain">` : `<span class="muted small">بدون شعار</span>`}
            </div>
          </div>
          <div class="col">
            <button class="btn sm" id="pick-logo">${Icons.upload} اختر صورة</button>
            ${S.logo ? `<button class="btn sm danger" id="rm-logo">${Icons.trash} حذف الشعار</button>` : ''}
            <span class="hint">يفضل صورة مربعة PNG بحجم صغير</span>
          </div>
        </div>
        <div class="divider"></div>
        <div class="grid g3">
          <div class="field"><label>رمز العملة</label>
            <select class="select" id="s-cur">
              ${CURRENCIES.map((c) => `<option value="${esc(c.v)}" ${curAr === c.v ? 'selected' : ''}>${esc(c.n)}</option>`).join('')}
              <option value="__custom" ${curKnown ? '' : 'selected'}>رمز مخصص…</option>
            </select>
            <span class="hint">المعاينة: <b class="cur-preview">1,250.00 ${esc(curAr)}</b></span></div>
          <div class="field" id="s-cur-custom-wrap" style="${curKnown ? 'display:none' : ''}">
            <label>الرمز المخصص</label><input class="input" id="s-cur-custom" value="${esc(curKnown ? '' : curAr)}"></div>
          <div class="field"><label>عدد الخانات العشرية</label>
            <select class="select" id="s-dec">
              <option value="0" ${S.decimals === '0' ? 'selected' : ''}>بدون كسور</option>
              <option value="2" ${S.decimals !== '0' ? 'selected' : ''}>خانتان (0.00)</option>
            </select></div>
        </div>
        <div class="row mt16"><div class="spacer"></div><button class="btn primary" id="s-save">${Icons.save} ${esc(t('save'))}</button></div>
      </div></div>

      <div class="card">
        <div class="card-head"><h3>السجل الضريبي</h3><div class="spacer"></div>
          <span class="badge ${needTax ? (S.tax_register ? 'ok' : 'danger') : ''}">
            ${needTax ? (S.tax_register ? 'مُسجَّل' : 'مطلوب') : 'اختياري'}</span></div>
        <div class="card-body">
          ${needTax ? `<div class="alert-box ${S.tax_register ? 'ok' : 'warn'}">${S.tax_register ? Icons.check : Icons.warning}<div>
            ${S.tax_register ? 'السجل الضريبي مسجَّل ومطلوب في حالتك لأن ' : 'مطلوب منك إضافة السجل الضريبي لأن '}
            ${comp.byIncome ? `دخل آخر سنة <b>${UI.money(comp.income12m)}</b> تجاوز ${UI.money(comp.threshold)}` : ''}
            ${comp.byIncome && comp.byBranches ? ' و ' : ''}
            ${comp.byBranches ? `عندك <b>${esc(String(comp.branches))}</b> فروع` : ''}.
          </div></div>` : `<div class="alert-box info">${Icons.info}<div>
            السجل الضريبي يصير مطلوباً إذا تجاوز دخلك ${UI.money(comp.threshold)} في السنة أو صار عندك أكثر من فرع.
            دخل آخر سنة الآن: <b>${UI.money(comp.income12m)}</b>.
          </div></div>`}
          <div class="grid g2 mt12">
            <div class="field"><label>رقم السجل الضريبي (20 رقم)</label>
              <input class="input" id="s-taxreg" inputmode="numeric" maxlength="20" placeholder="20 رقم"
                     value="${esc(S.tax_register || '')}">
              <span class="hint" id="s-taxreg-hint"></span></div>
            <div class="field"><label>صورة السجل</label>
              <button class="btn" id="s-goforms" type="button">${Icons.doc} صور السجلات في صفحة النماذج</button>
              <span class="hint">صورة السجل التجاري والسجل الضريبي تُرفَع وتُعرض من صفحة «النماذج»</span></div>
          </div>
          <div class="row mt16"><div class="spacer"></div>
            <button class="btn primary" id="s-taxreg-save">${Icons.save} حفظ السجل الضريبي</button></div>
        </div>
      </div></div>`);
    box.appendChild(el);

    /* ترجمة اسم المحل بين العربي والإنجليزي أثناء الكتابة.
       أول خانة يكتب فيها المستخدم تصير المصدر، والثانية تتعبّى فوراً،
       وإذا عدّل الثانية بنفسه تتوقف عن التتبّع حتى يضغط زر الترجمة. */
    Translit.bindPair($('#s-name', el), $('#s-name-en', el), {
      regenEn: $('#s-gen-en', el),
      regenAr: $('#s-gen-ar', el),
      startAutoEn: true,
      startAutoAr: true,
    });

    /* أرقام فقط + عدّاد مباشر */
    const digitsOnly = (input, len, hintEl, label) => {
      const upd = () => {
        input.value = input.value.replace(/[^\d]/g, '').slice(0, len);
        const n = input.value.length;
        if (!n) { hintEl.textContent = `${label}: ${len} رقم`; hintEl.className = 'hint'; return; }
        const ok = n === len;
        hintEl.textContent = ok ? `تمام ✓ ${len} رقم` : `${n} من ${len} رقم`;
        hintEl.className = ok ? 'hint ok-text' : 'hint danger-text';
      };
      input.addEventListener('input', upd);
      upd();
    };
    digitsOnly($('#s-cr', el), 12, $('#s-cr-hint', el), 'السجل التجاري');
    digitsOnly($('#s-phone', el), 10, $('#s-phone-hint', el), 'رقم الجوال');
    digitsOnly($('#s-taxreg', el), 20, $('#s-taxreg-hint', el), 'السجل الضريبي');

    /* رمز العملة */
    const curSel = $('#s-cur', el);
    const curWrap = $('#s-cur-custom-wrap', el);
    const curCustom = $('#s-cur-custom', el);
    const curValue = () => (curSel.value === '__custom' ? (curCustom.value.trim() || Riyal.CHAR) : curSel.value);
    const curPreview = () => { $('.cur-preview', el).textContent = `1,250.00 ${curValue()}`; };
    curSel.onchange = () => { curWrap.style.display = curSel.value === '__custom' ? '' : 'none'; curPreview(); };
    curCustom.oninput = curPreview;

    $('#s-goforms', el).onclick = () => App.go('forms');

    $('#s-taxreg-save', el).onclick = async () => {
      const v = $('#s-taxreg', el).value.trim();
      if (v && v.length !== 20) return UI.err('رقم السجل الضريبي لازم يكون 20 رقم بالضبط');
      await save({ tax_register: v }, 'تم حفظ السجل الضريبي');
      render(container);
    };

    $('#pick-logo', el).onclick = async () => {
      const r = await window.baqala.openFile({ filters: [{ name: 'صور', extensions: ['png', 'jpg', 'jpeg'] }], encoding: 'base64' });
      if (!r.ok || r.data.canceled) return;
      const ext = r.data.name.toLowerCase().endsWith('.png') ? 'png' : 'jpeg';
      const dataUrl = `data:image/${ext};base64,${r.data.content}`;
      if (dataUrl.length > 700000) return UI.err('الصورة كبيرة، اختر صورة أصغر');
      await save({ logo: dataUrl }, 'تم حفظ الشعار');
      render(container);
    };
    const rl = $('#rm-logo', el);
    if (rl) rl.onclick = async () => { await save({ logo: '' }, 'تم حذف الشعار'); render(container); };

    $('#s-save', el).onclick = async () => {
      const cr = $('#s-cr', el).value.trim();
      const ph = $('#s-phone', el).value.trim();
      if (cr && cr.length !== 12) return UI.err('رقم السجل التجاري لازم يكون 12 رقم بالضبط');
      if (ph && !/^0\d{9}$/.test(ph)) return UI.err('رقم الجوال لازم يكون 10 أرقام ويبدأ بصفر، مثال: 0546758750');
      const cur = curValue();
      await save({
        store_name: $('#s-name', el).value.trim(),
        store_name_en: $('#s-name-en', el).value.trim(),
        cr_number: cr,
        phone: ph,
        branches_count: $('#s-branches', el).value || '1',
        address: $('#s-addr', el).value.trim(),
        currency_ar: cur,
        currency_en: cur,
        decimals: $('#s-dec', el).value,
      });
      App.go('settings');
    };
  }

  /* ------------------------------ الضريبة ------------------------------ */
  function taxTab(box) {
    const on = S.tax_enabled === '1';
    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>ضريبة القيمة المضافة</h3><div class="spacer"></div>
          <span class="badge ${on ? 'ok' : ''}">${on ? 'مفعّلة' : 'موقوفة'}</span></div>
        <div class="card-body">
          <div class="alert-box info mb16">${Icons.info}<div>
            لو محلك مسجل في ضريبة القيمة المضافة، فعّلها هنا وأدخل الرقم الضريبي.
            البرنامج بيطبع <b>فاتورة ضريبية مبسطة</b> مع رمز QR حسب متطلبات هيئة الزكاة والضريبة والجمارك.
            لو ما أنت مسجل، خلّها موقوفة والفواتير تطلع عادية بدون ضريبة.</div></div>

          <label class="switch mb16"><input type="checkbox" id="tx-on" ${on ? 'checked' : ''}><span class="track"></span>
            <span class="bold">تفعيل ضريبة القيمة المضافة على الفواتير</span></label>

          <div id="tx-fields" style="${on ? '' : 'opacity:.5;pointer-events:none'}">
            <div class="grid g3">
              <div class="field"><label>الرقم الضريبي (15 رقم) *</label>
                <input class="input num" id="tx-vat" value="${esc(S.vat_number || '')}" placeholder="3xxxxxxxxxxxxx3" maxlength="15">
                <span class="hint" id="tx-vat-hint">يبدأ بـ 3 وينتهي بـ 3</span></div>
              <div class="field"><label>نسبة الضريبة %</label>
                <input class="input" id="tx-rate" type="number" step="0.5" value="${esc(S.tax_rate || 15)}"></div>
              <div class="field"><label>طريقة احتساب الأسعار</label>
                <select class="select" id="tx-inc">
                  <option value="1" ${S.prices_include_tax !== '0' ? 'selected' : ''}>أسعار الرف شاملة الضريبة</option>
                  <option value="0" ${S.prices_include_tax === '0' ? 'selected' : ''}>الضريبة تضاف على السعر</option>
                </select>
                <span class="hint">المتعارف عليه في البقالات: الأسعار شاملة الضريبة</span></div>
            </div>

            <div class="card mt16" style="padding:14px;background:var(--surface-2)">
              <div class="bold small mb8">مثال توضيحي على صنف سعره 10 ${esc(S.currency_ar || Riyal.CHAR)}</div>
              <div id="tx-example"></div>
            </div>
          </div>

          <div class="row mt16"><div class="spacer"></div>
            <button class="btn primary" id="tx-save">${Icons.save} ${esc(t('save'))}</button></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>ماذا يتغير عند التفعيل؟</h3></div>
        <div class="card-body">
          <div class="row gap14 mb12">${Icons.check}<div><b>عنوان الفاتورة</b> يصير «فاتورة ضريبية مبسطة».</div></div>
          <div class="row gap14 mb12">${Icons.check}<div><b>الرقم الضريبي</b> يظهر في رأس كل فاتورة.</div></div>
          <div class="row gap14 mb12">${Icons.check}<div><b>سطر الضريبة</b> ينضاف بالفاتورة موضّح المبلغ قبل الضريبة والضريبة والإجمالي.</div></div>
          <div class="row gap14 mb12">${Icons.check}<div><b>رمز QR</b> يُطبع أسفل الفاتورة بترميز TLV المطلوب نظاماً.</div></div>
          <div class="row gap14">${Icons.check}<div><b>تقرير الضريبة</b> يشتغل ويعطيك ضريبة المخرجات والمدخلات والصافي المستحق.</div></div>
        </div>
      </div>
    </div>`);
    box.appendChild(el);

    const updExample = () => {
      const rate = Number($('#tx-rate', el).value) || 15;
      const inc = $('#tx-inc', el).value === '1';
      const shelf = 10;
      let net, tax, total;
      if (inc) { net = shelf / (1 + rate / 100); tax = shelf - net; total = shelf; }
      else { net = shelf; tax = shelf * rate / 100; total = net + tax; }
      $('#tx-example', el).innerHTML = `
        <div class="row" style="justify-content:space-between"><span class="muted">قبل الضريبة</span><span>${money(net)}</span></div>
        <div class="row mt8" style="justify-content:space-between"><span class="muted">الضريبة <span class="num">${rate}%</span></span><span>${money(tax)}</span></div>
        <div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
          <span class="bold">يدفع العميل</span><span class="bold">${money(total)}</span></div>`;
    };
    updExample();
    $('#tx-rate', el).oninput = updExample;
    $('#tx-inc', el).onchange = updExample;

    const vatInput = $('#tx-vat', el);
    vatInput.oninput = () => {
      const v = vatInput.value.replace(/\D/g, '');
      vatInput.value = v;
      const hint = $('#tx-vat-hint', el);
      if (!v) { hint.textContent = 'يبدأ بـ 3 وينتهي بـ 3'; hint.className = 'hint'; return; }
      const valid = /^\d{15}$/.test(v) && v.startsWith('3') && v.endsWith('3');
      hint.textContent = valid ? '✓ الرقم الضريبي بصيغة صحيحة' : `${v.length}/15 — لازم 15 رقم يبدأ بـ 3 وينتهي بـ 3`;
      hint.className = valid ? 'hint ok-text' : 'hint danger-text';
    };

    $('#tx-on', el).onchange = (e) => {
      $('#tx-fields', el).style.opacity = e.target.checked ? '1' : '.5';
      $('#tx-fields', el).style.pointerEvents = e.target.checked ? '' : 'none';
    };

    $('#tx-save', el).onclick = async () => {
      const enabled = $('#tx-on', el).checked;
      const r = await API.safe('settings.setTax', {
        enabled,
        vatNumber: vatInput.value.trim(),
        rate: Number($('#tx-rate', el).value) || 15,
        includeInPrice: $('#tx-inc', el).value === '1',
      });
      if (!r) return;
      S = r; API.settings = r;
      UI.ok(enabled ? 'تم تفعيل الضريبة' : 'تم إيقاف الضريبة');
      render(container);
    };
  }

  /* ---------------------------- شكل البرنامج ---------------------------- */
  function lookTab(box) {
    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>الألوان</h3></div>
        <div class="card-body">
          <div class="field mb16"><label>اللون الرئيسي (الأزرار والتمييز)</label>
            <div class="swatches mb8" id="sw"></div>
            <div class="row gap6"><input type="color" class="input" id="c-acc" value="${esc(S.accent || '#0f9d58')}" style="width:64px;height:40px;padding:4px">
              <input class="input num" id="c-acc-t" value="${esc(S.accent || '#0f9d58')}" style="width:120px"></div></div>
          <div class="field mb16"><label>اللون الثانوي</label>
            <div class="row gap6"><input type="color" class="input" id="c-acc2" value="${esc(S.accent2 || '#1a73e8')}" style="width:64px;height:40px;padding:4px">
              <span class="hint">يستخدم في التدرجات والرسوم</span></div></div>
          <div class="field"><label>وضع الألوان</label>
            <div class="seg" id="thm">
              <button data-th="light" class="${S.theme !== 'dark' ? 'active' : ''}">${Icons.sun} فاتح</button>
              <button data-th="dark" class="${S.theme === 'dark' ? 'active' : ''}">${Icons.moon} داكن</button>
            </div></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>الخطوط</h3></div>
        <div class="card-body">
          <div class="grid g2 mb16">
            <div class="field"><label>نوع الخط</label>
              <select class="select" id="f-fam">
                ${FONTS.map((f) => `<option value="${esc(f.v)}" ${S.font_family === f.v ? 'selected' : ''}>${esc(f.n)}</option>`).join('')}
              </select></div>
            <div class="field"><label>حجم الخط: <span id="f-val">${esc(S.font_scale || 100)}%</span></label>
              <input type="range" id="f-size" min="85" max="135" step="5" value="${esc(S.font_scale || 100)}" style="width:100%"></div>
          </div>
          <div class="field mb16"><label>استدارة الحواف: <span id="r-val">${esc(S.radius || 14)}px</span></label>
            <input type="range" id="r-size" min="0" max="24" step="2" value="${esc(S.radius || 14)}" style="width:100%"></div>
          <div class="font-preview" id="prev">
            <div style="font-weight:700;font-size:1.15em">بقالة الأمانة — فاتورة رقم <span class="num">INV-000124</span></div>
            <div class="muted">المجموع: <span class="num">148.50</span> ر.س · الضريبة: <span class="num">19.37</span> ر.س</div>
            <div class="row gap6 mt8"><button class="btn primary sm">زر أساسي</button>
              <button class="btn sm">زر عادي</button><span class="badge ok">شارة</span></div>
          </div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>اللغة</h3></div>
        <div class="card-body">
          <div class="seg" id="lng">
            <button data-l="ar" class="${I18N.current() === 'ar' ? 'active' : ''}">العربية</button>
            <button data-l="en" class="${I18N.current() === 'en' ? 'active' : ''}">English</button>
          </div>
          <div class="hint mt8">تقدر تبدل اللغة بسرعة من زر الكرة الأرضية أعلى الشاشة</div>
        </div>
      </div>

      <div class="row"><div class="spacer"></div>
        <button class="btn" id="l-reset">${Icons.refresh} إرجاع الشكل الافتراضي</button>
        <button class="btn primary" id="l-save">${Icons.save} ${esc(t('save'))}</button></div>
    </div>`);
    box.appendChild(el);

    $('#sw', el).innerHTML = ACCENTS.map((c) => `<div class="swatch ${S.accent === c ? 'active' : ''}" data-c="${c}" style="background:${c}"></div>`).join('');

    const live = (patch) => { Object.assign(S, patch); App.applyTheme(S); };

    $$('[data-c]', el).forEach((d) => d.onclick = () => {
      $$('[data-c]', el).forEach((x) => x.classList.toggle('active', x === d));
      $('#c-acc', el).value = d.dataset.c;
      $('#c-acc-t', el).value = d.dataset.c;
      live({ accent: d.dataset.c });
    });
    $('#c-acc', el).oninput = (e) => { $('#c-acc-t', el).value = e.target.value; live({ accent: e.target.value }); };
    $('#c-acc-t', el).onchange = (e) => {
      if (!/^#[0-9a-fA-F]{6}$/.test(e.target.value)) return UI.err('كود لون غير صحيح');
      $('#c-acc', el).value = e.target.value; live({ accent: e.target.value });
    };
    $('#c-acc2', el).oninput = (e) => live({ accent2: e.target.value });
    $$('[data-th]', el).forEach((b) => b.onclick = () => {
      $$('[data-th]', el).forEach((x) => x.classList.toggle('active', x === b));
      live({ theme: b.dataset.th });
    });
    $('#f-fam', el).onchange = (e) => live({ font_family: e.target.value });
    $('#f-size', el).oninput = (e) => { $('#f-val', el).textContent = e.target.value + '%'; live({ font_scale: e.target.value }); };
    $('#r-size', el).oninput = (e) => { $('#r-val', el).textContent = e.target.value + 'px'; live({ radius: e.target.value }); };
    $$('[data-l]', el).forEach((b) => b.onclick = async () => {
      I18N.setLang(b.dataset.l);
      await save({ lang: b.dataset.l }, false);
      App.boot();
    });

    $('#l-save', el).onclick = async () => {
      await save({
        accent: $('#c-acc', el).value, accent2: $('#c-acc2', el).value,
        theme: S.theme, font_family: $('#f-fam', el).value,
        font_scale: $('#f-size', el).value, radius: $('#r-size', el).value,
      }, 'تم حفظ شكل البرنامج');
      App.boot();
    };
    $('#l-reset', el).onclick = async () => {
      await save({ accent: '#0f9d58', accent2: '#1a73e8', theme: 'light', font_family: 'Cairo', font_scale: '100', radius: '14' }, 'تم الإرجاع');
      App.boot();
    };
  }

  /* ------------------------- الفاتورة والطباعة ------------------------- */
  function receiptTab(box) {
    const el = h(`<div class="grid" style="grid-template-columns:1fr 340px;align-items:start">
      <div class="card">
        <div class="card-head"><h3>إعدادات الطباعة</h3></div>
        <div class="card-body">
          <div class="grid g2 mb16">
            <div class="field"><label>عرض ورق الطابعة</label>
              <select class="select" id="r-w">
                <option value="80" ${S.receipt_width !== '58' ? 'selected' : ''}>80 ملم (الشائع)</option>
                <option value="58" ${S.receipt_width === '58' ? 'selected' : ''}>58 ملم (صغيرة)</option>
              </select></div>
            <div class="field"><label>بادئة رقم الفاتورة</label>
              <input class="input num" id="r-pre" value="${esc(S.invoice_prefix || 'INV-')}"></div>
          </div>
          <div class="field mb16"><label>عبارة أسفل الفاتورة</label>
            <input class="input" id="r-foot" value="${esc(S.receipt_footer || '')}" placeholder="شكراً لزيارتكم"></div>
          <div class="col gap10">
            <label class="switch"><input type="checkbox" id="r-auto" ${S.print_auto !== '0' ? 'checked' : ''}><span class="track"></span>
              <span>طباعة الفاتورة تلقائياً بعد إتمام البيع</span></label>
            <label class="switch"><input type="checkbox" id="r-logo" ${S.receipt_show_logo !== '0' ? 'checked' : ''}><span class="track"></span>
              <span>طباعة الشعار في رأس الفاتورة</span></label>
            <label class="switch"><input type="checkbox" id="r-qr" ${S.receipt_show_qr !== '0' ? 'checked' : ''}><span class="track"></span>
              <span>طباعة رمز هيئة الزكاة والضريبة (عند تفعيل الضريبة)</span></label>
            <label class="switch"><input type="checkbox" id="r-vqr" ${S.receipt_show_verify_qr !== '0' ? 'checked' : ''}><span class="track"></span>
              <span>طباعة رمز التحقق من صحة الفاتورة</span></label>
          </div>
          <div class="alert-box info mt12">${Icons.info}<div>
            رمز التحقق يُطبع على كل فاتورة ويحتوي اسم المحل ورقم السجل التجاري والسجل الضريبي
            (إذا كان مُدخلاً) مع رقم الفاتورة وإجماليها، وفي آخره رمز موقّع بمفتاح خاص بمحلك.
            الزبون يمسحه بأي كاميرا فيقرأ البيانات، وأنت تتأكد من صحته من
            <b>الفواتير ← تحقق من فاتورة</b>.</div></div>
          <div class="row mt16">
            <button class="btn" id="r-test">${Icons.print} طباعة فاتورة تجريبية</button>
            <div class="spacer"></div>
            <button class="btn primary" id="r-save">${Icons.save} ${esc(t('save'))}</button></div>
        </div>
      </div>
      <div class="card">
        <div class="card-head"><h3>معاينة</h3></div>
        <div class="card-body" style="background:var(--surface-3);display:grid;place-items:center;padding:16px">
          <iframe id="prev-frame" style="width:330px;height:560px;border:none;border-radius:8px;background:#fff"></iframe>
        </div>
      </div>
    </div>`);
    box.appendChild(el);

    const sample = () => ({
      invoice_no: (S.invoice_prefix || 'INV-') + '000124',
      created_at: new Date().toISOString(),
      user_name: API.user.name,
      customer_name: '',
      type: 'sale',
      tax_enabled: S.tax_enabled === '1' ? 1 : 0,
      tax_rate: Number(S.tax_rate || 15),
      subtotal: S.tax_enabled === '1' ? 43.48 : 50,
      discount: 0,
      tax_amount: S.tax_enabled === '1' ? 6.52 : 0,
      total: 50,
      cash_amount: 50, card_amount: 0, credit_amount: 0, change_due: 0,
      items: [
        { name: 'حليب المراعي 1 لتر', barcode: '6281007010207', qty: 2, unit_price: 5.22, tax_amount: 1.57, line_total: 12 },
        { name: 'خبز توست', barcode: '6281000123456', qty: 1, unit_price: 4.35, tax_amount: 0.65, line_total: 5 },
        { name: 'أرز بسمتي 5 كيلو', barcode: '6281100998877', qty: 1, unit_price: 28.7, tax_amount: 4.3, line_total: 33 },
      ],
    });

    const refresh = async () => {
      const html = await Receipt.preview(sample());
      const f = $('#prev-frame', el);
      f.srcdoc = html;
    };
    refresh();

    ['#r-w', '#r-foot', '#r-logo', '#r-qr', '#r-pre'].forEach((sel) => {
      const n = $(sel, el);
      n.oninput = n.onchange = () => {
        S.receipt_width = $('#r-w', el).value;
        S.receipt_footer = $('#r-foot', el).value;
        S.receipt_show_logo = $('#r-logo', el).checked ? '1' : '0';
        S.receipt_show_qr = $('#r-qr', el).checked ? '1' : '0';
        S.invoice_prefix = $('#r-pre', el).value;
        API.settings = S;
        refresh();
      };
    });

    $('#r-test', el).onclick = () => Receipt.print(sample(), { silent: false });
    $('#r-save', el).onclick = () => save({
      receipt_width: $('#r-w', el).value,
      receipt_footer: $('#r-foot', el).value.trim(),
      invoice_prefix: $('#r-pre', el).value.trim() || 'INV-',
      print_auto: $('#r-auto', el).checked ? '1' : '0',
      receipt_show_logo: $('#r-logo', el).checked ? '1' : '0',
      receipt_show_qr: $('#r-qr', el).checked ? '1' : '0',
        receipt_show_verify_qr: $('#r-vqr', el).checked ? '1' : '0',
    });
  }

  /* ------------------------------ التنبيهات ------------------------------ */
  function alertsTab(box) {
    const el = h(`<div class="card"><div class="card-head"><h3>تنبيهات المخزون والبيع</h3></div>
      <div class="card-body">
        <div class="field mb16"><label>التنبيه قبل انتهاء الصلاحية بـ (أيام)</label>
          <input class="input" id="a-days" type="number" value="${esc(S.expiry_alert_days || 30)}" style="width:160px">
          <span class="hint">البرنامج ينبهك بالأصناف اللي تنتهي صلاحيتها خلال هذه المدة</span></div>
        <div class="col gap10">
          <label class="switch"><input type="checkbox" id="a-low" ${S.low_stock_alert !== '0' ? 'checked' : ''}><span class="track"></span>
            <span>تنبيه عند نزول الكمية عن حد التنبيه المحدد لكل صنف</span></label>
          <label class="switch"><input type="checkbox" id="a-neg" ${S.negative_stock === '1' ? 'checked' : ''}><span class="track"></span>
            <span>السماح بالبيع حتى لو الكمية صفر (رصيد بالسالب)</span></label>
        </div>
        <div class="alert-box warn mt16">${Icons.warning}<div>
          السماح بالبيع بالسالب مفيد لو ما تجرد كل الأصناف، لكنه يخلي تقارير المخزون غير دقيقة.</div></div>
        <div class="row mt16"><div class="spacer"></div><button class="btn primary" id="a-save">${Icons.save} ${esc(t('save'))}</button></div>
      </div></div>`);
    box.appendChild(el);
    $('#a-save', el).onclick = async () => {
      await save({
        expiry_alert_days: Number($('#a-days', el).value) || 30,
        low_stock_alert: $('#a-low', el).checked ? '1' : '0',
        negative_stock: $('#a-neg', el).checked ? '1' : '0',
      });
      App.refreshAlerts();
    };
  }

  /* --------------------------- الأجهزة والاتصال --------------------------- */
  async function networkTab(box) {
    const info = await window.baqala.info();
    const d = info.ok ? info.data : {};
    const cfg = d.config || {};
    const st = d.serverStatus || {};
    const ips = (d.localIPs || []).map((x) => x.address);
    const modeName = { local: 'جهاز واحد', host: 'الجهاز الرئيسي (سيرفر)', client: 'كاشير فرعي' }[cfg.mode] || cfg.mode;

    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>وضع التشغيل الحالي</h3><div class="spacer"></div>
          <span class="badge ${cfg.mode === 'host' ? 'ok' : cfg.mode === 'client' ? 'info' : ''}">${esc(modeName)}</span></div>
        <div class="card-body">
          ${cfg.mode === 'local' ? `<div class="alert-box info">${Icons.info}<div>
            البرنامج يشتغل على هذا الجهاز لوحده وقاعدة البيانات محفوظة فيه. الأنسب لبقالة فيها كاشير واحد.</div></div>` : ''}
          ${cfg.mode === 'host' ? `
            <div class="alert-box ${st.running ? 'ok' : 'danger'} mb16">${st.running ? Icons.check : Icons.alert}<div>
              ${st.running ? `السيرفر شغّال على المنفذ <b class="num">${st.port}</b>` : 'السيرفر متوقف — جرّب تغيير المنفذ'}</div></div>
            <div class="field mb16"><label>عناوين هذا الجهاز على الشبكة (اكتب أحدها في الأجهزة الفرعية)</label>
              ${ips.length ? ips.map((ip) => `<div class="row gap6 mt8">
                  <input class="input num" value="${esc(ip)}:${esc(st.port || cfg.serverPort)}" readonly style="max-width:260px">
                  <button class="btn sm" data-cp="${esc(ip)}:${esc(st.port || cfg.serverPort)}">نسخ</button></div>`).join('')
                : '<div class="muted small">ما فيه اتصال شبكة</div>'}</div>
            <div class="bold small mb8">الأجهزة المتصلة الآن (${(st.clients || []).length})</div>
            ${(st.clients || []).length ? st.clients.map((c) => `
              <div class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border)">
                <span>${esc(c.user)}</span><span class="small muted num">${esc(c.ip)}</span></div>`).join('')
              : '<div class="muted small">ما فيه أجهزة متصلة</div>'}` : ''}
          ${cfg.mode === 'client' ? `<div class="alert-box info">${Icons.info}<div>
            هذا الجهاز متصل بـ <b class="num">${esc(cfg.serverUrl || '')}</b> وكل البيانات محفوظة هناك.</div></div>` : ''}
          <div class="row mt16"><div class="spacer"></div>
            <button class="btn primary" id="n-change">${Icons.server} تغيير وضع التشغيل</button></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>كيف أربط أكثر من كاشير؟</h3></div>
        <div class="card-body">
          <div class="row gap14 mb12"><span class="badge">1</span><div>
            على الجهاز الرئيسي (اللي فيه البيانات): افتح الإعدادات ← اختر <b>الجهاز الرئيسي</b> واحفظ.</div></div>
          <div class="row gap14 mb12"><span class="badge">2</span><div>
            انسخ العنوان الظاهر فوق، مثال <span class="num">192.168.1.10:7711</span>.</div></div>
          <div class="row gap14 mb12"><span class="badge">3</span><div>
            على جهاز الكاشير الثاني: ثبّت نفس البرنامج، وفي شاشة الدخول اضغط <b>إعداد الاتصال</b> ← <b>كاشير فرعي</b> ← الصق العنوان.</div></div>
          <div class="row gap14 mb12"><span class="badge">4</span><div>
            سجّل دخول بحساب الموظف — وكل الفواتير تنحفظ على الجهاز الرئيسي مباشرة.</div></div>
          <div class="alert-box warn mt12">${Icons.warning}<div>
            لازم الجهازين على نفس شبكة الواي فاي/الكيبل، وجدار الحماية في ويندوز يسمح للبرنامج بالاتصال
            (تظهر رسالة أول مرة — اختر «السماح»). للفروع البعيدة تحتاج سيرفر على الإنترنت.</div></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>معلومات النظام</h3></div>
        <div class="card-body">
          <div class="row" style="justify-content:space-between;padding:6px 0"><span class="muted">إصدار البرنامج</span><span class="num">${esc(d.version || '')}</span></div>
          <div class="row" style="justify-content:space-between;padding:6px 0"><span class="muted">اسم الجهاز</span><span>${esc(cfg.deviceName || '')}</span></div>
          ${d.dbPath ? `<div class="row" style="justify-content:space-between;padding:6px 0">
            <span class="muted">مكان قاعدة البيانات</span>
            <span class="small num" style="max-width:340px;overflow:hidden;text-overflow:ellipsis">${esc(d.dbPath)}</span></div>
            <div class="row mt8"><button class="btn sm" id="n-open">${Icons.box} فتح مجلد البيانات</button></div>` : ''}
        </div>
      </div>
    </div>`);
    box.appendChild(el);

    $$('[data-cp]', el).forEach((b) => b.onclick = () => {
      navigator.clipboard.writeText(b.dataset.cp).then(() => UI.ok('تم نسخ العنوان'));
    });
    $('#n-change', el).onclick = () => Pages.login.networkDialog();
    const op = $('#n-open', el);
    if (op) op.onclick = () => window.baqala.openPath(d.dataDir);
  }

  /* ------------------------------ التحديثات ------------------------------ */
  async function updateTab(box) {
    const r = await window.baqala.update.state();
    const u = r.ok ? r.data : {};
    const statusText = {
      idle: 'جاهز', checking: 'جاري الفحص…', none: 'برنامجك محدّث',
      available: 'يتوفر تحديث جديد', downloading: 'جاري التنزيل…',
      downloaded: 'التحديث جاهز للتثبيت', error: 'صار خطأ', unset: 'ما تم ضبط السيرفر',
    }[u.status] || '—';

    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>تحديثات البرنامج</h3><div class="spacer"></div>
          <span class="badge ${u.status === 'available' || u.status === 'downloaded' ? 'ok' : ''}">${esc(statusText)}</span></div>
        <div class="card-body">
          <div class="row mb16" style="justify-content:space-between">
            <div><div class="small muted">النسخة الحالية</div>
              <div class="bold num" style="font-size:20px">${esc(u.version || '')}</div></div>
            <button class="btn primary" id="u-check">${Icons.refresh} تحقق من وجود تحديث</button>
          </div>

          <div class="alert-box ${u.autoUpdate !== false ? 'ok' : 'warn'} mb16">
            ${u.autoUpdate !== false ? Icons.check : Icons.warning}<div>
            ${u.autoUpdate !== false
              ? 'التحديث التلقائي <b>شغّال</b> — البرنامج يفحص بنفسه بعد ما تفتحه بثوانٍ، وكل ٤ ساعات، وكل ما ترجع له. أول ما ينزل إصدار جديد تطلع لك شاشة التحديث مباشرة.'
              : 'التحديث التلقائي <b>موقوف</b> — ما راح يوصلك إشعار بالإصدارات الجديدة إلا إذا ضغطت «تحقق من وجود تحديث» بنفسك.'}
          </div></div>

          <label class="switch mb16"><input type="checkbox" id="u-auto" ${u.autoUpdate !== false ? 'checked' : ''}>
            <span class="track"></span>
            <span>الفحص التلقائي عن التحديثات</span></label>

          <details class="mb12">
            <summary class="small muted" style="cursor:pointer">إعداد متقدّم — عنوان سيرفر التحديثات</summary>
            <div class="field mt12"><label>عنوان سيرفر التحديثات</label>
              <input class="input num" id="u-url" value="${esc(u.url || '')}"
                     placeholder="${esc(u.defaultUrl || '')}">
              <span class="hint">${u.isDefaultUrl
                ? 'مضبوط على العنوان الرسمي للبرنامج — ما تحتاج تغيّره.'
                : 'عنوان مخصص. اتركه فاضياً واحفظ عشان يرجع للعنوان الرسمي.'}</span></div>
            <div class="row mt12"><div class="spacer"></div>
              ${!u.isDefaultUrl ? `<button class="btn sm" id="u-reset">${Icons.refresh} رجّع العنوان الرسمي</button>` : ''}
              <button class="btn primary" id="u-save">${Icons.save} ${esc(t('save'))}</button></div>
          </details>

          ${!u.packaged ? `<div class="alert-box warn mt16">${Icons.warning}<div>
            التحديث التلقائي يشتغل فقط على النسخة المثبّتة، مو على نسخة التطوير.</div></div>` : ''}
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>كيف أنشر تحديث لبقالتي؟</h3></div>
        <div class="card-body">
          <div class="alert-box info mb16">${Icons.info}<div>
            البرنامج يفحص العنوان أعلاه، وإذا لقى رقم إصدار أحدث من اللي عندك
            يعرض لك شاشة التحديث مع التنزيل وشريط التقدم ثم يثبّته — بدون ما تعيد التثبيت يدوياً.</div></div>
          <div class="row gap14 mb12"><span class="badge">1</span><div>
            العنوان الرسمي مضبوط مسبقاً داخل البرنامج، فما تحتاج تسوي شيء على أجهزة الكاشير.</div></div>
          <div class="row gap14 mb12"><span class="badge">2</span><div>
            إذا كنت تنشر بنفسك: ارفع الملفات الثلاثة اللي ينتجها البناء على أي استضافة أو GitHub Releases:
            <div class="small num mt8" style="background:var(--surface-2);padding:8px 10px;border-radius:8px">
              latest.yml<br>BaqalaPOS-Setup-1.0.4.exe<br>BaqalaPOS-Setup-1.0.4.exe.blockmap</div></div></div>
          <div class="row gap14 mb12"><span class="badge">3</span><div>
            كل ما ترفع إصدار جديد، كل الأجهزة اللي فيها البرنامج بيوصلها التحديث تلقائياً خلال ساعات.</div></div>
          <div class="alert-box warn">${Icons.warning}<div>
            لازم الرابط يكون عام (بدون كلمة مرور) ويبدأ بـ https، والجهاز موصول بالإنترنت وقت الفحص.</div></div>
        </div>
      </div>
    </div>`);
    box.appendChild(el);

    $('#u-check', el).onclick = () => Updater.checkNow();
    const saveUpd = async (url) => {
      const res = await window.baqala.update.config({
        updateUrl: url !== undefined ? url : $('#u-url', el).value.trim(),
        autoUpdate: $('#u-auto', el).checked,
      });
      if (!res.ok) return UI.err(res.error.ar);
      UI.ok('تم حفظ إعدادات التحديث');
      render(container);
    };
    $('#u-save', el).onclick = () => saveUpd();
    const ur = $('#u-reset', el);
    if (ur) ur.onclick = () => saveUpd('');
    // زر التشغيل/الإيقاف يحفظ فوراً بدون ما يفتح الإعداد المتقدّم
    $('#u-auto', el).onchange = () => saveUpd();
  }

  /* --------------------------- النسخ الاحتياطي --------------------------- */
  async function backupTab(box) {
    const list = (await API.safe('settings.backups')) || [];
    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>النسخ الاحتياطي</h3></div>
        <div class="card-body">
          <div class="alert-box info mb16">${Icons.info}<div>
            البرنامج يأخذ نسخة تلقائية كل ٦ ساعات وعند إغلاق البرنامج. ينصح بنسخ ملف النسخة لفلاش ميموري أسبوعياً.</div></div>
          <div class="row gap10 mb16">
            <button class="btn primary" id="b-now">${Icons.save} أخذ نسخة الآن</button>
            <button class="btn" id="b-export">${Icons.download} حفظ نسخة في مكان أختاره</button>
            <button class="btn" id="b-folder">${Icons.box} فتح مجلد النسخ</button>
          </div>
          <label class="switch mb12"><input type="checkbox" id="b-auto" ${S.backup_auto !== '0' ? 'checked' : ''}><span class="track"></span>
            <span>النسخ الاحتياطي التلقائي</span></label>
          <div class="field" style="max-width:220px"><label>عدد النسخ المحفوظة</label>
            <input class="input" id="b-keep" type="number" value="${esc(S.backup_keep || 20)}"></div>
          <div class="row mt16"><div class="spacer"></div><button class="btn primary" id="b-save">${esc(t('save'))}</button></div>
        </div>
      </div>

      <div class="card">
        <div class="card-head"><h3>النسخ المتوفرة</h3><span class="badge">${list.length}</span></div>
        <div class="card-body tight" id="blist"></div>
      </div>

      <div class="card">
        <div class="card-head"><h3>سجل النشاط — الأرشفة التلقائية</h3><div class="spacer"></div>
          <span class="badge" id="lg-count">—</span></div>
        <div class="card-body">
          <div class="alert-box info mb16">${Icons.info}<div>
            عشان ما يثقل البرنامج مع الوقت، يأخذ البرنامج <b>نسخة من سجل النشاط في ملف Excel</b>
            كل أسبوع ثم يحذف القديم من قاعدة البيانات. الملفات محفوظة عندك ومتاحة وقت ما تبغاها.</div></div>
          <div class="grid g3 mb16" id="lg-stats"></div>
          <label class="switch mb12"><input type="checkbox" id="lg-auto"><span class="track"></span>
            <span>الأرشفة التلقائية الأسبوعية</span></label>
          <div class="row gap10 mb16">
            <div class="field" style="width:220px"><label>يحتفظ بآخر كم يوم في البرنامج؟</label>
              <input class="input" id="lg-days" type="number" min="1" max="365"></div>
          </div>
          <div class="row gap10">
            <button class="btn" id="lg-now">${Icons.save} أرشف الآن</button>
            <button class="btn" id="lg-folder">${Icons.box} فتح مجلد الأرشيف</button>
            <div class="spacer"></div>
            <button class="btn primary" id="lg-save">${esc(t('save'))}</button>
          </div>
          <div class="divider"></div>
          <div class="bold small mb8">ملفات الأرشيف</div>
          <div id="lg-files"></div>
        </div>
      </div>

      <div class="card" style="border-color:var(--danger)">
        <div class="card-head"><h3 class="danger-text">منطقة خطرة</h3></div>
        <div class="card-body">
          <div class="row" style="justify-content:space-between">
            <div><div class="bold">تصفير بيانات الحركات</div>
              <div class="small muted">يحذف كل الفواتير والمشتريات والمصروفات والسجل، ويبقي الأصناف والموظفين والإعدادات.</div></div>
            <button class="btn danger" id="b-reset">${Icons.trash} تصفير</button>
          </div>
        </div>
      </div>
    </div>`);
    box.appendChild(el);

    $('#blist', el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الملف', render: (r) => `<span class="num">${esc(r.name)}</span>` },
        { title: 'التاريخ', render: (r) => UI.dateTimeStr(r.at) },
        { title: 'الحجم', align: 'end', render: (r) => `${(r.size / 1024).toFixed(0)} KB` },
        { title: '', align: 'end', render: (r) => `<button class="btn sm" data-rs="${esc(r.path)}">${Icons.refresh} استعادة</button>` },
      ],
      rows: list,
      empty: 'ما فيه نسخ بعد',
    }));

    $$('[data-rs]', el).forEach((b) => b.onclick = async () => {
      const ok = await UI.confirm({
        title: 'استعادة نسخة احتياطية',
        message: 'بيتم استبدال البيانات الحالية بالكامل ببيانات النسخة. (بيتم أخذ نسخة أمان تلقائياً قبل الاستعادة)',
        confirmText: 'استعادة',
      });
      if (!ok) return;
      const r = await API.safe('settings.restore', { path: b.dataset.rs });
      if (!r) return;
      UI.ok('تمت الاستعادة، جاري إعادة التشغيل…');
      setTimeout(() => window.baqala.relaunch(), 900);
    });

    /* ---------------------- سجل النشاط والأرشفة ---------------------- */
    const drawLogs = async () => {
      const st = await API.safe('activity.stats', {}, { silent: true });
      if (!st) return;
      $('#lg-count', el).textContent = `${st.rows} حركة`;
      $('#lg-stats', el).innerHTML = `
        <div class="stat"><div class="lbl">حركات في السجل</div><div class="val" style="font-size:20px">${st.rows}</div>
          <div class="sub">${st.from ? esc(UI.dateStr(st.from)) + ' — ' + esc(UI.dateStr(st.to)) : 'فاضي'}</div></div>
        <div class="stat"><div class="lbl">حجم قاعدة البيانات</div>
          <div class="val" style="font-size:20px">${(st.dbSize / 1048576).toFixed(1)} <small>ميجا</small></div></div>
        <div class="stat"><div class="lbl">آخر أرشفة</div>
          <div class="val" style="font-size:16px">${st.lastPurge ? esc(UI.dateStr(st.lastPurge)) : 'ما تمت بعد'}</div></div>`;
      $('#lg-auto', el).checked = st.autoPurge;
      $('#lg-days', el).value = st.keepDays;

      const files = (await API.safe('activity.archives', {}, { silent: true })) || [];
      const box2 = $('#lg-files', el);
      box2.innerHTML = '';
      box2.appendChild(UI.table({
        compact: true,
        columns: [
          { title: 'الملف', render: (f) => esc(f.name) },
          { title: 'التاريخ', render: (f) => UI.dateTimeStr(f.at) },
          { title: 'الحجم', align: 'end', render: (f) => `${(f.size / 1024).toFixed(0)} KB` },
          { title: '', align: 'end', render: (f) => `<button class="btn sm" data-of="${esc(f.path)}">فتح</button>` },
        ],
        rows: files,
        empty: 'ما فيه ملفات أرشيف بعد',
      }));
      UI.$$('[data-of]', box2).forEach((b) => b.onclick = () => window.baqala.openPath(b.dataset.of));
    };
    drawLogs();

    $('#lg-save', el).onclick = async () => {
      await save({
        log_auto_purge: $('#lg-auto', el).checked ? '1' : '0',
        log_keep_days: Number($('#lg-days', el).value) || 7,
      }, 'تم حفظ إعدادات السجل');
      drawLogs();
    };
    $('#lg-now', el).onclick = async () => {
      const days = Number($('#lg-days', el).value) || 7;
      const ok = await UI.confirm({
        title: 'أرشفة سجل النشاط', danger: false, confirmText: 'أرشف',
        message: `بيتم حفظ كل الحركات الأقدم من <b>${days}</b> يوم في ملف Excel ثم حذفها من البرنامج.`,
      });
      if (!ok) return;
      const r = await API.safe('activity.archive', { keepDays: days });
      if (!r) return;
      UI.ok(r.archived ? `تمت أرشفة ${r.archived} حركة في الملف ${r.name}` : 'ما فيه حركات قديمة للأرشفة');
      drawLogs();
    };
    $('#lg-folder', el).onclick = async () => {
      const info = await window.baqala.info();
      if (info.ok) window.baqala.openPath(info.data.dataDir + '/archive-logs');
    };

    $('#b-now', el).onclick = async () => {
      const r = await API.safe('settings.backup');
      if (r) { UI.ok('تم أخذ نسخة احتياطية'); render(container); }
    };
    $('#b-export', el).onclick = async () => {
      const info = await window.baqala.info();
      const dbPath = info.ok ? info.data.dbPath : null;
      if (!dbPath) return UI.err('غير متاح في وضع الكاشير الفرعي');
      const r = await API.safe('settings.backup');
      if (!r) return;
      UI.ok('النسخة محفوظة في مجلد البيانات، افتح المجلد وانسخها للفلاش');
      window.baqala.openPath(info.data.dataDir);
    };
    $('#b-folder', el).onclick = async () => {
      const info = await window.baqala.info();
      if (info.ok) window.baqala.openPath(info.data.dataDir);
    };
    $('#b-save', el).onclick = () => save({
      backup_auto: $('#b-auto', el).checked ? '1' : '0',
      backup_keep: Number($('#b-keep', el).value) || 20,
    });
    $('#b-reset', el).onclick = async () => {
      const v = await UI.confirm({
        title: 'تصفير بيانات الحركات',
        message: 'هذه العملية ما ترجع! اكتب <b>حذف البيانات</b> للتأكيد.',
        confirmText: 'تصفير نهائي',
        input: { label: 'اكتب: حذف البيانات', placeholder: 'حذف البيانات' },
      });
      if (v === null) return;
      const r = await API.safe('settings.reset', { confirmText: v });
      if (!r) return;
      UI.ok('تم التصفير، جاري إعادة التشغيل…');
      setTimeout(() => window.baqala.relaunch(), 900);
    };
  }

  return { render, openTab };
})();
