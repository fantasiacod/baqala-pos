/* العملاء والموردون والديون والمصروفات */
(() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;

  /* ================================ حسابات ================================ */
  function makeParty(type) {
    const isCust = type === 'customer';
    const state = { q: '', withDebt: false };
    let container = null;

    async function render(view) {
      container = view;
      view.innerHTML = '';
      const el = h(`<div>
        <div class="toolbar">
          <div class="search-box">${Icons.search}<input class="input" id="q" placeholder="${esc(t('search'))} بالاسم أو الجوال"></div>
          <label class="check"><input type="checkbox" id="dbt"> ${isCust ? 'عليهم دين فقط' : 'لهم مستحقات فقط'}</label>
          <div class="spacer"></div>
          <button class="btn sm" id="ex">${Icons.download} ${esc(t('export'))}</button>
          <button class="btn primary sm" id="new">${Icons.plus} ${isCust ? 'عميل جديد' : 'مورد جديد'}</button>
        </div>
        <div class="grid g3 mb16" id="stats"></div>
        <div class="card"><div class="card-body tight" id="list"></div></div>
      </div>`);
      view.appendChild(el);
      $('#q', el).oninput = UI.debounce((e) => { state.q = e.target.value; load(); }, 250);
      $('#dbt', el).onchange = (e) => { state.withDebt = e.target.checked; load(); };
      $('#new', el).onclick = () => editDialog(null);
      $('#ex', el).onclick = exportCSV;
      load();
    }

    async function load() {
      const res = await API.safe('parties.list', { type, q: state.q, withDebt: state.withDebt || undefined, limit: 500 });
      if (!res) return;
      const debt = res.rows.reduce((s, r) => s + (isCust ? Math.max(0, r.balance) : Math.max(0, -r.balance)), 0);
      $('#stats', container).innerHTML = `
        <div class="stat"><div class="lbl">${isCust ? 'عدد العملاء' : 'عدد الموردين'}</div><div class="val">${res.total}</div></div>
        <div class="stat"><div class="lbl">${isCust ? 'إجمالي ديونهم لك' : 'إجمالي ما عليك لهم'}</div>
          <div class="val ${debt > 0 ? (isCust ? 'danger-text' : 'warn-text') : ''}" style="font-size:21px">${money(debt, false)}</div></div>
        <div class="stat"><div class="lbl">${isCust ? 'عملاء عليهم دين' : 'موردون لهم مستحقات'}</div>
          <div class="val">${res.rows.filter((r) => (isCust ? r.balance > 0.009 : r.balance < -0.009)).length}</div></div>`;

      const box = $('#list', container);
      box.innerHTML = '';
      box.appendChild(UI.table({
        columns: [
          { title: t('name'), render: (r) => `<div class="row gap6">
              <div class="avatar" style="width:28px;height:28px;font-size:11px;background:${esc(UI.colorFor(r.name))}">${esc(UI.initials(r.name))}</div>
              <div><div class="bold">${esc(r.name)}</div><div class="small muted">${esc(r.phone || '')}</div></div></div>` },
          ...(isCust ? [{ title: 'حد الدين', align: 'end', render: (r) => Number(r.credit_limit) ? money(r.credit_limit, false) : '—' }] : []),
          { title: t('balance'), align: 'end', render: (r) => {
              const b = Number(r.balance);
              if (Math.abs(b) < 0.009) return '<span class="badge ok">مسدد</span>';
              const owed = isCust ? b > 0 : b < 0;
              return `<span class="bold ${owed ? 'danger-text' : 'ok-text'}">${money(Math.abs(b), false)}</span>
                      <div class="small muted">${owed ? (isCust ? 'عليه' : 'له') : (isCust ? 'له رصيد' : 'عليه')}</div>`;
            } },
          { title: '', align: 'end', width: '210px', render: (r) => `
              <div class="row gap6" style="justify-content:flex-end">
                ${API.can('debts') ? `<button class="btn sm" data-pay="${r.id}">${Icons.wallet} ${isCust ? 'قبض' : 'دفع'}</button>` : ''}
                <button class="btn ghost icon sm" data-st="${r.id}" title="كشف حساب">${Icons.list}</button>
                <button class="btn ghost icon sm" data-ed="${r.id}">${Icons.edit}</button>
                <button class="btn ghost icon sm" data-del="${r.id}">${Icons.trash}</button></div>` },
        ],
        rows: res.rows,
        onRowClick: (r) => statement(r.id),
        empty: isCust ? 'ما فيه عملاء مسجلين' : 'ما فيه موردين مسجلين',
      }));

      $$('[data-ed]', box).forEach((b) => b.onclick = async () => {
        const p = await API.safe('parties.get', { type, id: Number(b.dataset.ed) });
        if (p) editDialog(p);
      });
      $$('[data-pay]', box).forEach((b) => b.onclick = () => payDialog(res.rows.find((x) => x.id === Number(b.dataset.pay))));
      $$('[data-st]', box).forEach((b) => b.onclick = () => statement(Number(b.dataset.st)));
      $$('[data-del]', box).forEach((b) => b.onclick = async () => {
        const row = res.rows.find((x) => x.id === Number(b.dataset.del));
        const ok = await UI.confirm({ title: t('delete'), message: `حذف «${esc(row.name)}»؟` });
        if (!ok) return;
        const r = await API.safe('parties.delete', { type, id: row.id });
        if (r) { UI.ok(r.disabled ? 'تم الإخفاء' : 'تم الحذف'); load(); }
      });
    }

    function editDialog(p, onSaved) {
      const isNew = !p;
      p = p || {};
      const m = UI.modal({
        title: isNew ? (isCust ? 'عميل جديد' : 'مورد جديد') : p.name,
        body: `
          <div class="grid g2">
            <div class="field"><label>${esc(t('name'))} *</label><input class="input" id="e-n" value="${esc(p.name || '')}"></div>
            <div class="field"><label>${esc(t('phone'))}</label><input class="input" id="e-p" value="${esc(p.phone || '')}" placeholder="05xxxxxxxx"></div>
            <div class="field"><label>الرقم الضريبي</label><input class="input" id="e-v" value="${esc(p.vat_number || '')}"></div>
            <div class="field"><label>العنوان</label><input class="input" id="e-a" value="${esc(p.address || '')}"></div>
            ${isCust ? `<div class="field"><label>حد الدين المسموح</label>
              <input class="input" id="e-l" type="number" step="0.01" value="${esc(p.credit_limit || 0)}">
              <span class="hint">صفر = بدون حد</span></div>` : ''}
            ${isNew ? `<div class="field"><label>رصيد افتتاحي</label>
              <input class="input" id="e-b" type="number" step="0.01" value="0">
              <span class="hint">${isCust ? 'دين قديم عليه' : 'بالسالب إذا لك عليه'}</span></div>` : ''}
          </div>
          <div class="field mt12"><label>${esc(t('notes'))}</label><input class="input" id="e-note" value="${esc(p.note || '')}"></div>`,
        footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('save'))}</button>`,
      });
      $('[data-cancel]', m.el).onclick = m.close;
      $('[data-ok]', m.el).onclick = async () => {
        const payload = {
          type, id: p.id || 0,
          name: $('#e-n', m.el).value.trim(),
          phone: $('#e-p', m.el).value.trim(),
          vat_number: $('#e-v', m.el).value.trim(),
          address: $('#e-a', m.el).value.trim(),
          note: $('#e-note', m.el).value.trim(),
        };
        if (isCust) payload.credit_limit = Number(($('#e-l', m.el) || {}).value) || 0;
        if (isNew) payload.balance = Number(($('#e-b', m.el) || {}).value) || 0;
        if (!payload.name) return UI.err('اكتب الاسم');
        const saved = await API.safe('parties.save', payload);
        if (!saved) return;
        UI.ok(t('save'));
        m.close();
        if (onSaved) onSaved(saved); else if (container) load();
      };
    }

    function payDialog(party, onDone) {
      const owed = isCust ? Number(party.balance) : -Number(party.balance);
      const m = UI.modal({
        title: `${isCust ? 'قبض من' : 'دفع إلى'} ${party.name}`,
        width: 'narrow',
        body: `
          <div class="alert-box ${owed > 0 ? 'warn' : 'info'} mb16">${Icons.info}<div>
            الرصيد الحالي: <b>${money(Math.abs(party.balance))}</b> ${owed > 0 ? (isCust ? 'عليه' : 'له') : 'لصالحه'}</div></div>
          <div class="field mb12"><label>${esc(t('amount'))}</label>
            <input class="input lg" id="pa" type="number" step="0.01" value="${owed > 0 ? esc(owed) : ''}"></div>
          <div class="field mb12"><label>طريقة الدفع</label>
            <select class="select" id="pm"><option value="cash">كاش</option><option value="bank">تحويل بنكي</option><option value="card">شبكة</option></select></div>
          <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="pn"></div>`,
        footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('confirm'))}</button>`,
      });
      $('[data-cancel]', m.el).onclick = m.close;
      $('[data-ok]', m.el).onclick = async () => {
        const amount = Number($('#pa', m.el).value);
        if (!(amount > 0)) return UI.err('اكتب مبلغ صحيح');
        const r = await API.safe('parties.pay', {
          type, id: party.id, amount, method: $('#pm', m.el).value, note: $('#pn', m.el).value.trim(),
        });
        if (!r) return;
        UI.ok('تم تسجيل الحركة، الرصيد الجديد ' + money(r.balance));
        m.close();
        if (onDone) onDone(); else if (container) load();
      };
    }

    async function statement(id) {
      const st = await API.safe('parties.statement', { type, id });
      if (!st) return;
      const m = UI.modal({
        title: `كشف حساب - ${st.party.name}`,
        width: 'wide',
        body: `
          <div class="row wrap gap14 mb16">
            <span class="muted small">${esc(t('phone'))}: <b>${esc(st.party.phone || '-')}</b></span>
            <div class="spacer"></div>
            <span>الرصيد الحالي:
              <b class="${Math.abs(st.balance) < 0.009 ? '' : (isCust ? (st.balance > 0 ? 'danger-text' : 'ok-text') : (st.balance < 0 ? 'warn-text' : 'ok-text'))}"
                 style="font-size:17px">${money(Math.abs(st.balance))}</b></span>
          </div>
          <div id="sttbl"></div>`,
        footer: `${API.can('debts') ? `<button class="btn primary" data-pay>${Icons.wallet} ${isCust ? 'قبض' : 'دفع'}</button>` : ''}
                 <button class="btn" data-print>${Icons.print} ${esc(t('print'))}</button>
                 <div class="spacer"></div><button class="btn" data-close2>${esc(t('close'))}</button>`,
      });
      $('#sttbl', m.el).appendChild(UI.table({
        compact: true,
        columns: [
          { title: t('date'), render: (r) => UI.dateTimeStr(r.date) },
          { title: 'البيان', render: (r) => `${esc(r.note)}<div class="small muted">${esc(r.ref)}</div>` },
          { title: 'مدين', align: 'end', render: (r) => r.debit ? money(r.debit, false) : '—' },
          { title: 'دائن', align: 'end', render: (r) => r.credit ? money(r.credit, false) : '—' },
          { title: 'الرصيد', align: 'end', render: (r) => `<b>${money(r.balance, false)}</b>` },
        ],
        rows: st.entries,
        empty: 'ما فيه حركات على الحساب',
      }));
      const pb = $('[data-pay]', m.el);
      if (pb) pb.onclick = () => { m.close(); payDialog(st.party, () => { if (container) load(); }); };
      $('[data-print]', m.el).onclick = () => printStatement(st);
      $('[data-close2]', m.el).onclick = m.close;
    }

    function printStatement(st) {
      const s = API.settings;
      const rows = st.entries.map((r) => `<tr>
        <td>${esc(UI.dateStr(r.date))}</td><td>${esc(r.note)}</td>
        <td class="e">${r.debit ? money(r.debit, false) : '—'}</td>
        <td class="e">${r.credit ? money(r.credit, false) : '—'}</td>
        <td class="e"><b>${money(r.balance, false)}</b></td></tr>`).join('');
      const html = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
        @page{size:A4;margin:14mm} body{font-family:'Cairo',sans-serif;font-size:12px}
        h1{font-size:18px;text-align:center;margin:8px 0}
        table{width:100%;border-collapse:collapse;margin-top:12px}
        th{background:#f0f2f4;border:1px solid #ccc;padding:7px} td{border:1px solid #ddd;padding:6px}
        .e{text-align:end} .head{text-align:center;border-bottom:2px solid #111;padding-bottom:8px}
      </style></head><body>
        <div class="head"><div style="font-size:19px;font-weight:700">${esc(s.store_name || '')}</div>
          <div>${esc(s.phone || '')}</div></div>
        <h1>كشف حساب ${isCust ? 'عميل' : 'مورد'}</h1>
        <div><b>الاسم:</b> ${esc(st.party.name)} &nbsp;&nbsp; <b>الجوال:</b> ${esc(st.party.phone || '-')}
          &nbsp;&nbsp; <b>التاريخ:</b> ${esc(UI.dateStr(new Date().toISOString()))}</div>
        <table><thead><tr><th>التاريخ</th><th>البيان</th><th>مدين</th><th>دائن</th><th>الرصيد</th></tr></thead>
          <tbody>${rows}</tbody></table>
        <div style="margin-top:14px;text-align:end;font-size:15px"><b>الرصيد النهائي: ${money(Math.abs(st.balance))}</b></div>
      </body></html>`;
      window.baqala.print(html, { silent: false, width: 210 });
    }

    async function exportCSV() {
      const res = await API.safe('parties.list', { type, limit: 2000 });
      if (!res) return;
      const csv = UI.toCSV(res.rows.map((r) => ({
        name: r.name, phone: r.phone, vat: r.vat_number, balance: r.balance, note: r.note,
      })));
      await window.baqala.saveFile({
        defaultName: `${isCust ? 'العملاء' : 'الموردين'}-${UI.todayStr()}.csv`,
        filters: [{ name: 'CSV', extensions: ['csv'] }], content: csv,
      });
      UI.ok('تم الحفظ');
    }

    return { render, editDialog, payDialog, statement };
  }

  Pages.customers = makeParty('customer');
  Pages.suppliers = makeParty('supplier');

  /* ================================ الديون ================================ */
  Pages.debts = (() => {
    async function render(view) {
      const d = await API.safe('parties.debtSummary');
      if (!d) return;
      view.innerHTML = '';
      const el = h(`<div class="col gap14">
        <div class="grid g4">
          <div class="stat accent"><div class="lbl">لك عند العملاء</div>
            <div class="val">${money(d.customersDebt, false)}</div>
            <div class="sub">${d.customersCount} عميل</div><div class="ico-box">${Icons.credit}</div></div>
          <div class="stat"><div class="lbl">عليك للموردين</div>
            <div class="val warn-text">${money(d.suppliersDebt, false)}</div>
            <div class="sub">${d.suppliersCount} مورد</div></div>
          <div class="stat"><div class="lbl">الصافي</div>
            <div class="val ${d.customersDebt - d.suppliersDebt >= 0 ? 'ok-text' : 'danger-text'}">${money(d.customersDebt - d.suppliersDebt, false)}</div></div>
          <div class="stat"><div class="lbl">إجمالي الحركة</div><div class="val">${money(d.customersDebt + d.suppliersDebt, false)}</div></div>
        </div>
        <div class="grid g2">
          <div class="card"><div class="card-head"><h3>ديون على العملاء</h3><div class="spacer"></div>
            <button class="btn sm" id="go-c">${esc(t('customers'))}</button></div>
            <div class="card-body tight" id="dc"></div></div>
          <div class="card"><div class="card-head"><h3>مستحقات الموردين</h3><div class="spacer"></div>
            <button class="btn sm" id="go-s">${esc(t('suppliers'))}</button></div>
            <div class="card-body tight" id="ds"></div></div>
        </div>
      </div>`);
      view.appendChild(el);

      $('#dc', el).appendChild(UI.table({
        compact: true,
        columns: [
          { title: t('name'), key: 'name' },
          { title: t('phone'), render: (r) => `<span class="num">${esc(r.phone || '-')}</span>` },
          { title: 'الدين', align: 'end', render: (r) => `<b class="danger-text">${money(r.balance, false)}</b>` },
          { title: '', align: 'end', render: (r) => `<button class="btn sm" data-pc="${r.id}">${Icons.wallet} قبض</button>` },
        ],
        rows: d.topCustomers,
        empty: 'ما فيه ديون على العملاء',
      }));
      $('#ds', el).appendChild(UI.table({
        compact: true,
        columns: [
          { title: t('name'), key: 'name' },
          { title: t('phone'), render: (r) => `<span class="num">${esc(r.phone || '-')}</span>` },
          { title: 'المستحق', align: 'end', render: (r) => `<b class="warn-text">${money(r.balance, false)}</b>` },
          { title: '', align: 'end', render: (r) => `<button class="btn sm" data-ps="${r.id}">${Icons.wallet} دفع</button>` },
        ],
        rows: d.topSuppliers,
        empty: 'ما فيه مستحقات للموردين',
      }));

      $$('[data-pc]', el).forEach((b) => b.onclick = async () => {
        const p = await API.safe('parties.get', { type: 'customer', id: Number(b.dataset.pc) });
        if (p) Pages.customers.payDialog(p, () => render(view));
      });
      $$('[data-ps]', el).forEach((b) => b.onclick = async () => {
        const p = await API.safe('parties.get', { type: 'supplier', id: Number(b.dataset.ps) });
        if (p) Pages.suppliers.payDialog(p, () => render(view));
      });
      $('#go-c', el).onclick = () => App.go('customers');
      $('#go-s', el).onclick = () => App.go('suppliers');
    }
    return { render };
  })();

  /* ============================== المصروفات ============================== */
  Pages.expenses = (() => {
    const state = { from: UI.monthStart(), to: UI.todayStr(), range: 'month' };
    let container = null;
    const CATS = ['إيجار', 'كهرباء', 'ماء', 'رواتب', 'صيانة', 'نقل وتوصيل', 'مشتريات متفرقة', 'ضيافة', 'أخرى'];

    async function render(view) {
      container = view;
      view.innerHTML = '';
      const el = h(`<div>
        <div class="toolbar">
          <div id="range"></div>
          <div class="spacer"></div>
          <button class="btn primary sm" id="new">${Icons.plus} تسجيل مصروف</button>
        </div>
        <div class="grid g3 mb16" id="stats"></div>
        <div class="grid" style="grid-template-columns:1fr 320px">
          <div class="card"><div class="card-body tight" id="list"></div></div>
          <div class="card"><div class="card-head"><h3>حسب البند</h3></div><div class="card-body" id="bycat"></div></div>
        </div>
      </div>`);
      view.appendChild(el);
      $('#range', el).appendChild(UI.dateRangeBar(state, load));
      $('#new', el).onclick = () => addDialog();
      load();
    }

    async function load() {
      const res = await API.safe('expenses.list', state);
      if (!res) return;
      $('#stats', container).innerHTML = `
        <div class="stat"><div class="lbl">إجمالي المصروفات</div><div class="val danger-text" style="font-size:22px">${money(res.total, false)}</div></div>
        <div class="stat"><div class="lbl">عدد الحركات</div><div class="val">${res.count}</div></div>
        <div class="stat"><div class="lbl">متوسط المصروف</div><div class="val" style="font-size:22px">${money(res.count ? res.total / res.count : 0, false)}</div></div>`;

      const box = $('#list', container);
      box.innerHTML = '';
      box.appendChild(UI.table({
        columns: [
          { title: t('date'), render: (r) => UI.dateTimeStr(r.created_at) },
          { title: 'البند', render: (r) => `<span class="badge">${esc(r.category)}</span>` },
          { title: t('notes'), key: 'note' },
          { title: 'الموظف', key: 'user_name' },
          { title: t('amount'), align: 'end', render: (r) => `<b class="danger-text">${money(r.amount, false)}</b>` },
          { title: '', align: 'end', render: (r) => `<button class="btn ghost icon sm" data-d="${r.id}">${Icons.trash}</button>` },
        ],
        rows: res.rows,
        empty: 'ما فيه مصروفات في هذه الفترة',
      }));
      $$('[data-d]', box).forEach((b) => b.onclick = async () => {
        const ok = await UI.confirm({ title: t('delete'), message: 'حذف هذا المصروف؟' });
        if (!ok) return;
        const r = await API.safe('expenses.delete', { id: Number(b.dataset.d) });
        if (r) { UI.ok('تم الحذف'); load(); }
      });

      const max = Math.max(1, ...res.byCategory.map((c) => c.t));
      $('#bycat', container).innerHTML = res.byCategory.length ? res.byCategory.map((c) => `
        <div class="mb12">
          <div class="row" style="justify-content:space-between">
            <span class="small bold">${esc(c.category)}</span>
            <span class="small">${money(c.t, false)}</span></div>
          <div class="progress mt8"><i style="width:${(c.t / max) * 100}%"></i></div>
        </div>`).join('') : '<div class="muted small">ما فيه بيانات</div>';
    }

    function addDialog() {
      const m = UI.modal({
        title: 'تسجيل مصروف',
        width: 'narrow',
        body: `
          <div class="field mb12"><label>البند</label>
            <select class="select" id="x-c">${CATS.map((c) => `<option>${esc(c)}</option>`).join('')}</select></div>
          <div class="field mb12"><label>${esc(t('amount'))}</label><input class="input lg" id="x-a" type="number" step="0.01"></div>
          <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="x-n" placeholder="تفاصيل المصروف"></div>`,
        footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('save'))}</button>`,
      });
      $('[data-cancel]', m.el).onclick = m.close;
      $('[data-ok]', m.el).onclick = async () => {
        const amount = Number($('#x-a', m.el).value);
        if (!(amount > 0)) return UI.err('اكتب المبلغ');
        const r = await API.safe('expenses.add', { category: $('#x-c', m.el).value, amount, note: $('#x-n', m.el).value.trim() });
        if (!r) return;
        UI.ok('تم تسجيل المصروف');
        m.close();
        load();
      };
    }

    return { render, addDialog };
  })();
})();
