/* شاشة تسجيل الدخول */
Pages.login = (() => {
  const { h, $, esc } = UI;

  async function render(root, { onSuccess }) {
    const info = API.info || {};
    const cfg = info.config || { mode: 'local' };
    const modeLabel = { local: 'جهاز واحد', host: 'الجهاز الرئيسي', client: 'كاشير فرعي' }[cfg.mode] || cfg.mode;

    const el = h(`
      <div class="login-wrap">
        <div class="login-card">
          <div class="login-logo">${Icons.store}</div>
          <h2>${esc(t('app_name'))}</h2>
          <div class="sub">${esc(t('app_sub'))}</div>

          <form id="lf">
            <div class="field mb12">
              <label>${esc(t('username'))}</label>
              <input class="input lg" id="u" autocomplete="off" autofocus placeholder="admin">
            </div>
            <div class="field mb16">
              <label>${esc(t('password'))}</label>
              <input class="input lg" id="p" type="password" autocomplete="off" placeholder="••••">
            </div>
            <button class="btn primary lg block" type="submit" id="go">${esc(t('login_btn'))}</button>
          </form>

          <div class="row mt16" style="justify-content:space-between">
            <span class="small muted">${esc(modeLabel)}${cfg.mode === 'client' && cfg.serverUrl ? ' · ' + esc(cfg.serverUrl) : ''}</span>
            <button class="btn ghost sm" id="net">${Icons.server} إعداد الاتصال</button>
          </div>

          <div id="hint" class="alert-box info mt16" style="display:none"></div>
        </div>
      </div>`);

    root.appendChild(el);

    // تلميح أول تشغيل
    if (cfg.mode !== 'client') {
      const hint = $('#hint', el);
      hint.style.display = 'flex';
      hint.innerHTML = `${Icons.info}<div>أول تشغيل؟ ادخل باسم <b>admin</b> وكلمة المرور <b>1234</b> ثم غيّرها من الإعدادات.</div>`;
    }

    $('#net', el).onclick = () => networkDialog();

    $('#lf', el).onsubmit = async (e) => {
      e.preventDefault();
      const btn = $('#go', el);
      const u = $('#u', el).value.trim();
      const p = $('#p', el).value;
      if (!u || !p) return UI.warn('اكتب اسم المستخدم وكلمة المرور');
      btn.disabled = true;
      btn.innerHTML = '<span class="spin"></span>';
      try {
        await API.login(u, p);
        await onSuccess();
      } catch (err) {
        UI.err(API.msg(err));
        $('#p', el).value = '';
        $('#p', el).focus();
      } finally {
        btn.disabled = false;
        btn.textContent = t('login_btn');
      }
    };
  }

  /* ------------------------- إعداد وضع الاتصال ------------------------- */
  async function networkDialog() {
    const info = await window.baqala.info();
    const d = info.ok ? info.data : {};
    const cfg = d.config || { mode: 'local', serverPort: 7711, serverUrl: '' };
    const ips = (d.localIPs || []).map((x) => x.address);

    const m = UI.modal({
      title: 'إعداد الاتصال',
      body: `
        <div class="alert-box info mb16">${Icons.info}
          <div>اختر طريقة تشغيل البرنامج على هذا الجهاز. تقدر تغيّرها في أي وقت.</div></div>

        <label class="card mb8" style="display:block;padding:13px;cursor:pointer">
          <div class="row"><input type="radio" name="md" value="local" ${cfg.mode === 'local' ? 'checked' : ''}>
            <div><div class="bold">جهاز واحد</div>
              <div class="small muted">كل البيانات داخل هذا الجهاز. الأنسب لبقالة فيها كاشير واحد.</div></div></div>
        </label>

        <label class="card mb8" style="display:block;padding:13px;cursor:pointer">
          <div class="row"><input type="radio" name="md" value="host" ${cfg.mode === 'host' ? 'checked' : ''}>
            <div><div class="bold">الجهاز الرئيسي (سيرفر)</div>
              <div class="small muted">البيانات هنا، وبقية الكاشيرات تتصل على هذا الجهاز عبر شبكة المحل.</div></div></div>
          <div class="row gap10 mt12" style="padding-inline-start:26px">
            <div class="field" style="width:130px"><label>المنفذ</label>
              <input class="input" id="port" type="number" value="${esc(cfg.serverPort || 7711)}"></div>
            <div class="field" style="flex:1"><label>عنوان الجهاز على الشبكة</label>
              <input class="input" value="${esc(ips[0] ? ips[0] + ':' + (cfg.serverPort || 7711) : 'غير متاح')}" readonly></div>
          </div>
          ${ips.length > 1 ? `<div class="small muted mt8" style="padding-inline-start:26px">عناوين أخرى: ${esc(ips.slice(1).join('، '))}</div>` : ''}
        </label>

        <label class="card" style="display:block;padding:13px;cursor:pointer">
          <div class="row"><input type="radio" name="md" value="client" ${cfg.mode === 'client' ? 'checked' : ''}>
            <div><div class="bold">كاشير فرعي / فرع</div>
              <div class="small muted">يتصل بالجهاز الرئيسي في المحل، أو بسيرفر على الإنترنت لو عندك أكثر من فرع.</div></div></div>
          <div class="field mt12" style="padding-inline-start:26px"><label>عنوان الجهاز الرئيسي</label>
            <input class="input" id="surl" placeholder="192.168.1.10:7711" value="${esc(cfg.serverUrl || '')}">
            <span class="hint">اكتب العنوان اللي ظهر لك في الجهاز الرئيسي. للفروع عبر الإنترنت اكتب الرابط كامل.</span></div>
          <div class="row mt8" style="padding-inline-start:26px">
            <button class="btn sm" id="test">${Icons.refresh} اختبار الاتصال</button>
            <span class="small" id="test-res"></span>
          </div>
        </label>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${esc(t('save'))} وإعادة التشغيل</button>`,
      width: 'wide',
    });

    $('#test', m.el).onclick = async (e) => {
      e.preventDefault();
      const url = $('#surl', m.el).value.trim();
      const res = $('#test-res', m.el);
      if (!url) { res.innerHTML = '<span class="danger-text">اكتب العنوان أولاً</span>'; return; }
      res.textContent = 'جاري الاختبار…';
      try {
        const u = /^https?:\/\//i.test(url) ? url : 'http://' + url;
        const r = await fetch(u.replace(/\/+$/, '') + '/ping', { signal: AbortSignal.timeout(5000) });
        const j = await r.json();
        res.innerHTML = j && j.ok
          ? `<span class="ok-text">الاتصال ناجح مع «${UI.esc(j.server || 'الجهاز الرئيسي')}»</span>`
          : '<span class="danger-text">رد غير متوقع</span>';
      } catch (_) {
        res.innerHTML = '<span class="danger-text">ما قدرنا نوصل للجهاز، تأكد إنه شغّال وعلى نفس الشبكة</span>';
      }
    };

    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const mode = (m.el.querySelector('input[name=md]:checked') || {}).value || 'local';
      const patch = { mode };
      if (mode === 'host') patch.serverPort = Number($('#port', m.el).value) || 7711;
      if (mode === 'client') {
        patch.serverUrl = $('#surl', m.el).value.trim();
        if (!patch.serverUrl) return UI.err('اكتب عنوان الجهاز الرئيسي');
      }
      const r = await window.baqala.setMode(patch);
      if (!r.ok) return UI.err(r.error.ar);
      API.setSession('', null);
      UI.ok('تم الحفظ، جاري إعادة التشغيل…');
      setTimeout(() => window.baqala.relaunch(), 700);
    };
  }

  return { render, networkDialog };
})();
