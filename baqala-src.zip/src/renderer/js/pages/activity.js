/* سجل نشاط الموظفين */
Pages.activity = (() => {
  const { h, $, $$, esc, money } = UI;
  const state = { from: UI.todayStr(), to: UI.todayStr(), range: 'today', userId: 0, q: '', action: '' };
  let container = null;
  let users = [];

  const ACTION_LABELS = {
    login: 'تسجيل دخول', logout: 'تسجيل خروج', password_change: 'تغيير كلمة المرور',
    sale_create: 'فاتورة بيع', sale_return: 'إرجاع', sale_void: 'إلغاء فاتورة',
    product_create: 'إضافة صنف', product_update: 'تعديل صنف', product_delete: 'حذف صنف',
    product_disable: 'إخفاء صنف', products_import: 'استيراد أصناف',
    stock_adjust: 'تعديل كمية', category_create: 'تصنيف جديد', category_update: 'تعديل تصنيف', category_delete: 'حذف تصنيف',
    purchase_create: 'فاتورة شراء', purchase_pay: 'سداد مورد', purchase_delete: 'حذف فاتورة شراء',
    customer_create: 'عميل جديد', customer_update: 'تعديل عميل', customer_delete: 'حذف عميل', customer_disable: 'إخفاء عميل',
    supplier_create: 'مورد جديد', supplier_update: 'تعديل مورد', supplier_delete: 'حذف مورد', supplier_disable: 'إخفاء مورد',
    payment_in: 'قبض', payment_out: 'صرف',
    expense_add: 'مصروف', expense_delete: 'حذف مصروف',
    shift_open: 'فتح وردية', shift_close: 'إقفال وردية', cash_in: 'إيداع بالدرج', cash_out: 'سحب من الدرج',
    user_create: 'إضافة موظف', user_update: 'تعديل موظف', user_delete: 'حذف موظف', user_disable: 'إيقاف موظف',
    settings_update: 'تعديل إعدادات', tax_enable: 'تفعيل الضريبة', tax_disable: 'إيقاف الضريبة',
    backup_create: 'نسخة احتياطية', backup_restore: 'استعادة نسخة', data_reset: 'تصفير البيانات',
  };

  const ACTION_KIND = (a) => {
    if (['sale_void', 'product_delete', 'user_delete', 'data_reset', 'purchase_delete', 'expense_delete', 'customer_delete', 'supplier_delete'].includes(a)) return 'danger';
    if (['sale_create', 'purchase_create', 'payment_in'].includes(a)) return 'ok';
    if (['login', 'logout'].includes(a)) return '';
    if (['stock_adjust', 'settings_update', 'tax_enable', 'tax_disable', 'sale_return'].includes(a)) return 'warn';
    return 'info';
  };

  async function render(view) {
    container = view;
    users = (await API.safe('users.list', {}, { silent: true })) || [];
    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="search-box">${Icons.search}<input class="input" id="q" placeholder="ابحث في التفاصيل" value="${esc(state.q)}"></div>
        <select class="select" id="usr" style="width:170px">
          <option value="0">كل الموظفين</option>
          ${users.map((u) => `<option value="${u.id}" ${state.userId === u.id ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}
        </select>
        <select class="select" id="act" style="width:180px">
          <option value="">كل الحركات</option>
          ${Object.entries(ACTION_LABELS).map(([k, v]) => `<option value="${k}" ${state.action === k ? 'selected' : ''}>${esc(v)}</option>`).join('')}
        </select>
        <div class="spacer"></div>
        <button class="btn sm" id="ex">${Icons.download} ${esc(t('export'))}</button>
      </div>
      <div id="range" class="mb16"></div>
      <div class="card mb16"><div class="card-head"><h3>ملخص اليوم لكل موظف</h3><div class="spacer"></div>
        <input type="date" class="input" id="sday" style="width:150px" value="${esc(state.to)}"></div>
        <div class="card-body tight" id="summary"></div></div>
      <div class="card"><div class="card-head"><h3>تفاصيل الحركات</h3><div class="spacer"></div>
        <span class="small muted" id="cnt"></span></div>
        <div class="card-body tight" id="list"></div></div>
    </div>`);
    view.appendChild(el);

    $('#range', el).appendChild(UI.dateRangeBar(state, () => { load(); loadSummary(); }));
    $('#q', el).oninput = UI.debounce((e) => { state.q = e.target.value; load(); }, 260);
    $('#usr', el).onchange = (e) => { state.userId = Number(e.target.value); load(); };
    $('#act', el).onchange = (e) => { state.action = e.target.value; load(); };
    $('#sday', el).onchange = () => loadSummary();
    $('#ex', el).onclick = exportCSV;

    load();
    loadSummary();
  }

  async function loadSummary() {
    const day = $('#sday', container).value || UI.todayStr();
    const rows = await API.safe('activity.staffDay', { day });
    if (!rows) return;
    const box = $('#summary', container);
    box.innerHTML = '';
    box.appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الموظف', render: (r) => `<div class="row gap6">
            <div class="avatar" style="width:26px;height:26px;font-size:11px;background:${esc(r.user.color || UI.colorFor(r.user.name))}">${esc(UI.initials(r.user.name))}</div>
            <div class="bold" style="font-size:13px">${esc(r.user.name)}</div></div>` },
        { title: 'أول حركة', align: 'center', render: (r) => r.firstAction ? UI.timeStr(r.firstAction) : '—' },
        { title: 'آخر حركة', align: 'center', render: (r) => r.lastAction ? UI.timeStr(r.lastAction) : '—' },
        { title: 'الحركات', align: 'center', render: (r) => r.actions || '—' },
        { title: 'فواتير', align: 'center', render: (r) => r.invoices || '—' },
        { title: 'المبيعات', align: 'end', render: (r) => r.total ? money(r.total, false) : '—' },
        { title: 'إرجاع', align: 'center', render: (r) => r.returns ? `<span class="badge warn">${r.returns}</span>` : '—' },
        { title: 'إلغاء', align: 'center', render: (r) => r.voids ? `<span class="badge danger">${r.voids}</span>` : '—' },
        { title: 'فرق الصندوق', align: 'end', render: (r) => r.shift && r.shift.difference !== null && r.shift.difference !== undefined
            ? `<span class="${Math.abs(r.shift.difference) < 0.01 ? 'ok-text' : 'danger-text'} bold">${money(r.shift.difference, false)}</span>` : '—' },
      ],
      rows: rows.filter((r) => r.actions || r.invoices || r.user.active),
      empty: 'ما فيه نشاط',
    }));
  }

  async function load() {
    const res = await API.safe('activity.list', {
      ...state, userId: state.userId || undefined, action: state.action || undefined, limit: 600,
    });
    if (!res) return;
    $('#cnt', container).textContent = `${res.rows.length} من ${res.total} حركة`;
    const box = $('#list', container);
    box.innerHTML = '';
    box.appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الوقت', width: '150px', render: (r) => `${UI.timeStr(r.created_at)}<div class="small muted">${UI.dateStr(r.created_at)}</div>` },
        { title: 'الموظف', width: '150px', render: (r) => `<div class="row gap6">
            <div class="avatar" style="width:22px;height:22px;font-size:10px;background:${esc(UI.colorFor(r.user_name || ''))}">${esc(UI.initials(r.user_name || '؟'))}</div>
            <span>${esc(r.user_name || 'النظام')}</span></div>` },
        { title: 'الحركة', width: '150px', render: (r) => `<span class="badge ${ACTION_KIND(r.action)}">${esc(ACTION_LABELS[r.action] || r.action)}</span>` },
        { title: 'التفاصيل', render: (r) => esc(r.details || '') },
        { title: 'المبلغ', align: 'end', render: (r) => r.amount ? `<b>${money(r.amount, false)}</b>` : '—' },
        { title: 'الجهاز', align: 'center', render: (r) => `<span class="small muted">${esc(r.device || '')}</span>` },
      ],
      rows: res.rows,
      empty: 'ما فيه حركات بهذه الفلاتر',
    }));
  }

  async function exportCSV() {
    const res = await API.safe('activity.list', { ...state, userId: state.userId || undefined, limit: 5000 });
    if (!res) return;
    const csv = UI.toCSV(res.rows.map((r) => ({
      date: r.created_at, user: r.user_name, action: ACTION_LABELS[r.action] || r.action,
      details: r.details, amount: r.amount, device: r.device,
    })));
    await window.baqala.saveFile({
      defaultName: `سجل-النشاط-${state.from}-${state.to}.csv`,
      filters: [{ name: 'CSV', extensions: ['csv'] }], content: csv,
    });
    UI.ok('تم الحفظ');
  }

  function filterUser(userId, day) {
    state.userId = userId;
    if (day) { state.from = day; state.to = day; state.range = 'custom'; }
    if (container) render(container);
  }

  return { render, filterUser, ACTION_LABELS };
})();
