/* المشتريات وفواتير الموردين */
Pages.purchases = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  const state = { from: UI.monthStart(), to: UI.todayStr(), range: 'month', q: '', unpaid: false };
  let container = null;
  let pendingProduct = null;

  async function render(view) {
    container = view;
    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="search-box">${Icons.search}<input class="input" id="q" placeholder="رقم الفاتورة أو المورد"></div>
        <label class="check"><input type="checkbox" id="unpaid" ${state.unpaid ? 'checked' : ''}> غير مسددة فقط</label>
        <div class="spacer"></div>
        <button class="btn primary sm" id="new">${Icons.plus} فاتورة شراء جديدة</button>
      </div>
      <div id="range" class="mb16"></div>
      <div class="grid g4 mb16" id="stats"></div>
      <div class="card"><div class="card-body tight" id="list"></div></div>
    </div>`);
    view.appendChild(el);

    $('#range', el).appendChild(UI.dateRangeBar(state, load));
    $('#q', el).oninput = UI.debounce((e) => { state.q = e.target.value; load(); }, 250);
    $('#unpaid', el).onchange = (e) => { state.unpaid = e.target.checked; load(); };
    $('#new', el).onclick = () => newDialog();

    if (pendingProduct) { const p = pendingProduct; pendingProduct = null; newDialog(p); }
    load();
  }

  async function load() {
    const res = await API.safe('purchases.list', { ...state, unpaid: state.unpaid || undefined });
    if (!res) return;
    $('#stats', container).innerHTML = `
      <div class="stat"><div class="lbl">عدد الفواتير</div><div class="val">${res.total}</div></div>
      <div class="stat"><div class="lbl">إجمالي المشتريات</div><div class="val" style="font-size:21px">${money(res.sum, false)}</div></div>
      <div class="stat"><div class="lbl">المتبقي على المحل</div><div class="val warn-text" style="font-size:21px">${money(res.due, false)}</div></div>
      <div class="stat"><div class="lbl">المدفوع</div><div class="val ok-text" style="font-size:21px">${money(res.sum - res.due, false)}</div></div>`;

    const box = $('#list', container);
    box.innerHTML = '';
    box.appendChild(UI.table({
      columns: [
        { title: 'رقم الفاتورة', render: (r) => `<span class="num bold">${esc(r.invoice_no)}</span>` },
        { title: 'المورد', render: (r) => esc(r.supplier_name || '—') },
        { title: 'التاريخ', render: (r) => UI.dateStr(r.created_at) },
        { title: 'الإجمالي', align: 'end', render: (r) => moneyHTML(r.total) },
        { title: 'المدفوع', align: 'end', render: (r) => money(r.paid, false) },
        { title: 'المتبقي', align: 'end', render: (r) => {
            const rem = Number(r.total) - Number(r.paid);
            return rem > 0.009 ? `<span class="badge warn">${money(rem, false)}</span>` : '<span class="badge ok">مسددة</span>';
          } },
        { title: 'أدخلها', render: (r) => esc(r.user_name || '') },
        { title: '', align: 'end', render: (r) => {
            const rem = Number(r.total) - Number(r.paid);
            return `<div class="row gap6" style="justify-content:flex-end">
              ${rem > 0.009 ? `<button class="btn sm" data-pay="${r.id}">${Icons.wallet} سداد</button>` : ''}
              <button class="btn ghost icon sm" data-del="${r.id}">${Icons.trash}</button></div>`;
          } },
      ],
      rows: res.rows,
      onRowClick: (r) => detail(r.id),
      empty: 'ما فيه فواتير شراء في هذه الفترة',
    }));

    $$('[data-pay]', box).forEach((b) => b.onclick = () => payDialog(Number(b.dataset.pay)));
    $$('[data-del]', box).forEach((b) => b.onclick = async () => {
      const ok = await UI.confirm({ title: 'حذف الفاتورة', message: 'بيتم إرجاع الكميات من المخزون وتعديل حساب المورد. متأكد؟' });
      if (!ok) return;
      const r = await API.safe('purchases.delete', { id: Number(b.dataset.del) });
      if (r) { UI.ok('تم الحذف'); load(); App.refreshAlerts(); }
    });
  }

  /* --------------------------- فاتورة شراء جديدة --------------------------- */
  async function newDialog(prefillProduct) {
    const suppliers = (await API.safe('parties.list', { type: 'supplier', limit: 300 })) || { rows: [] };
    let lines = [];
    if (prefillProduct) {
      lines.push({ product_id: prefillProduct.id, name: prefillProduct.name_ar, barcode: prefillProduct.barcode,
        qty: 1, cost_price: prefillProduct.cost_price, sale_price: prefillProduct.sale_price, expiry_date: prefillProduct.expiry_date || '' });
    }

    const m = UI.modal({
      title: 'فاتورة شراء جديدة',
      width: 'xwide',
      body: `
        <div class="grid g4 mb16">
          <div class="field"><label>المورد</label>
            <div class="row gap6">
              <select class="select" id="sup">
                <option value="">بدون مورد</option>
                ${suppliers.rows.map((s) => `<option value="${s.id}">${esc(s.name)}</option>`).join('')}
              </select>
              <button class="btn sm icon" id="sup-new" title="مورد جديد">${Icons.plus}</button>
            </div></div>
          <div class="field"><label>رقم فاتورة المورد</label><input class="input" id="inv" placeholder="اختياري"></div>
          <div class="field"><label>التاريخ</label><input class="input" id="dt" type="date" value="${esc(UI.todayStr())}"></div>
          <div class="field"><label>تاريخ الاستحقاق</label><input class="input" id="due" type="date"></div>
        </div>

        <div class="card mb16">
          <div class="card-head"><h3>الأصناف</h3><div class="spacer"></div>
            <div class="search-box" style="max-width:300px">${Icons.search}
              <input class="input" id="psearch" placeholder="ابحث عن صنف أو امسح الباركود"></div>
            <button class="btn sm" id="add-new-prod">${Icons.plus} صنف جديد</button>
          </div>
          <div id="psug" style="display:none;max-height:200px;overflow:auto;border-bottom:1px solid var(--border)"></div>
          <div class="card-body tight" id="lines"></div>
        </div>

        <div class="grid g4">
          <div class="field"><label>خصم المورد</label><input class="input" id="disc" type="number" step="0.01" value="0"></div>
          <div class="field"><label>ضريبة الفاتورة</label><input class="input" id="tax" type="number" step="0.01" value="0"
            placeholder="0"><span class="hint">اكتبها من فاتورة المورد إن وجدت</span></div>
          <div class="field"><label>المدفوع الآن</label><input class="input" id="paid" type="number" step="0.01" value="0"></div>
          <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="note"></div>
        </div>
        <div class="card mt16" style="padding:14px" id="sum"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${Icons.check} حفظ الفاتورة</button>`,
    });

    const drawLines = () => {
      const box = $('#lines', m.el);
      box.innerHTML = '';
      if (!lines.length) { box.innerHTML = UI.emptyState('أضف أصناف الفاتورة'); return updateSum(); }
      box.appendChild(UI.table({
        compact: true,
        columns: [
          { title: 'الصنف', render: (r, i) => `<div class="bold">${esc(r.name)}</div><div class="small muted">${esc(r.barcode || 'صنف جديد')}</div>` },
          { title: 'الكمية', align: 'center', width: '110px', render: (r, i) => `<input class="input" data-q="${i}" value="${esc(r.qty)}" style="width:90px;text-align:center">` },
          { title: 'سعر الشراء', align: 'center', width: '120px', render: (r, i) => `<input class="input" data-c="${i}" value="${esc(r.cost_price)}" style="width:100px;text-align:center">` },
          { title: 'سعر البيع', align: 'center', width: '120px', render: (r, i) => `<input class="input" data-s="${i}" value="${esc(r.sale_price || '')}" style="width:100px;text-align:center">` },
          { title: 'الصلاحية', align: 'center', width: '150px', render: (r, i) => `<input class="input" type="date" data-e="${i}" value="${esc(r.expiry_date || '')}" style="width:140px">` },
          { title: 'الإجمالي', align: 'end', render: (r) => `<span class="bold">${money(r.qty * r.cost_price, false)}</span>` },
          { title: '', align: 'end', render: (r, i) => `<button class="btn ghost icon sm" data-x="${i}">${Icons.x}</button>` },
        ],
        rows: lines,
      }));
      $$('[data-q]', box).forEach((inp) => inp.onchange = () => { lines[+inp.dataset.q].qty = Number(inp.value) || 0; drawLines(); });
      $$('[data-c]', box).forEach((inp) => inp.onchange = () => { lines[+inp.dataset.c].cost_price = Number(inp.value) || 0; drawLines(); });
      $$('[data-s]', box).forEach((inp) => inp.onchange = () => { lines[+inp.dataset.s].sale_price = Number(inp.value) || 0; });
      $$('[data-e]', box).forEach((inp) => inp.onchange = () => { lines[+inp.dataset.e].expiry_date = inp.value; });
      $$('[data-x]', box).forEach((b) => b.onclick = () => { lines.splice(+b.dataset.x, 1); drawLines(); });
      updateSum();
    };

    const updateSum = () => {
      const sub = lines.reduce((s, l) => s + (Number(l.qty) || 0) * (Number(l.cost_price) || 0), 0);
      const disc = Number($('#disc', m.el).value) || 0;
      const tax = Number($('#tax', m.el).value) || 0;
      const total = Math.max(0, sub - disc) + tax;
      const paid = Number($('#paid', m.el).value) || 0;
      $('#sum', m.el).innerHTML = `
        <div class="row" style="justify-content:space-between"><span class="muted">مجموع الأصناف</span><span>${money(sub)}</span></div>
        ${disc ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الخصم</span><span class="danger-text">- ${money(disc)}</span></div>` : ''}
        ${tax ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الضريبة</span><span>${money(tax)}</span></div>` : ''}
        <div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
          <span class="bold">الإجمالي</span><span class="bold" style="font-size:19px">${money(total)}</span></div>
        <div class="row mt8" style="justify-content:space-between">
          <span class="muted">المتبقي على المحل</span>
          <span class="bold ${total - paid > 0.009 ? 'warn-text' : 'ok-text'}">${money(Math.max(0, total - paid))}</span></div>`;
    };
    ['#disc', '#tax', '#paid'].forEach((sel) => { $(sel, m.el).oninput = updateSum; });

    /* البحث عن صنف */
    const search = $('#psearch', m.el);
    const sug = $('#psug', m.el);
    const addLine = (p) => {
      const ex = lines.find((l) => l.product_id === p.id);
      if (ex) ex.qty += 1;
      else lines.push({ product_id: p.id, name: p.name_ar, barcode: p.barcode, qty: 1,
        cost_price: p.cost_price, sale_price: p.sale_price, expiry_date: p.expiry_date || '' });
      sug.style.display = 'none';
      search.value = '';
      drawLines();
      search.focus();
    };
    search.oninput = UI.debounce(async (e) => {
      const q = e.target.value.trim();
      if (q.length < 2) { sug.style.display = 'none'; return; }
      const r = await API.safe('products.list', { q, limit: 12 }, { silent: true });
      if (!r || !r.rows.length) { sug.style.display = 'none'; return; }
      sug.style.display = 'block';
      sug.innerHTML = r.rows.map((p, i) => `
        <div class="cart-row" data-ps="${i}" style="cursor:pointer">
          <div><div class="nm">${esc(p.name_ar)}</div><div class="meta">${esc(p.barcode || '')} · المتوفر ${UI.qty(p.stock)}</div></div>
          <div class="amt">${money(p.cost_price)}</div></div>`).join('');
      $$('[data-ps]', sug).forEach((d) => d.onclick = () => addLine(r.rows[+d.dataset.ps]));
    }, 240);
    search.onkeydown = async (e) => {
      if (e.key !== 'Enter') return;
      e.preventDefault();
      const code = search.value.trim();
      if (!code) return;
      const res = await API.safe('pos.scan', { code }, { silent: true });
      if (res && res.product) addLine(res.product);
      else if (res && res.suggestions && res.suggestions.length === 1) addLine(res.suggestions[0]);
    };

    $('#add-new-prod', m.el).onclick = () => {
      Pages.products.editDialog(null, (saved) => addLine(saved));
    };
    $('#sup-new', m.el).onclick = () => {
      Pages.suppliers.editDialog(null, (saved) => {
        const sel = $('#sup', m.el);
        sel.appendChild(h(`<option value="${saved.id}" selected>${esc(saved.name)}</option>`));
      });
    };

    drawLines();

    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      if (!lines.length) return UI.err('أضف صنف واحد على الأقل');
      if (lines.some((l) => !(l.qty > 0) || !(l.cost_price >= 0))) return UI.err('تأكد من الكميات والأسعار');
      const btn = $('[data-ok]', m.el);
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
      const out = await API.safe('purchases.create', {
        supplier_id: Number($('#sup', m.el).value) || null,
        invoice_no: $('#inv', m.el).value.trim(),
        day: $('#dt', m.el).value,
        due_date: $('#due', m.el).value,
        discount: Number($('#disc', m.el).value) || 0,
        tax_amount: Number($('#tax', m.el).value) || 0,
        paid: Number($('#paid', m.el).value) || 0,
        note: $('#note', m.el).value.trim(),
        items: lines,
      });
      btn.disabled = false; btn.innerHTML = t('save');
      if (!out) return;
      UI.ok(`تم حفظ فاتورة الشراء ${out.invoice_no}`);
      m.close();
      load();
      App.refreshAlerts();
    };
  }

  /* -------------------------------- التفاصيل -------------------------------- */
  async function detail(id) {
    const p = await API.safe('purchases.get', { id });
    if (!p) return;
    const rem = Number(p.total) - Number(p.paid);
    const m = UI.modal({
      title: `فاتورة شراء ${p.invoice_no}`,
      width: 'wide',
      body: `
        <div class="row wrap gap14 mb16 small">
          <span class="muted">المورد: <b>${esc(p.supplier_name || '—')}</b></span>
          <span class="muted">التاريخ: <b>${esc(UI.dateTimeStr(p.created_at))}</b></span>
          <span class="muted">أدخلها: <b>${esc(p.user_name || '')}</b></span>
          ${p.due_date ? `<span class="muted">الاستحقاق: <b>${esc(UI.dateStr(p.due_date))}</b></span>` : ''}
        </div>
        <div id="pit" class="mb16"></div>
        <div class="row" style="justify-content:flex-end">
          <div style="width:280px">
            <div class="row" style="justify-content:space-between"><span class="muted">المجموع</span><span>${money(p.subtotal)}</span></div>
            ${Number(p.discount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الخصم</span><span>- ${money(p.discount)}</span></div>` : ''}
            ${Number(p.tax_amount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الضريبة</span><span>${money(p.tax_amount)}</span></div>` : ''}
            <div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
              <span class="bold">الإجمالي</span><span class="bold">${money(p.total)}</span></div>
            <div class="row mt8" style="justify-content:space-between"><span class="muted">المدفوع</span><span class="ok-text">${money(p.paid)}</span></div>
            <div class="row mt8" style="justify-content:space-between"><span class="bold">المتبقي</span>
              <span class="bold ${rem > 0.009 ? 'warn-text' : 'ok-text'}">${money(rem)}</span></div>
          </div>
        </div>`,
      footer: `${rem > 0.009 ? `<button class="btn primary" data-pay>${Icons.wallet} سداد</button>` : ''}
               <div class="spacer"></div><button class="btn" data-close2>${esc(t('close'))}</button>`,
    });
    $('#pit', m.el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', key: 'name' },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.qty) },
        { title: 'سعر الشراء', align: 'end', render: (r) => money(r.cost_price, false) },
        { title: 'سعر البيع', align: 'end', render: (r) => r.sale_price ? money(r.sale_price, false) : '—' },
        { title: 'الصلاحية', align: 'center', render: (r) => r.expiry_date ? UI.dateStr(r.expiry_date) : '—' },
        { title: 'الإجمالي', align: 'end', render: (r) => `<b>${money(r.line_total, false)}</b>` },
      ],
      rows: p.items,
    }));
    const pb = $('[data-pay]', m.el);
    if (pb) pb.onclick = () => { m.close(); payDialog(p.id, rem); };
    $('[data-close2]', m.el).onclick = m.close;
  }

  async function payDialog(id, remaining) {
    if (remaining === undefined) {
      const p = await API.safe('purchases.get', { id });
      if (!p) return;
      remaining = Number(p.total) - Number(p.paid);
    }
    const m = UI.modal({
      title: 'سداد فاتورة شراء',
      width: 'narrow',
      body: `
        <div class="alert-box info mb16">${Icons.info}<div>المتبقي على الفاتورة: <b>${money(remaining)}</b></div></div>
        <div class="field mb12"><label>المبلغ</label><input class="input lg" id="pa" type="number" step="0.01" value="${esc(remaining)}"></div>
        <div class="field mb12"><label>طريقة الدفع</label>
          <select class="select" id="pm"><option value="cash">كاش</option><option value="bank">تحويل بنكي</option><option value="card">شبكة</option></select></div>
        <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="pn"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('confirm'))}</button>`,
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const r = await API.safe('purchases.pay', {
        id, amount: Number($('#pa', m.el).value), method: $('#pm', m.el).value, note: $('#pn', m.el).value.trim(),
      });
      if (!r) return;
      UI.ok('تم تسجيل السداد');
      m.close();
      load();
    };
  }

  function newWith(product) { pendingProduct = product; if (container) newDialog(product); }

  return { render, newDialog, newWith };
})();
