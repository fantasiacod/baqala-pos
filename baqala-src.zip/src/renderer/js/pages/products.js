/* إدارة الأصناف */
Pages.products = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  const state = { q: '', categoryId: 0, sort: 'name', filter: '', limit: 300 };
  let categories = [];
  let container = null;

  async function render(view, { topExtra }) {
    container = view;
    categories = (await API.safe('categories.list')) || [];

    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="search-box">${Icons.search}
          <input class="input" id="q" placeholder="ابحث بالاسم أو الباركود…" value="${esc(state.q)}"></div>
        <select class="select" id="cat" style="width:170px">
          <option value="0">كل التصنيفات</option>
          ${categories.map((c) => `<option value="${c.id}" ${state.categoryId === c.id ? 'selected' : ''}>${esc(c.name_ar)}</option>`).join('')}
        </select>
        <select class="select" id="flt" style="width:165px">
          <option value="">كل الأصناف</option>
          <option value="low" ${state.filter === 'low' ? 'selected' : ''}>كمية منخفضة</option>
          <option value="out" ${state.filter === 'out' ? 'selected' : ''}>منتهي من المخزون</option>
          <option value="exp" ${state.filter === 'exp' ? 'selected' : ''}>قرب انتهاء الصلاحية</option>
        </select>
        <select class="select" id="srt" style="width:140px">
          <option value="name">ترتيب بالاسم</option>
          <option value="stock" ${state.sort === 'stock' ? 'selected' : ''}>بالكمية</option>
          <option value="price" ${state.sort === 'price' ? 'selected' : ''}>بالسعر</option>
          <option value="recent" ${state.sort === 'recent' ? 'selected' : ''}>الأحدث</option>
        </select>
        <div class="spacer"></div>
        ${API.can('products_edit') ? `
          <button class="btn sm" id="cats">${Icons.list} التصنيفات</button>
          <button class="btn sm" id="imp">${Icons.upload} ${esc(t('import'))}</button>` : ''}
        <button class="btn sm" id="exp">${Icons.download} ${esc(t('export'))}</button>
        ${API.can('products_edit') ? `<button class="btn primary sm" id="new">${Icons.plus} ${esc(t('new_product'))}</button>` : ''}
      </div>
      <div class="card"><div class="card-body tight" id="list"><div class="loading-full"><span class="spin"></span></div></div></div>
    </div>`);
    view.appendChild(el);

    $('#q', el).oninput = UI.debounce((e) => { state.q = e.target.value; load(); }, 250);
    $('#cat', el).onchange = (e) => { state.categoryId = Number(e.target.value); load(); };
    $('#srt', el).onchange = (e) => { state.sort = e.target.value; load(); };
    $('#flt', el).onchange = (e) => { state.filter = e.target.value; load(); };
    const nb = $('#new', el); if (nb) nb.onclick = () => editDialog(null);
    const cb = $('#cats', el); if (cb) cb.onclick = categoriesDialog;
    const ib = $('#imp', el); if (ib) ib.onclick = importDialog;
    $('#exp', el).onclick = exportCSV;

    load();
  }

  async function load() {
    const box = $('#list', container);
    if (!box) return;
    const params = { q: state.q, categoryId: state.categoryId || undefined, sort: state.sort, limit: state.limit };
    if (state.filter === 'low') params.lowStock = true;
    if (state.filter === 'out') params.outOfStock = true;
    if (state.filter === 'exp') params.expiring = Number(API.settings.expiry_alert_days || 30);

    const res = await API.safe('products.list', params);
    if (!res) return;

    box.innerHTML = '';
    box.appendChild(UI.table({
      columns: [
        { title: 'الصنف', render: (r) => `
            <div class="bold">${esc(r.name_ar)}</div>
            <div class="small muted">${esc(r.barcode || 'بدون باركود')}${r.cat_name ? ' · ' + esc(r.cat_name) : ''}</div>` },
        { title: t('cost_price'), align: 'end', render: (r) => moneyHTML(r.cost_price) },
        { title: t('sale_price'), align: 'end', render: (r) => `<span class="bold">${money(r.sale_price)}</span>` },
        { title: 'الربح', align: 'end', render: (r) => {
            const p = Number(r.sale_price) - Number(r.cost_price);
            const pc = Number(r.cost_price) > 0 ? (p / Number(r.cost_price)) * 100 : 0;
            return `<span class="${p >= 0 ? 'ok-text' : 'danger-text'}">${money(p, false)}</span>
                    <div class="small muted num">${pc.toFixed(0)}%</div>`;
          } },
        { title: t('stock'), align: 'center', render: (r) => {
            if (!r.track_stock) return '<span class="muted small">—</span>';
            const s = Number(r.stock);
            const cls = s <= 0 ? 'danger' : (Number(r.min_stock) > 0 && s <= Number(r.min_stock)) ? 'warn' : '';
            return `<span class="badge ${cls}">${UI.qty(s)} ${esc(r.unit || '')}</span>`;
          } },
        { title: t('expiry'), align: 'center', render: (r) => {
            if (!r.expiry_date) return '<span class="muted small">—</span>';
            const exp = r.expiry_date < UI.todayStr();
            const soon = r.expiry_date <= UI.todayStr(Number(API.settings.expiry_alert_days || 30));
            return `<span class="badge ${exp ? 'danger' : soon ? 'warn' : ''}">${esc(UI.dateStr(r.expiry_date))}</span>`;
          } },
        { title: '', align: 'end', width: '120px', render: (r) => `
            <div class="row gap6" style="justify-content:flex-end">
              ${API.can('inventory') ? `<button class="btn ghost icon sm" data-adj="${r.id}" title="تعديل الكمية">${Icons.pkg}</button>` : ''}
              ${API.can('products_edit') ? `<button class="btn ghost icon sm" data-ed="${r.id}">${Icons.edit}</button>
              <button class="btn ghost icon sm" data-del="${r.id}">${Icons.trash}</button>` : ''}
            </div>` },
      ],
      rows: res.rows,
      onRowClick: (r) => detail(r.id),
      empty: state.q ? 'ما حصلنا صنف بهذا البحث' : 'ما فيه أصناف بعد — ابدأ بإضافة صنف أو استيراد ملف',
    }));

    $$('[data-ed]', box).forEach((b) => b.onclick = async () => {
      const p = await API.safe('products.get', { id: Number(b.dataset.ed) });
      if (p) editDialog(p);
    });
    $$('[data-del]', box).forEach((b) => b.onclick = async () => {
      const row = res.rows.find((x) => x.id === Number(b.dataset.del));
      const ok = await UI.confirm({ title: t('delete'), message: `حذف الصنف «${esc(row.name_ar)}»؟` });
      if (!ok) return;
      const r = await API.safe('products.delete', { id: row.id });
      if (r) { UI.ok(r.disabled ? 'تم إخفاء الصنف (له مبيعات سابقة)' : 'تم الحذف'); load(); }
    });
    $$('[data-adj]', box).forEach((b) => b.onclick = () => {
      const row = res.rows.find((x) => x.id === Number(b.dataset.adj));
      Pages.inventory.adjustDialog(row, load);
    });

    const foot = h(`<div class="row" style="padding:10px 14px;border-top:1px solid var(--border)">
      <span class="small muted">${res.rows.length} من ${res.total} صنف</span></div>`);
    box.appendChild(foot);
  }

  /* ------------------------------ التعديل ------------------------------ */
  function editDialog(p, onSaved) {
    const isNew = !p;
    p = p || { taxable: 1, track_stock: 1, price_includes_tax: 1, unit: 'حبة', stock: 0, min_stock: 0, active: 1 };
    const m = UI.modal({
      title: isNew ? t('new_product') : p.name_ar,
      width: 'wide',
      body: `
        <div class="grid g2">
          <div class="field"><label>${esc(t('name'))} *</label>
            <div class="row gap6">
              <input class="input" id="f-name" value="${esc(p.name_ar || '')}">
              <button class="btn sm icon" id="f-gen-ar" type="button" title="ترجمة من الإنجليزي">${Icons.globe}</button>
            </div></div>
          <div class="field"><label>الاسم بالإنجليزي</label>
            <div class="row gap6">
              <input class="input" id="f-name-en" value="${esc(p.name_en || '')}">
              <button class="btn sm icon" id="f-gen-en" type="button" title="ترجمة من العربي">${Icons.globe}</button>
            </div>
            <span class="hint">يتعبّى تلقائياً وأنت تكتب الاسم بالعربي — وتقدر تعدّله</span></div>
          <div class="field"><label>${esc(t('barcode'))}</label>
            <div class="row gap6"><input class="input" id="f-bc" value="${esc(p.barcode || '')}" placeholder="امسح الباركود هنا">
              <button class="btn sm" id="f-gen" title="توليد رقم">${Icons.barcode}</button></div></div>
          <div class="field"><label>${esc(t('category'))}</label>
            <select class="select" id="f-cat">
              <option value="">بدون تصنيف</option>
              ${categories.map((c) => `<option value="${c.id}" ${Number(p.category_id) === c.id ? 'selected' : ''}>${esc(c.name_ar)}</option>`).join('')}
            </select></div>
          <div class="field"><label>${esc(t('cost_price'))}</label>
            <input class="input" id="f-cost" type="number" step="0.01" value="${esc(p.cost_price || 0)}"></div>
          <div class="field"><label>${esc(t('sale_price'))} *</label>
            <input class="input" id="f-price" type="number" step="0.01" value="${esc(p.sale_price || 0)}"></div>
          <div class="field"><label>${esc(t('unit'))}</label>
            <input class="input" id="f-unit" value="${esc(p.unit || 'حبة')}" list="units">
            <datalist id="units"><option>حبة</option><option>كرتون</option><option>كيلو</option><option>جرام</option>
              <option>لتر</option><option>علبة</option><option>كيس</option><option>ربطة</option></datalist></div>
          <div class="field"><label>${esc(t('expiry'))}</label>
            <input class="input" id="f-exp" type="date" value="${esc(p.expiry_date || '')}"></div>
          <div class="field"><label>${esc(t('stock'))} ${isNew ? '(الرصيد الافتتاحي)' : ''}</label>
            <input class="input" id="f-stock" type="number" step="0.001" value="${esc(p.stock || 0)}" ${!isNew && !API.can('inventory') ? 'disabled' : ''}></div>
          <div class="field"><label>${esc(t('min_stock'))}</label>
            <input class="input" id="f-min" type="number" step="0.001" value="${esc(p.min_stock || 0)}">
            <span class="hint">ينبهك البرنامج لما تقل الكمية عن هذا الرقم</span></div>
        </div>
        <div class="divider"></div>
        <div class="row wrap gap14">
          <label class="switch"><input type="checkbox" id="f-tax" ${Number(p.taxable) ? 'checked' : ''}><span class="track"></span>
            <span>${esc(t('taxable'))}</span></label>
          <label class="switch"><input type="checkbox" id="f-track" ${Number(p.track_stock) ? 'checked' : ''}><span class="track"></span>
            <span>يتابع الكمية في المخزون</span></label>
          <label class="switch"><input type="checkbox" id="f-active" ${Number(p.active) !== 0 ? 'checked' : ''}><span class="track"></span>
            <span>صنف فعّال</span></label>
        </div>
        <div class="field mt12"><label>${esc(t('notes'))}</label>
          <input class="input" id="f-note" value="${esc(p.note || '')}"></div>
        <div id="profit-hint" class="alert-box info mt12" style="display:none"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${esc(t('save'))}</button>`,
    });

    // ربط الاسم العربي بالإنجليزي: الكتابة في أي خانة تملأ الثانية فوراً
    Translit.bindPair($('#f-name', m.el), $('#f-name-en', m.el), {
      regenEn: $('#f-gen-en', m.el),
      regenAr: $('#f-gen-ar', m.el),
    });

    const upd = () => {
      const c = Number($('#f-cost', m.el).value) || 0;
      const s = Number($('#f-price', m.el).value) || 0;
      const box = $('#profit-hint', m.el);
      if (c > 0 && s > 0) {
        const pr = s - c;
        const pc = (pr / c) * 100;
        box.style.display = 'flex';
        box.innerHTML = `${Icons.chart}<div>الربح على الحبة <b>${money(pr)}</b> — نسبة <b>${pc.toFixed(1)}%</b>${pr < 0 ? ' <span class="danger-text">(بيع بخسارة!)</span>' : ''}</div>`;
      } else box.style.display = 'none';
    };
    $('#f-cost', m.el).oninput = upd;
    $('#f-price', m.el).oninput = upd;
    upd();

    $('#f-gen', m.el).onclick = () => {
      $('#f-bc', m.el).value = '2' + String(Date.now()).slice(-11);
    };

    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const payload = {
        id: p.id || 0,
        name_ar: $('#f-name', m.el).value.trim(),
        name_en: $('#f-name-en', m.el).value.trim(),
        barcode: $('#f-bc', m.el).value.trim(),
        category_id: Number($('#f-cat', m.el).value) || null,
        cost_price: Number($('#f-cost', m.el).value) || 0,
        sale_price: Number($('#f-price', m.el).value) || 0,
        unit: $('#f-unit', m.el).value.trim(),
        expiry_date: $('#f-exp', m.el).value,
        min_stock: Number($('#f-min', m.el).value) || 0,
        taxable: $('#f-tax', m.el).checked,
        track_stock: $('#f-track', m.el).checked,
        active: $('#f-active', m.el).checked,
        note: $('#f-note', m.el).value.trim(),
      };
      const stockInput = $('#f-stock', m.el);
      if (!stockInput.disabled) payload.stock = Number(stockInput.value) || 0;
      if (!payload.name_ar) return UI.err('اكتب اسم الصنف');
      if (!(payload.sale_price > 0)) return UI.err('اكتب سعر البيع');

      const saved = await API.safe('products.save', payload);
      if (!saved) return;
      UI.ok(isNew ? 'تم إضافة الصنف' : 'تم حفظ التعديلات');
      m.close();
      if (onSaved) onSaved(saved); else load();
      App.refreshAlerts();
    };
  }

  /* ------------------------------ التفاصيل ------------------------------ */
  async function detail(id) {
    const p = await API.safe('products.get', { id });
    if (!p) return;
    const moves = API.can('inventory') ? (await API.safe('products.moves', { productId: id, limit: 50 })) || [] : [];
    const reasonAr = { sale: 'بيع', return: 'إرجاع', purchase: 'شراء', adjust: 'تسوية', damage: 'تالف', open: 'رصيد افتتاحي' };

    const m = UI.modal({
      title: p.name_ar,
      width: 'wide',
      body: `
        <div class="grid g4 mb16">
          <div class="stat"><div class="lbl">${esc(t('stock'))}</div>
            <div class="val" style="font-size:20px">${UI.qty(p.stock)} <small>${esc(p.unit || '')}</small></div></div>
          <div class="stat"><div class="lbl">${esc(t('sale_price'))}</div><div class="val" style="font-size:20px">${money(p.sale_price, false)}</div></div>
          <div class="stat"><div class="lbl">${esc(t('cost_price'))}</div><div class="val" style="font-size:20px">${money(p.cost_price, false)}</div></div>
          <div class="stat"><div class="lbl">قيمة المخزون</div><div class="val" style="font-size:20px">${money(p.stock * p.cost_price, false)}</div></div>
        </div>
        <div class="row wrap gap10 mb16 small muted">
          <span>${esc(t('barcode'))}: <b class="num">${esc(p.barcode || '-')}</b></span>
          <span>${esc(t('category'))}: <b>${esc(p.cat_name || '-')}</b></span>
          <span>${esc(t('expiry'))}: <b>${esc(p.expiry_date ? UI.dateStr(p.expiry_date) : '-')}</b></span>
          <span>${esc(t('taxable'))}: <b>${Number(p.taxable) ? 'نعم' : 'لا'}</b></span>
        </div>
        ${moves.length ? `<div class="bold mb8">آخر حركات المخزون</div><div id="mv"></div>` : ''}`,
      footer: `${API.can('products_edit') ? `<button class="btn" data-edit>${Icons.edit} ${esc(t('edit'))}</button>` : ''}
               <div class="spacer"></div><button class="btn primary" data-close2>${esc(t('close'))}</button>`,
    });

    if (moves.length) {
      $('#mv', m.el).appendChild(UI.table({
        compact: true,
        columns: [
          { title: 'التاريخ', render: (r) => UI.dateTimeStr(r.created_at) },
          { title: 'الحركة', render: (r) => esc(reasonAr[r.reason] || r.reason) },
          { title: 'التغيير', align: 'center', render: (r) => `<span class="${r.qty_change > 0 ? 'ok-text' : 'danger-text'} bold num">${r.qty_change > 0 ? '+' : ''}${UI.qty(r.qty_change)}</span>` },
          { title: 'الرصيد بعدها', align: 'center', render: (r) => UI.qty(r.balance_after) },
          { title: 'الموظف', key: 'user_name' },
          { title: 'ملاحظة', key: 'note' },
        ],
        rows: moves,
      }));
    }
    const eb = $('[data-edit]', m.el);
    if (eb) eb.onclick = () => { m.close(); editDialog(p); };
    $('[data-close2]', m.el).onclick = m.close;
  }

  /* ------------------------------ التصنيفات ----------------------------- */
  function categoriesDialog() {
    const m = UI.modal({
      title: 'التصنيفات',
      body: `<div id="cl"></div>
        <div class="divider"></div>
        <div class="row gap6">
          <input class="input" id="nc" placeholder="اسم تصنيف جديد">
          <input type="color" class="input" id="ncc" value="#0f9d58" style="width:56px;padding:4px">
          <button class="btn primary" id="nca">${esc(t('add'))}</button>
        </div>`,
      footer: null,
    });
    const draw = async () => {
      categories = (await API.safe('categories.list')) || [];
      $('#cl', m.el).innerHTML = categories.map((c) => `
        <div class="row" style="padding:7px 0;border-bottom:1px solid var(--border)">
          <span style="width:14px;height:14px;border-radius:4px;background:${esc(c.color || '#ccc')}"></span>
          <span class="bold">${esc(c.name_ar)}</span>
          <div class="spacer"></div>
          <button class="btn ghost icon sm" data-cd="${c.id}">${Icons.trash}</button>
        </div>`).join('') || '<div class="muted small">ما فيه تصنيفات</div>';
      $$('[data-cd]', m.el).forEach((b) => b.onclick = async () => {
        const r = await API.safe('categories.delete', { id: Number(b.dataset.cd) });
        if (r) { UI.ok('تم الحذف'); draw(); }
      });
    };
    draw();
    $('#nca', m.el).onclick = async () => {
      const name = $('#nc', m.el).value.trim();
      if (!name) return;
      const r = await API.safe('categories.save', { name_ar: name, color: $('#ncc', m.el).value });
      if (r) { $('#nc', m.el).value = ''; draw(); }
    };
  }

  /* --------------------------- استيراد وتصدير --------------------------- */
  async function exportCSV() {
    const rows = await API.safe('products.export');
    if (!rows) return;
    const csv = UI.toCSV(rows, [
      { key: 'barcode', title: 'barcode' }, { key: 'name_ar', title: 'name_ar' },
      { key: 'name_en', title: 'name_en' }, { key: 'category', title: 'category' },
      { key: 'unit', title: 'unit' }, { key: 'cost_price', title: 'cost_price' },
      { key: 'sale_price', title: 'sale_price' }, { key: 'stock', title: 'stock' },
      { key: 'min_stock', title: 'min_stock' }, { key: 'expiry_date', title: 'expiry_date' },
      { key: 'taxable', title: 'taxable' },
    ]);
    const r = await window.baqala.saveFile({
      defaultName: `اصناف-${UI.todayStr()}.csv`,
      filters: [{ name: 'CSV', extensions: ['csv'] }],
      content: csv,
    });
    if (r.ok && !r.data.canceled) UI.ok('تم حفظ الملف');
  }

  function importDialog() {
    const m = UI.modal({
      title: t('import') + ' أصناف من ملف Excel/CSV',
      width: 'wide',
      body: `
        <div class="alert-box info mb16">${Icons.info}<div>
          احفظ ملف الإكسل بصيغة CSV، ولازم يكون فيه صف عناوين بهذه الأسماء:<br>
          <code>barcode, name_ar, sale_price, cost_price, stock, min_stock, unit, expiry_date</code><br>
          الصنف اللي له نفس الباركود بيتحدّث، والجديد بينضاف.</div></div>
        <button class="btn block mb16" id="pick">${Icons.upload} اختر ملف CSV</button>
        <div id="prev"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok disabled>${esc(t('import'))}</button>`,
    });
    let rows = [];
    $('#pick', m.el).onclick = async () => {
      const r = await window.baqala.openFile({ filters: [{ name: 'CSV', extensions: ['csv', 'txt'] }] });
      if (!r.ok || r.data.canceled) return;
      rows = UI.parseCSV(r.data.content);
      if (!rows.length) return UI.err('الملف فاضي أو غير صحيح');
      $('#prev', m.el).innerHTML = '';
      $('#prev', m.el).appendChild(h(`<div class="bold mb8">معاينة أول ٥ صفوف من ${rows.length}</div>`));
      $('#prev', m.el).appendChild(UI.table({
        compact: true,
        columns: Object.keys(rows[0]).slice(0, 7).map((k) => ({ title: k, key: k })),
        rows: rows.slice(0, 5),
      }));
      $('[data-ok]', m.el).disabled = false;
    };
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const btn = $('[data-ok]', m.el);
      btn.disabled = true; btn.innerHTML = '<span class="spin"></span>';
      const res = await API.safe('products.import', { rows });
      btn.disabled = false; btn.textContent = t('import');
      if (!res) return;
      UI.ok(`تم: ${res.created} جديد، ${res.updated} محدّث${res.failed ? `، ${res.failed} فشل` : ''}`);
      if (res.errors.length) {
        UI.modal({ title: 'أخطاء الاستيراد', body: res.errors.map((e) => `<div class="small">${esc(e)}</div>`).join(''), footer: null });
      }
      m.close();
      load();
    };
  }

  return { render, editDialog, reload: load };
})();
