/* شاشة الكاشير */
Pages.pos = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;

  let cart = [];          // {product_id,name,barcode,unit,qty,price,cost_price,taxable,discount,stock}
  let held = [];          // فواتير معلّقة
  let customer = null;
  let discount = { amount: 0, percent: 0 };
  let payMethod = 'cash';
  let received = { cash: 0, card: 0 };
  let calc = null;
  let categories = [];
  let activeCat = 0;
  let quickProducts = [];
  let root = null;
  let isReturn = false;

  /* ------------------------------ العرض ------------------------------ */
  async function render(view) {
    root = view;
    view.innerHTML = '';
    const el = h(`
      <div class="pos">
        <div class="pos-left">
          <div class="scan-bar">
            <input class="scan-input" id="scan" placeholder="${esc(t('scan_hint'))}" autocomplete="off">
            <button class="btn icon" id="btn-search" title="بحث">${Icons.search}</button>
            <button class="btn icon" id="btn-manual" title="${esc(t('add_manual'))}">${Icons.plus}</button>
          </div>
          <div id="suggest" style="display:none;max-height:260px;overflow:auto;border-bottom:1px solid var(--border);background:var(--surface)"></div>
          <div class="cart-items" id="cart"></div>
          <div class="totals" id="totals"></div>
        </div>
        <div class="pos-right">
          <div class="seg" style="margin:12px 12px 0">
            <button data-tab="items" class="active">الأصناف السريعة</button>
            <button data-tab="pay">${esc(t('pay'))} <kbd>F8</kbd></button>
          </div>
          <div id="panel" style="flex:1;overflow:hidden;display:flex;flex-direction:column"></div>
        </div>
      </div>`);
    view.appendChild(el);

    $$('[data-tab]', el).forEach((b) => {
      b.onclick = () => {
        $$('[data-tab]', el).forEach((x) => x.classList.toggle('active', x === b));
        b.dataset.tab === 'pay' ? renderPay() : renderItems();
      };
    });

    $('#btn-manual', el).onclick = manualItem;
    $('#btn-search', el).onclick = () => { $('#scan').focus(); };

    const scan = $('#scan', el);
    scan.onkeydown = onScanKey;
    scan.oninput = UI.debounce(onScanInput, 220);

    if (!window.__posKeysBound) { window.__posKeysBound = true; document.addEventListener('keydown', hotkeys); }

    categories = (await API.safe('categories.list')) || [];
    await loadQuick();
    renderItems();
    renderCart();
    focusScan();
  }

  function focusScan() {
    setTimeout(() => { const s = $('#scan'); if (s) s.focus(); }, 40);
  }

  function hotkeys(e) {
    if (!document.querySelector('.pos')) return;
    if (document.querySelector('.modal-backdrop')) return;
    if (e.key === 'F8') { e.preventDefault(); openPayTab(); }
    if (e.key === 'F9') { e.preventDefault(); holdCart(); }
    if (e.key === 'F10') { e.preventDefault(); reprintLast(); }
    if (e.key === 'Escape') { const s = $('#scan'); if (s) { s.value = ''; hideSuggest(); s.focus(); } }
  }

  function openPayTab() {
    const b = document.querySelector('[data-tab="pay"]');
    if (b) b.click();
  }

  /* ------------------------------ المسح ------------------------------ */
  async function onScanKey(e) {
    if (e.key !== 'Enter') return;
    e.preventDefault();
    const v = e.target.value.trim();
    if (!v) { openPayTab(); return; }

    // كمية سريعة: 3*باركود  أو  3x
    let qtyMul = 1;
    let code = v;
    const m = v.match(/^(\d+(?:\.\d+)?)\s*[*xX]\s*(.+)$/);
    if (m) { qtyMul = Number(m[1]); code = m[2].trim(); }

    const res = await API.safe('pos.scan', { code });
    e.target.value = '';
    if (!res) return;
    if (res.product) {
      addToCart(res.product, (res.qty || 1) * qtyMul, res.priceOverride);
      hideSuggest();
    } else if (res.suggestions && res.suggestions.length === 1) {
      addToCart(res.suggestions[0], qtyMul);
      hideSuggest();
    } else if (res.suggestions && res.suggestions.length) {
      showSuggest(res.suggestions, qtyMul);
    } else {
      UI.warn(t('item_not_found') + ': ' + code);
      hideSuggest();
    }
  }

  async function onScanInput(e) {
    const v = e.target.value.trim();
    if (v.length < 2 || /^\d{6,}$/.test(v)) return hideSuggest();
    const res = await API.safe('products.list', { q: v, limit: 12 }, { silent: true });
    if (!res || !res.rows.length) return hideSuggest();
    showSuggest(res.rows, 1);
  }

  function showSuggest(rows, qtyMul) {
    const box = $('#suggest');
    if (!box) return;
    box.style.display = 'block';
    box.innerHTML = rows.map((p, i) => `
      <div class="cart-row" data-s="${i}" style="cursor:pointer">
        <div><div class="nm">${esc(p.name_ar)}</div>
          <div class="meta">${esc(p.barcode || '')} ${p.track_stock ? `· متوفر ${esc(UI.qty(p.stock))}` : ''}</div></div>
        <div class="amt">${moneyHTML(p.sale_price)}</div>
      </div>`).join('');
    $$('[data-s]', box).forEach((d) => {
      d.onclick = () => { addToCart(rows[Number(d.dataset.s)], qtyMul || 1); hideSuggest(); $('#scan').value = ''; focusScan(); };
    });
  }

  function hideSuggest() {
    const box = $('#suggest');
    if (box) { box.style.display = 'none'; box.innerHTML = ''; }
  }

  /* ------------------------------ السلة ------------------------------ */
  function addToCart(p, qty = 1, priceOverride) {
    const price = priceOverride || p.sale_price;
    const existing = cart.find((c) => c.product_id === p.id && c.price === price);
    if (existing) {
      existing.qty = Number((existing.qty + qty).toFixed(3));
    } else {
      cart.push({
        product_id: p.id, name: p.name_ar, barcode: p.barcode, unit: p.unit,
        qty: Number(qty.toFixed(3)), price, cost_price: p.cost_price,
        taxable: p.taxable, discount: 0, stock: p.stock, track_stock: p.track_stock,
      });
    }
    if (!isReturn && p.track_stock) {
      const total = cart.filter((c) => c.product_id === p.id).reduce((s, c) => s + c.qty, 0);
      if (total > Number(p.stock) && API.settings.negative_stock !== '1') {
        UI.warn(`المتوفر من «${p.name_ar}» ${UI.qty(p.stock)} فقط`);
      }
    }
    renderCart(p.id);
  }

  function removeLine(i) { cart.splice(i, 1); renderCart(); }

  function setQty(i, q) {
    const n = Number(q);
    if (!Number.isFinite(n) || n <= 0) return removeLine(i);
    cart[i].qty = Number(n.toFixed(3));
    renderCart();
  }

  async function renderCart(highlightId) {
    const box = $('#cart');
    if (!box) return;
    if (!cart.length) {
      box.innerHTML = UI.emptyState(t('cart_empty'), Icons.cart);
      $('#totals').innerHTML = totalsHTML({ subtotal: 0, taxAmount: 0, total: 0, discount: 0 });
      calc = null;
      if (document.querySelector('[data-tab="pay"].active')) renderPay();
      return;
    }

    box.innerHTML = cart.map((c, i) => `
      <div class="cart-row ${highlightId === c.product_id ? 'hl' : ''}" data-i="${i}">
        <div>
          <div class="nm">${esc(c.name)}</div>
          <div class="meta">${moneyHTML(c.price)} / ${esc(c.unit || 'حبة')}${c.discount ? ` · خصم ${money(c.discount)}` : ''}</div>
        </div>
        <div class="row gap6">
          <div class="qty-ctl">
            <button data-dec="${i}">−</button>
            <input data-q="${i}" value="${esc(UI.qty(c.qty))}">
            <button data-inc="${i}">+</button>
          </div>
          <div class="amt" style="min-width:86px">${moneyHTML(c.price * c.qty - c.discount, false)}</div>
          <button class="btn ghost icon sm" data-del="${i}">${Icons.x}</button>
        </div>
      </div>`).join('');

    $$('[data-inc]', box).forEach((b) => b.onclick = () => setQty(+b.dataset.inc, cart[+b.dataset.inc].qty + 1));
    $$('[data-dec]', box).forEach((b) => b.onclick = () => setQty(+b.dataset.dec, cart[+b.dataset.dec].qty - 1));
    $$('[data-del]', box).forEach((b) => b.onclick = () => removeLine(+b.dataset.del));
    $$('[data-q]', box).forEach((inp) => {
      inp.onchange = () => setQty(+inp.dataset.q, inp.value);
      inp.onkeydown = (e) => { if (e.key === 'Enter') { inp.blur(); focusScan(); } };
      inp.onfocus = () => inp.select();
    });
    $$('.cart-row', box).forEach((row) => {
      row.ondblclick = (e) => { if (!e.target.closest('button,input')) lineOptions(+row.dataset.i); };
    });

    box.scrollTop = box.scrollHeight;
    await recalc();
  }

  async function recalc() {
    const res = await API.safe('pos.preview', {
      items: cart.map((c) => ({ ...c })),
      discountAmount: discount.amount, discountPercent: discount.percent,
    }, { silent: true });
    if (!res) return;
    calc = res;
    $('#totals').innerHTML = totalsHTML(res);
    if (document.querySelector('[data-tab="pay"].active')) renderPay();
  }

  function totalsHTML(c) {
    const taxOn = API.settings.tax_enabled === '1';
    return `
      <div class="line"><span>${esc(t('subtotal'))} (${cart.length} صنف)</span><span>${moneyHTML(c.subtotal)}</span></div>
      ${Number(c.discount) > 0 ? `<div class="line"><span>${esc(t('discount'))}</span><span class="danger-text">- ${moneyHTML(c.discount, false)}</span></div>` : ''}
      ${taxOn ? `<div class="line"><span>${esc(t('vat'))} <span class="num">${esc(API.settings.tax_rate || 15)}%</span></span><span>${moneyHTML(c.taxAmount)}</span></div>` : ''}
      <div class="line grand"><span>${esc(t('grand_total'))}</span><span>${moneyHTML(c.total)}</span></div>`;
  }

  function lineOptions(i) {
    const c = cart[i];
    if (!c) return;
    const canPrice = API.can('products_edit');
    const canDisc = API.can('sale_discount');
    const m = UI.modal({
      title: c.name,
      width: 'narrow',
      body: `
        <div class="field mb12"><label>${esc(t('qty'))}</label>
          <input class="input lg" id="l-q" value="${esc(UI.qty(c.qty))}"></div>
        <div class="field mb12"><label>${esc(t('price'))} ${canPrice ? '' : '(للاطلاع)'}</label>
          <input class="input" id="l-p" value="${esc(c.price)}" ${canPrice ? '' : 'disabled'}></div>
        <div class="field"><label>خصم على السطر</label>
          <input class="input" id="l-d" value="${esc(c.discount || 0)}" ${canDisc ? '' : 'disabled'}></div>`,
      footer: `<button class="btn danger" data-rm>${esc(t('delete'))}</button>
               <div class="spacer"></div>
               <button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${esc(t('save'))}</button>`,
    });
    $('[data-rm]', m.el).onclick = () => { removeLine(i); m.close(); };
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = () => {
      const q = Number($('#l-q', m.el).value);
      if (!(q > 0)) return UI.err('كمية غير صحيحة');
      c.qty = Number(q.toFixed(3));
      if (canPrice) c.price = Number($('#l-p', m.el).value) || c.price;
      if (canDisc) c.discount = Math.max(0, Number($('#l-d', m.el).value) || 0);
      m.close();
      renderCart();
      focusScan();
    };
  }

  function manualItem() {
    const m = UI.modal({
      title: t('add_manual'),
      width: 'narrow',
      body: `
        <div class="field mb12"><label>${esc(t('name'))}</label><input class="input" id="mi-n" placeholder="صنف متنوع"></div>
        <div class="field mb12"><label>${esc(t('price'))}</label><input class="input lg" id="mi-p" type="number" step="0.01"></div>
        <div class="field"><label>${esc(t('qty'))}</label><input class="input" id="mi-q" value="1"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('add'))}</button>`,
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = () => {
      const name = $('#mi-n', m.el).value.trim() || 'صنف متنوع';
      const price = Number($('#mi-p', m.el).value);
      const q = Number($('#mi-q', m.el).value) || 1;
      if (!(price > 0)) return UI.err('اكتب السعر');
      cart.push({ product_id: null, name, barcode: '', unit: 'حبة', qty: q, price, cost_price: 0, taxable: 1, discount: 0 });
      m.close(); renderCart(); focusScan();
    };
  }

  /* --------------------------- الأصناف السريعة --------------------------- */
  async function loadQuick() {
    const res = await API.safe('products.list', { limit: 200, categoryId: activeCat || undefined, sort: 'name' }, { silent: true });
    quickProducts = res ? res.rows : [];
  }

  function renderItems() {
    const panel = $('#panel');
    if (!panel) return;
    panel.innerHTML = '';
    const tabs = h(`<div class="cat-tabs">
      <button class="cat-tab ${!activeCat ? 'active' : ''}" data-c="0">${esc(t('all'))}</button>
      ${categories.map((c) => `<button class="cat-tab ${activeCat === c.id ? 'active' : ''}" data-c="${c.id}">${esc(c.name_ar)}</button>`).join('')}
    </div>`);
    const grid = h(`<div class="pos-grid" id="qgrid"></div>`);
    panel.appendChild(tabs);
    panel.appendChild(grid);

    $$('[data-c]', tabs).forEach((b) => {
      b.onclick = async () => { activeCat = Number(b.dataset.c); await loadQuick(); renderItems(); };
    });

    grid.innerHTML = quickProducts.length ? quickProducts.map((p, i) => `
      <button class="prod-card ${p.track_stock && p.stock <= 0 ? 'oos' : ''}" data-p="${i}">
        <div class="nm">${esc(p.name_ar)}</div>
        <div class="pr">${moneyHTML(p.sale_price, false)}</div>
        <div class="st">${p.track_stock ? 'المتوفر ' + esc(UI.qty(p.stock)) : 'بدون مخزون'}</div>
      </button>`).join('') : UI.emptyState('ما فيه أصناف في هذا التصنيف');

    $$('[data-p]', grid).forEach((b) => {
      b.onclick = () => { addToCart(quickProducts[Number(b.dataset.p)], 1); focusScan(); };
    });
  }

  /* ------------------------------ الدفع ------------------------------ */
  function renderPay() {
    const panel = $('#panel');
    if (!panel) return;
    const total = calc ? calc.total : 0;
    const paid = Number(received.cash || 0) + Number(received.card || 0);
    const change = Math.max(0, paid - total);
    const creditAmt = payMethod === 'credit' ? Math.max(0, total - paid) : 0;

    panel.innerHTML = '';
    const el = h(`
      <div style="flex:1;overflow-y:auto;padding:14px;display:flex;flex-direction:column;gap:12px">
        ${isReturn ? `<div class="alert-box warn">${Icons.warning}<div>وضع الإرجاع مفعّل — الأصناف ترجع للمخزون والمبلغ يُرد للعميل.</div></div>` : ''}

        <div class="row gap6">
          <button class="btn sm" id="p-cust">${Icons.user} ${esc(customer ? customer.name : t('walk_in'))}</button>
          ${customer ? `<button class="btn ghost icon sm" id="p-cust-x">${Icons.x}</button>` : ''}
          <div class="spacer"></div>
          <button class="btn sm ${isReturn ? 'danger' : 'ghost'}" id="p-ret">${esc(t('return_invoice'))}</button>
        </div>

        <div class="pay-grid">
          <button class="pay-btn ${payMethod === 'cash' ? 'active' : ''}" data-pm="cash">${Icons.cash}${esc(t('cash'))}</button>
          <button class="pay-btn ${payMethod === 'card' ? 'active' : ''}" data-pm="card">${Icons.card}${esc(t('card'))}</button>
          <button class="pay-btn ${payMethod === 'credit' ? 'active' : ''}" data-pm="credit">${Icons.credit}${esc(t('credit'))}</button>
        </div>

        <div class="field">
          <label>${esc(t('received'))}</label>
          <input class="input lg" id="p-recv" inputmode="decimal"
                 value="${received.cash || received.card ? esc(paid) : ''}" placeholder="${esc(money(total, false))}">
        </div>

        <div class="row gap6 quick-amounts">
          ${[total, 5, 10, 20, 50, 100, 200, 500].filter((v, i, a) => a.indexOf(v) === i && v > 0)
            .slice(0, 6).map((v) => `<button class="btn sm" data-quick="${v}">${esc(money(v, false))}</button>`).join('')}
        </div>

        <div class="keypad">
          ${[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => `<button data-k="${n}">${n}</button>`).join('')}
          <button data-k=".">.</button><button data-k="0">0</button><button data-k="del">⌫</button>
        </div>

        <div class="card" style="padding:12px">
          <div class="row" style="justify-content:space-between"><span class="muted">${esc(t('grand_total'))}</span>
            <span class="bold" style="font-size:19px">${moneyHTML(total)}</span></div>
          <div class="row mt8" style="justify-content:space-between"><span class="muted">${esc(t('received'))}</span>
            <span>${moneyHTML(paid)}</span></div>
          ${creditAmt > 0 ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">على الحساب</span>
            <span class="warn-text bold">${moneyHTML(creditAmt)}</span></div>` : ''}
          <div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
            <span class="bold">${esc(t('change'))}</span>
            <span class="bold ok-text" style="font-size:19px">${moneyHTML(change)}</span></div>
        </div>

        <div class="row gap6">
          <button class="btn sm" id="p-disc">${Icons.tag} ${esc(t('discount'))}</button>
          <button class="btn sm" id="p-hold">${Icons.save} ${esc(t('hold'))} <kbd>F9</kbd></button>
          <button class="btn sm" id="p-clear">${Icons.trash} ${esc(t('clear_cart'))}</button>
        </div>

        <button class="btn primary lg block" id="p-go" ${!cart.length ? 'disabled' : ''}>
          ${Icons.check} ${esc(isReturn ? 'تأكيد الإرجاع' : t('complete_sale'))} — ${esc(money(total))}
        </button>
        <button class="btn ghost block" id="p-last">${Icons.print} ${esc(t('reprint'))} <kbd>F10</kbd></button>
        ${held.length ? `<button class="btn block" id="p-held">${Icons.list} فواتير معلّقة (${held.length})</button>` : ''}
      </div>`);
    panel.appendChild(el);

    $$('[data-pm]', el).forEach((b) => b.onclick = () => {
      payMethod = b.dataset.pm;
      if (payMethod === 'card') { received.card = total; received.cash = 0; }
      else if (payMethod === 'cash') { received.card = 0; }
      else { received.cash = 0; received.card = 0; }
      renderPay();
    });

    const recv = $('#p-recv', el);
    recv.oninput = () => {
      const v = Number(recv.value) || 0;
      if (payMethod === 'card') { received.card = v; received.cash = 0; }
      else { received.cash = v; received.card = 0; }
      updatePaySummary();
    };
    recv.onkeydown = (e) => { if (e.key === 'Enter') { e.preventDefault(); complete(); } };

    $$('[data-quick]', el).forEach((b) => b.onclick = () => {
      const cur = Number(recv.value) || 0;
      const v = Number(b.dataset.quick);
      recv.value = (cur && cur !== total ? cur + v : v).toFixed(2).replace(/\.00$/, '');
      recv.dispatchEvent(new Event('input'));
    });

    $$('[data-k]', el).forEach((b) => b.onclick = () => {
      const k = b.dataset.k;
      if (k === 'del') recv.value = recv.value.slice(0, -1);
      else recv.value += k;
      recv.dispatchEvent(new Event('input'));
    });

    $('#p-go', el).onclick = complete;
    $('#p-disc', el).onclick = discountDialog;
    $('#p-hold', el).onclick = holdCart;
    $('#p-clear', el).onclick = clearCart;
    $('#p-last', el).onclick = reprintLast;
    $('#p-cust', el).onclick = pickCustomer;
    const cx = $('#p-cust-x', el);
    if (cx) cx.onclick = () => { customer = null; renderPay(); };
    $('#p-ret', el).onclick = () => {
      if (!API.can('sale_return')) return UI.err('ما عندك صلاحية الإرجاع');
      isReturn = !isReturn;
      renderPay();
    };
    const hb = $('#p-held', el);
    if (hb) hb.onclick = heldDialog;

    setTimeout(() => recv.focus(), 30);
  }

  function updatePaySummary() {
    // إعادة رسم خفيفة للملخص فقط
    const total = calc ? calc.total : 0;
    const paid = Number(received.cash || 0) + Number(received.card || 0);
    const panel = $('#panel');
    if (!panel) return;
    const card = panel.querySelector('.card');
    if (!card) return;
    const creditAmt = payMethod === 'credit' ? Math.max(0, total - paid) : 0;
    card.innerHTML = `
      <div class="row" style="justify-content:space-between"><span class="muted">${esc(t('grand_total'))}</span>
        <span class="bold" style="font-size:19px">${moneyHTML(total)}</span></div>
      <div class="row mt8" style="justify-content:space-between"><span class="muted">${esc(t('received'))}</span>
        <span>${moneyHTML(paid)}</span></div>
      ${creditAmt > 0 ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">على الحساب</span>
        <span class="warn-text bold">${moneyHTML(creditAmt)}</span></div>` : ''}
      <div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
        <span class="bold">${esc(t('change'))}</span>
        <span class="bold ok-text" style="font-size:19px">${moneyHTML(Math.max(0, paid - total))}</span></div>`;
  }

  /* ------------------------------ إجراءات ------------------------------ */
  function discountDialog() {
    if (!API.can('sale_discount')) return UI.err('ما عندك صلاحية إعطاء خصم');
    const m = UI.modal({
      title: t('discount'),
      width: 'narrow',
      body: `
        <div class="field mb12"><label>خصم مبلغ ثابت</label>
          <input class="input lg" id="d-a" type="number" step="0.01" value="${esc(discount.amount || '')}"></div>
        <div class="field"><label>أو خصم نسبة %</label>
          <input class="input lg" id="d-p" type="number" step="0.5" value="${esc(discount.percent || '')}"></div>`,
      footer: `<button class="btn" data-clear>إلغاء الخصم</button><div class="spacer"></div>
               <button class="btn primary" data-ok>${esc(t('apply'))}</button>`,
    });
    $('[data-clear]', m.el).onclick = async () => { discount = { amount: 0, percent: 0 }; m.close(); await recalc(); };
    $('[data-ok]', m.el).onclick = async () => {
      const a = Number($('#d-a', m.el).value) || 0;
      const p = Number($('#d-p', m.el).value) || 0;
      discount = p > 0 ? { amount: 0, percent: p } : { amount: a, percent: 0 };
      m.close();
      await recalc();
    };
  }

  async function pickCustomer() {
    const res = await API.safe('parties.list', { type: 'customer', limit: 300 });
    if (!res) return;
    const m = UI.modal({
      title: t('customer'),
      body: `
        <div class="search-box mb12">${Icons.search}<input class="input" id="c-q" placeholder="${esc(t('search'))}"></div>
        <div id="c-list" style="max-height:340px;overflow:auto"></div>
        <button class="btn block mt12" id="c-new">${Icons.plus} عميل جديد</button>`,
      footer: null,
    });
    const draw = (rows) => {
      $('#c-list', m.el).innerHTML = rows.length ? rows.map((c, i) => `
        <div class="cart-row" data-c="${i}" style="cursor:pointer">
          <div><div class="nm">${esc(c.name)}</div><div class="meta">${esc(c.phone || '')}</div></div>
          <div class="amt ${Number(c.balance) > 0 ? 'danger-text' : 'muted'}">${moneyHTML(c.balance)}</div>
        </div>`).join('') : UI.emptyState('ما فيه عملاء');
      $$('[data-c]', m.el).forEach((d) => d.onclick = () => {
        customer = rows[Number(d.dataset.c)];
        m.close();
        renderPay();
      });
    };
    draw(res.rows);
    $('#c-q', m.el).oninput = UI.debounce(async (e) => {
      const r = await API.safe('parties.list', { type: 'customer', q: e.target.value, limit: 300 }, { silent: true });
      if (r) draw(r.rows);
    }, 220);
    $('#c-new', m.el).onclick = () => {
      m.close();
      Pages.customers.editDialog(null, async (saved) => { customer = saved; renderPay(); });
    };
  }

  function holdCart() {
    if (!cart.length) return;
    held.push({ cart: cart.slice(), customer, discount: { ...discount }, at: new Date().toISOString() });
    cart = []; customer = null; discount = { amount: 0, percent: 0 }; received = { cash: 0, card: 0 };
    UI.ok('تم تعليق الفاتورة');
    renderCart();
    focusScan();
  }

  function heldDialog() {
    const m = UI.modal({
      title: 'فواتير معلّقة',
      body: held.length ? held.map((hd, i) => `
        <div class="cart-row" data-h="${i}" style="cursor:pointer">
          <div><div class="nm">${hd.cart.length} صنف · ${esc(hd.customer ? hd.customer.name : t('walk_in'))}</div>
            <div class="meta">${esc(UI.timeStr(hd.at))}</div></div>
          <div class="amt">${moneyHTML(hd.cart.reduce((s, c) => s + c.price * c.qty - c.discount, 0))}</div>
        </div>`).join('') : UI.emptyState('ما فيه فواتير معلّقة'),
      footer: null,
    });
    $$('[data-h]', m.el).forEach((d) => d.onclick = () => {
      const i = Number(d.dataset.h);
      if (cart.length) held.push({ cart: cart.slice(), customer, discount: { ...discount }, at: new Date().toISOString() });
      const hd = held.splice(i, 1)[0];
      cart = hd.cart; customer = hd.customer; discount = hd.discount;
      m.close(); renderCart(); focusScan();
    });
  }

  async function clearCart() {
    if (!cart.length) return;
    const ok = await UI.confirm({ title: t('clear_cart'), message: 'أكيد تبغى تفرّغ السلة؟' });
    if (!ok) return;
    cart = []; discount = { amount: 0, percent: 0 }; customer = null; received = { cash: 0, card: 0 };
    renderCart(); focusScan();
  }

  async function complete() {
    if (!cart.length) return UI.warn(t('cart_empty'));
    const total = calc ? calc.total : 0;
    const paid = Number(received.cash || 0) + Number(received.card || 0);

    if (payMethod === 'credit' && !customer) {
      UI.warn('اختر العميل أولاً للبيع الآجل');
      return pickCustomer();
    }
    if (payMethod !== 'credit' && paid + 0.009 < total) {
      return UI.err('المبلغ المستلم أقل من الإجمالي');
    }

    const btn = $('#p-go');
    if (btn) { btn.disabled = true; btn.innerHTML = '<span class="spin"></span>'; }

    const payload = {
      type: isReturn ? 'return' : 'sale',
      items: cart.map((c) => ({
        product_id: c.product_id, name: c.name, barcode: c.barcode, unit: c.unit,
        qty: c.qty, price: c.price, discount: c.discount, cost_price: c.cost_price,
      })),
      discountAmount: discount.amount, discountPercent: discount.percent,
      cash: payMethod === 'card' ? 0 : Math.min(received.cash, total),
      card: payMethod === 'card' ? Math.min(received.card || total, total) : received.card,
      credit: payMethod === 'credit' ? Math.max(0, total - paid) : 0,
      payment_method: payMethod,
      customer_id: customer ? customer.id : null,
    };

    const sale = await API.safe('sales.create', payload);
    if (btn) { btn.disabled = false; renderPay(); }
    if (!sale) return;

    UI.ok(`${isReturn ? 'تم الإرجاع' : 'تمت الفاتورة'} ${sale.invoice_no} · ${money(sale.total)}`);
    if (API.settings.print_auto !== '0') Receipt.print(sale).catch(() => {});

    const change = Math.max(0, paid - total);
    if (change > 0 && !isReturn) changeDialog(change, sale);

    cart = []; customer = null; discount = { amount: 0, percent: 0 };
    received = { cash: 0, card: 0 }; payMethod = 'cash'; isReturn = false;
    await renderCart();
    document.querySelector('[data-tab="items"]').click();
    focusScan();
    App.refreshAlerts();
  }

  function changeDialog(change, sale) {
    const m = UI.modal({
      title: 'الباقي للعميل',
      width: 'narrow',
      body: `<div class="center">
          <div style="font-size:44px;font-weight:700;color:var(--ok);margin:10px 0">${money(change)}</div>
          <div class="muted small">فاتورة ${esc(sale.invoice_no)}</div>
        </div>`,
      footer: `<button class="btn" data-print>${Icons.print} ${esc(t('print'))}</button>
               <button class="btn primary" data-ok>${esc(t('close'))}</button>`,
    });
    $('[data-print]', m.el).onclick = () => Receipt.print(sale, { silent: false });
    $('[data-ok]', m.el).onclick = m.close;
    setTimeout(() => { if (document.body.contains(m.el)) m.close(); }, 6000);
  }

  async function reprintLast() {
    const sale = await API.safe('sales.last');
    if (!sale) return UI.warn('ما فيه فاتورة سابقة');
    Receipt.print(sale, { silent: false });
  }

  return { render, addToCart };
})();
