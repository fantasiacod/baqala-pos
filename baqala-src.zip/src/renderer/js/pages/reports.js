/* التقارير */
Pages.reports = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  const state = { from: UI.monthStart(), to: UI.todayStr(), range: 'month' };
  let tab = 'sales';
  let container = null;

  const TABS = [
    { k: 'sales', n: 'المبيعات' },
    { k: 'profit', n: 'الأرباح والخسائر' },
    { k: 'products', n: 'الأصناف' },
    { k: 'vat', n: 'الضريبة' },
    { k: 'inventory', n: 'المخزون' },
  ];

  async function render(view) {
    container = view;
    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="seg">${TABS.map((x) => `<button data-t="${x.k}" class="${tab === x.k ? 'active' : ''}">${esc(x.n)}</button>`).join('')}</div>
        <div class="spacer"></div>
        <button class="btn sm" id="print">${Icons.print} ${esc(t('print'))}</button>
        <button class="btn sm" id="ex">${Icons.download} ${esc(t('export'))}</button>
      </div>
      <div id="range" class="mb16"></div>
      <div id="body"></div>
    </div>`);
    view.appendChild(el);
    $('#range', el).appendChild(UI.dateRangeBar(state, () => draw()));
    $$('[data-t]', el).forEach((b) => b.onclick = () => { tab = b.dataset.t; render(view); });
    $('#print', el).onclick = printReport;
    $('#ex', el).onclick = exportReport;
    draw();
  }

  let lastData = null;

  async function draw() {
    const box = $('#body', container);
    box.innerHTML = `<div class="loading-full"><span class="spin"></span></div>`;
    if (tab === 'sales') return salesReport(box);
    if (tab === 'profit') return profitReport(box);
    if (tab === 'products') return productsReport(box);
    if (tab === 'vat') return vatReport(box);
    if (tab === 'inventory') return inventoryReport(box);
  }

  /* ------------------------------ المبيعات ------------------------------ */
  async function salesReport(box) {
    const d = await API.safe('reports.sales', state);
    if (!d) return;
    lastData = { rows: d.byDay, name: 'تقرير-المبيعات' };
    const s = d.stats;
    box.innerHTML = '';
    box.appendChild(h(`<div class="grid g4 mb16">
      <div class="stat accent"><div class="lbl">صافي المبيعات</div><div class="val">${money(s.netSales, false)}</div>
        <div class="sub">${s.invoices} فاتورة · متوسط ${money(s.avgInvoice)}</div><div class="ico-box">${Icons.coins}</div></div>
      <div class="stat"><div class="lbl">مجمل الربح</div><div class="val ok-text" style="font-size:22px">${money(s.grossProfit, false)}</div>
        <div class="sub">تكلفة البضاعة ${money(s.cost)}</div></div>
      <div class="stat"><div class="lbl">صافي الربح</div><div class="val ${s.netProfit >= 0 ? 'ok-text' : 'danger-text'}" style="font-size:22px">${money(s.netProfit, false)}</div>
        <div class="sub">بعد خصم مصروفات ${money(s.expenses)}</div></div>
      <div class="stat"><div class="lbl">القطع المباعة</div><div class="val" style="font-size:22px">${UI.qty(s.itemsSold)}</div>
        <div class="sub">خصومات ${money(s.discount)}</div></div>
    </div>`));

    box.appendChild(h(`<div class="grid g4 mb16">
      <div class="stat"><div class="lbl">كاش</div><div class="val" style="font-size:20px">${money(s.cash, false)}</div></div>
      <div class="stat"><div class="lbl">شبكة</div><div class="val" style="font-size:20px">${money(s.card, false)}</div></div>
      <div class="stat"><div class="lbl">آجل</div><div class="val warn-text" style="font-size:20px">${money(s.credit, false)}</div></div>
      <div class="stat"><div class="lbl">مرتجعات</div><div class="val danger-text" style="font-size:20px">${money(s.returnsTotal, false)}</div></div>
    </div>`));

    const chart = h(`<div class="card mb16"><div class="card-head"><h3>المبيعات اليومية</h3></div><div class="card-body" id="ch"></div></div>`);
    box.appendChild(chart);
    $('#ch', chart).appendChild(UI.barChart(d.byDay.slice(0, 14).reverse(), { valueKey: 'total', labelKey: 'day' }));

    const grid = h(`<div class="grid g2 mb16">
      <div class="card"><div class="card-head"><h3>حسب الموظف</h3></div><div class="card-body tight" id="bu"></div></div>
      <div class="card"><div class="card-head"><h3>حسب التصنيف</h3></div><div class="card-body tight" id="bc"></div></div>
    </div>`);
    box.appendChild(grid);
    $('#bu', grid).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الموظف', key: 'name' },
        { title: 'الفواتير', align: 'center', key: 'invoices' },
        { title: 'المبيعات', align: 'end', render: (r) => moneyHTML(r.total) },
        { title: 'الربح', align: 'end', render: (r) => `<span class="ok-text">${money(r.profit, false)}</span>` },
      ],
      rows: d.byUser,
    }));
    $('#bc', grid).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'التصنيف', key: 'cat' },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.qty) },
        { title: 'المبيعات', align: 'end', render: (r) => moneyHTML(r.total) },
      ],
      rows: d.byCategory,
    }));

    const daily = h(`<div class="card"><div class="card-head"><h3>التفصيل اليومي</h3></div><div class="card-body tight" id="bd"></div></div>`);
    box.appendChild(daily);
    $('#bd', daily).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'اليوم', render: (r) => `${UI.dayName(r.day)} ${UI.dateStr(r.day)}` },
        { title: 'الفواتير', align: 'center', key: 'invoices' },
        { title: 'كاش', align: 'end', render: (r) => money(r.cash, false) },
        { title: 'شبكة', align: 'end', render: (r) => money(r.card, false) },
        { title: 'آجل', align: 'end', render: (r) => money(r.credit, false) },
        { title: 'الضريبة', align: 'end', render: (r) => money(r.tax, false) },
        { title: 'الإجمالي', align: 'end', render: (r) => `<b>${money(r.total, false)}</b>` },
        { title: 'الربح', align: 'end', render: (r) => `<span class="ok-text">${money(r.profit, false)}</span>` },
      ],
      rows: d.byDay,
      empty: 'ما فيه مبيعات',
    }));
  }

  /* --------------------------- الأرباح والخسائر --------------------------- */
  async function profitReport(box) {
    const d = await API.safe('reports.profitLoss', state);
    if (!d) return;
    lastData = { rows: d.expenseBreakdown, name: 'الارباح-والخسائر' };
    box.innerHTML = '';
    box.appendChild(h(`
      <div class="grid" style="grid-template-columns:1.3fr 1fr">
        <div class="card">
          <div class="card-head"><h3>قائمة الدخل — ${esc(UI.dateStr(d.from))} إلى ${esc(UI.dateStr(d.to))}</h3></div>
          <div class="card-body">
            <div class="row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)">
              <span class="bold">إجمالي المبيعات (شامل الضريبة)</span><span class="bold">${money(d.revenue)}</span></div>
            ${d.tax ? `<div class="row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)">
              <span class="muted">− ضريبة القيمة المضافة</span><span>${money(d.tax)}</span></div>` : ''}
            <div class="row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)">
              <span>صافي المبيعات بدون ضريبة</span><span>${money(d.revenueExTax)}</span></div>
            <div class="row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)">
              <span class="muted">− تكلفة البضاعة المباعة</span><span class="danger-text">${money(d.cogs)}</span></div>
            <div class="row" style="justify-content:space-between;padding:11px 0;border-bottom:2px solid var(--border)">
              <span class="bold">مجمل الربح</span><span class="bold ok-text" style="font-size:17px">${money(d.grossProfit)}</span></div>
            <div class="row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border)">
              <span class="muted">− المصروفات التشغيلية</span><span class="danger-text">${money(d.expenses)}</span></div>
            <div class="row" style="justify-content:space-between;padding:13px 0">
              <span class="bold" style="font-size:16px">صافي الربح</span>
              <span class="bold ${d.netProfit >= 0 ? 'ok-text' : 'danger-text'}" style="font-size:23px">${money(d.netProfit)}</span></div>
            <div class="alert-box ${d.netProfit >= 0 ? 'ok' : 'danger'}">${d.netProfit >= 0 ? Icons.check : Icons.warning}
              <div>هامش الربح من المبيعات: <b class="num">${d.margin}%</b>${d.netProfit < 0 ? ' — المحل في خسارة هذه الفترة' : ''}</div></div>
          </div>
        </div>
        <div class="card">
          <div class="card-head"><h3>تفصيل المصروفات</h3></div>
          <div class="card-body" id="eb"></div>
        </div>
      </div>`));

    const max = Math.max(1, ...d.expenseBreakdown.map((x) => x.t));
    $('#eb', box).innerHTML = d.expenseBreakdown.length ? d.expenseBreakdown.map((c) => `
      <div class="mb12">
        <div class="row" style="justify-content:space-between"><span class="small bold">${esc(c.category)}</span>
          <span class="small">${money(c.t, false)}</span></div>
        <div class="progress mt8"><i style="width:${(c.t / max) * 100}%"></i></div></div>`).join('')
      : '<div class="muted small">ما فيه مصروفات مسجلة في هذه الفترة</div>';
  }

  /* ------------------------------- الأصناف ------------------------------- */
  async function productsReport(box) {
    const d = await API.safe('reports.products', { ...state, sort: 'total', limit: 300 });
    if (!d) return;
    lastData = { rows: d.rows, name: 'تقرير-الاصناف' };
    box.innerHTML = '';
    const c1 = h(`<div class="card mb16"><div class="card-head"><h3>الأصناف الأكثر مبيعاً</h3></div>
      <div class="card-body tight" id="pr"></div></div>`);
    box.appendChild(c1);
    $('#pr', c1).appendChild(UI.table({
      compact: true,
      columns: [
        { title: '#', align: 'center', render: (r, i) => i + 1 },
        { title: 'الصنف', render: (r) => `${esc(r.name)}<div class="small muted num">${esc(r.barcode || '')}</div>` },
        { title: 'الكمية', align: 'center', render: (r) => `<b>${UI.qty(r.qty)}</b>` },
        { title: 'الفواتير', align: 'center', key: 'invoices' },
        { title: 'المبيعات', align: 'end', render: (r) => moneyHTML(r.total) },
        { title: 'التكلفة', align: 'end', render: (r) => money(r.cost, false) },
        { title: 'الربح', align: 'end', render: (r) => `<b class="${r.profit >= 0 ? 'ok-text' : 'danger-text'}">${money(r.profit, false)}</b>` },
      ],
      rows: d.rows,
      empty: 'ما فيه مبيعات في هذه الفترة',
    }));

    const c2 = h(`<div class="card"><div class="card-head"><h3>أصناف راكدة (ما انباعت في الفترة)</h3>
      <span class="badge warn">${d.dead.length}</span></div><div class="card-body tight" id="dd"></div></div>`);
    box.appendChild(c2);
    $('#dd', c2).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', render: (r) => `${esc(r.name_ar)}<div class="small muted num">${esc(r.barcode || '')}</div>` },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.stock) },
        { title: 'قيمة التكلفة', align: 'end', render: (r) => `<b>${money(r.stock * r.cost_price, false)}</b>` },
      ],
      rows: d.dead,
      empty: 'كل الأصناف تتحرك، ممتاز',
    }));
  }

  /* ------------------------------- الضريبة ------------------------------- */
  async function vatReport(box) {
    const d = await API.safe('reports.vat', state);
    if (!d) return;
    lastData = { rows: d.byMonth, name: 'تقرير-الضريبة' };
    box.innerHTML = '';
    box.appendChild(h(`
      ${!d.enabled ? `<div class="alert-box warn mb16">${Icons.warning}<div>
        ضريبة القيمة المضافة غير مفعّلة حالياً. الأرقام تحت تخص فواتير كانت الضريبة مفعّلة وقت إصدارها.</div></div>` : ''}
      <div class="grid g4 mb16">
        <div class="stat"><div class="lbl">ضريبة المبيعات (المخرجات)</div>
          <div class="val" style="font-size:22px">${money(d.outputTax, false)}</div>
          <div class="sub">من ${d.outputInvoices} فاتورة · وعاء ${money(d.outputBase)}</div></div>
        <div class="stat"><div class="lbl">ضريبة المشتريات (المدخلات)</div>
          <div class="val" style="font-size:22px">${money(d.inputTax, false)}</div>
          <div class="sub">من ${d.inputInvoices} فاتورة شراء</div></div>
        <div class="stat ${d.netDue >= 0 ? 'accent' : ''}"><div class="lbl">الصافي المستحق للهيئة</div>
          <div class="val" style="font-size:22px">${money(d.netDue, false)}</div>
          <div class="sub">${d.netDue >= 0 ? 'يدفع للهيئة' : 'رصيد لصالحك'}</div></div>
        <div class="stat"><div class="lbl">ضريبة المرتجعات</div>
          <div class="val" style="font-size:22px">${money(d.returnsTax, false)}</div>
          <div class="sub">نسبة الضريبة <span class="num">${d.rate}%</span></div></div>
      </div>
      <div class="alert-box info mb16">${Icons.info}<div>
        الرقم الضريبي المسجّل: <b class="num">${esc(d.vatNumber || 'غير مسجل')}</b> —
        هذا التقرير للاسترشاد، وتبقى مراجعة المحاسب ضرورية قبل تقديم الإقرار لهيئة الزكاة والضريبة والجمارك.</div></div>
      <div class="card"><div class="card-head"><h3>التفصيل الشهري</h3></div><div class="card-body tight" id="vm"></div></div>`));
    $('#vm', box).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الشهر', key: 'm' },
        { title: 'الوعاء الضريبي', align: 'end', render: (r) => money(r.base, false) },
        { title: 'الضريبة', align: 'end', render: (r) => `<b>${money(r.tax, false)}</b>` },
      ],
      rows: d.byMonth,
      empty: 'ما فيه فواتير خاضعة للضريبة',
    }));
  }

  /* ------------------------------- المخزون ------------------------------- */
  async function inventoryReport(box) {
    const d = await API.safe('reports.inventory', { sort: 'value' });
    if (!d) return;
    lastData = { rows: d.rows, name: 'تقرير-المخزون' };
    box.innerHTML = '';
    box.appendChild(h(`<div class="grid g4 mb16">
      <div class="stat"><div class="lbl">عدد الأصناف</div><div class="val">${d.rows.length}</div></div>
      <div class="stat"><div class="lbl">قيمة المخزون بالتكلفة</div><div class="val" style="font-size:22px">${money(d.totals.cost, false)}</div></div>
      <div class="stat"><div class="lbl">قيمته بسعر البيع</div><div class="val" style="font-size:22px">${money(d.totals.sale, false)}</div></div>
      <div class="stat"><div class="lbl">الربح المتوقع</div><div class="val ok-text" style="font-size:22px">${money(d.expectedProfit, false)}</div></div>
    </div>`));
    const c = h(`<div class="card"><div class="card-body tight" id="it"></div></div>`);
    box.appendChild(c);
    $('#it', c).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', render: (r) => `${esc(r.name_ar)}<div class="small muted">${esc(r.cat_name || '')}</div>` },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.stock) },
        { title: 'التكلفة', align: 'end', render: (r) => money(r.cost_price, false) },
        { title: 'قيمة التكلفة', align: 'end', render: (r) => `<b>${money(r.cost_value, false)}</b>` },
        { title: 'سعر البيع', align: 'end', render: (r) => money(r.sale_price, false) },
        { title: 'الصلاحية', align: 'center', render: (r) => r.expiry_date ? UI.dateStr(r.expiry_date) : '—' },
      ],
      rows: d.rows,
    }));
  }

  /* ------------------------------ تصدير وطباعة ------------------------------ */
  async function exportReport() {
    if (!lastData || !lastData.rows.length) return UI.warn('ما فيه بيانات للتصدير');
    const csv = UI.toCSV(lastData.rows);
    await window.baqala.saveFile({
      defaultName: `${lastData.name}-${state.from}-${state.to}.csv`,
      filters: [{ name: 'CSV', extensions: ['csv'] }], content: csv,
    });
    UI.ok('تم الحفظ');
  }

  function printReport() {
    const s = API.settings;
    const body = $('#body', container).innerHTML;
    const html = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
      @page{size:A4;margin:12mm} body{font-family:'Cairo',sans-serif;font-size:11px;color:#111}
      .card{border:1px solid #ddd;border-radius:8px;margin-bottom:10px;page-break-inside:avoid}
      .card-head{padding:8px 12px;border-bottom:1px solid #ddd;font-weight:700}
      .card-head h3{margin:0;font-size:13px} .card-body{padding:10px}
      .grid{display:grid;gap:8px} .g4{grid-template-columns:repeat(4,1fr)} .g2{grid-template-columns:repeat(2,1fr)}
      .stat{border:1px solid #ddd;border-radius:8px;padding:9px}
      .stat .lbl{font-size:10px;color:#555} .stat .val{font-size:16px;font-weight:700}
      .stat .sub{font-size:9px;color:#777}
      table{width:100%;border-collapse:collapse} th{background:#f0f2f4;border:1px solid #ccc;padding:5px;font-size:10px}
      td{border:1px solid #e0e0e0;padding:4px;font-size:10px}
      .bars,.progress,.ico-box,button{display:none!important}
      .ta-end{text-align:end}.ta-center{text-align:center}
      .head{text-align:center;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:12px}
    </style></head><body>
      <div class="head"><div style="font-size:18px;font-weight:700">${UI.esc(s.store_name || '')}</div>
        <div>${UI.esc(TABS.find((x) => x.k === tab).n)} — من ${UI.esc(UI.dateStr(state.from))} إلى ${UI.esc(UI.dateStr(state.to))}</div>
        <div style="font-size:10px;color:#666">طُبع في ${UI.esc(UI.dateTimeStr(new Date().toISOString()))} بواسطة ${UI.esc(API.user.name)}</div></div>
      ${body}</body></html>`;
    window.baqala.print(html, { silent: false, width: 210 });
  }

  return { render };
})();
