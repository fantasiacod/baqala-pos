/* سجل الفواتير */
Pages.sales = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  const state = { from: UI.todayStr(), to: UI.todayStr(), range: 'today', q: '', userId: 0, type: '', method: '', status: '' };
  let container = null;
  let users = [];

  async function render(view) {
    container = view;
    users = API.can('reports') ? ((await API.safe('users.list', {}, { silent: true })) || []) : [];
    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="search-box">${Icons.search}<input class="input" id="q" placeholder="رقم الفاتورة أو اسم العميل" value="${esc(state.q)}"></div>
        ${users.length ? `<select class="select" id="usr" style="width:160px">
          <option value="0">كل الموظفين</option>
          ${users.map((u) => `<option value="${u.id}" ${state.userId === u.id ? 'selected' : ''}>${esc(u.name)}</option>`).join('')}
        </select>` : ''}
        <select class="select" id="typ" style="width:130px">
          <option value="">بيع وإرجاع</option><option value="sale">بيع فقط</option><option value="return">إرجاع فقط</option></select>
        <select class="select" id="mth" style="width:130px">
          <option value="">كل طرق الدفع</option><option value="cash">كاش</option><option value="card">شبكة</option>
          <option value="credit">آجل</option><option value="mixed">مختلط</option></select>
        <div class="spacer"></div>
        <button class="btn sm" id="vfy">${Icons.shield} تحقق من فاتورة</button>
        <button class="btn sm" id="ex">${Icons.download} ${esc(t('export'))}</button>
      </div>
      <div id="range" class="mb16"></div>
      <div class="grid g4 mb16" id="stats"></div>
      <div class="card"><div class="card-body tight" id="list"></div></div>
    </div>`);
    view.appendChild(el);

    $('#range', el).appendChild(UI.dateRangeBar(state, load));
    $('#q', el).oninput = UI.debounce((e) => { state.q = e.target.value; load(); }, 250);
    const us = $('#usr', el); if (us) us.onchange = (e) => { state.userId = Number(e.target.value); load(); };
    $('#typ', el).onchange = (e) => { state.type = e.target.value; load(); };
    $('#mth', el).onchange = (e) => { state.method = e.target.value; load(); };
    $('#ex', el).onclick = exportCSV;
    $('#vfy', el).onclick = verifyDialog;
    load();
  }

  async function load() {
    const res = await API.safe('sales.list', {
      ...state, userId: state.userId || undefined, type: state.type || undefined,
      method: state.method || undefined, limit: 500,
    });
    if (!res) return;

    const stats = await API.safe('reports.period', { from: state.from, to: state.to }, { silent: true });
    if (stats) {
      $('#stats', container).innerHTML = `
        <div class="stat"><div class="lbl">صافي المبيعات</div><div class="val" style="font-size:22px">${money(stats.netSales, false)}</div>
          <div class="sub">${stats.invoices} فاتورة</div></div>
        <div class="stat"><div class="lbl">مجمل الربح</div><div class="val ok-text" style="font-size:22px">${money(stats.grossProfit, false)}</div></div>
        <div class="stat"><div class="lbl">المرتجعات</div><div class="val ${stats.returnsTotal ? 'danger-text' : ''}" style="font-size:22px">${money(stats.returnsTotal, false)}</div>
          <div class="sub">${stats.returns} فاتورة إرجاع</div></div>
        <div class="stat"><div class="lbl">الضريبة المحصّلة</div><div class="val" style="font-size:22px">${money(stats.tax, false)}</div></div>`;
    }

    const box = $('#list', container);
    box.innerHTML = '';
    box.appendChild(UI.table({
      columns: [
        { title: 'الفاتورة', render: (r) => `<span class="num bold">${esc(r.invoice_no)}</span>
            ${r.type === 'return' ? '<span class="badge warn">إرجاع</span>' : ''}
            ${r.status === 'void' ? '<span class="badge danger">ملغية</span>' : ''}` },
        { title: t('date'), render: (r) => `${UI.dateStr(r.created_at)}<div class="small muted">${UI.timeStr(r.created_at)}</div>` },
        { title: 'الكاشير', key: 'user_name' },
        { title: t('customer'), render: (r) => esc(r.customer_name || 'عميل نقدي') },
        { title: 'الدفع', align: 'center', render: (r) => {
            const m = { cash: 'كاش', card: 'شبكة', credit: 'آجل', mixed: 'مختلط' }[r.payment_method] || r.payment_method;
            const cls = { cash: '', card: 'info', credit: 'warn', mixed: '' }[r.payment_method] || '';
            return `<span class="badge ${cls}">${esc(m)}</span>`;
          } },
        { title: t('total'), align: 'end', render: (r) => r.status === 'void'
            ? `<span class="muted" style="text-decoration:line-through">${money(r.total, false)}</span>`
            : `<b class="${r.type === 'return' ? 'danger-text' : ''}">${r.type === 'return' ? '- ' : ''}${money(r.total, false)}</b>` },
        { title: '', align: 'end', width: '120px', render: (r) => `
            <div class="row gap6" style="justify-content:flex-end">
              <button class="btn ghost icon sm" data-pr="${r.id}" title="${esc(t('print'))}">${Icons.print}</button>
              ${API.can('sale_void') && r.status !== 'void' ? `<button class="btn ghost icon sm" data-vd="${r.id}" title="إلغاء">${Icons.x}</button>` : ''}
            </div>` },
      ],
      rows: res.rows,
      onRowClick: (r) => showInvoice(r.id),
      empty: 'ما فيه فواتير في هذه الفترة',
    }));

    $$('[data-pr]', box).forEach((b) => b.onclick = async () => {
      const sale = await API.safe('sales.get', { id: Number(b.dataset.pr) });
      if (sale) Receipt.print(sale, { silent: false });
    });
    $$('[data-vd]', box).forEach((b) => b.onclick = () => voidInvoice(Number(b.dataset.vd)));
  }

  async function showInvoice(id) {
    const sale = await API.safe('sales.get', { id });
    if (!sale) return;
    const taxed = Number(sale.tax_enabled) === 1 && Number(sale.tax_amount) > 0;
    const m = UI.modal({
      title: `فاتورة ${sale.invoice_no}`,
      width: 'wide',
      body: `
        ${sale.status === 'void' ? `<div class="alert-box danger mb16">${Icons.warning}<div>
          <b>فاتورة ملغية</b> — السبب: ${esc(sale.void_reason || '-')} · بتاريخ ${esc(UI.dateTimeStr(sale.void_at))}</div></div>` : ''}
        <div class="row wrap gap14 mb16 small">
          <span class="muted">${esc(t('date'))}: <b>${esc(UI.dateTimeStr(sale.created_at))}</b></span>
          <span class="muted">الكاشير: <b>${esc(sale.user_name || '')}</b></span>
          <span class="muted">${esc(t('customer'))}: <b>${esc(sale.customer_name || 'عميل نقدي')}</b></span>
          <span class="muted">الدفع: <b>${esc({ cash: 'كاش', card: 'شبكة', credit: 'آجل', mixed: 'مختلط' }[sale.payment_method] || '')}</b></span>
        </div>
        <div id="itbl" class="mb16"></div>
        <div class="row" style="justify-content:flex-end">
          <div style="width:300px">
            <div class="row" style="justify-content:space-between"><span class="muted">${taxed ? 'قبل الضريبة' : 'المجموع'}</span><span>${money(sale.subtotal)}</span></div>
            ${Number(sale.discount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الخصم</span><span class="danger-text">- ${money(sale.discount)}</span></div>` : ''}
            ${taxed ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">ضريبة <span class="num">${sale.tax_rate}%</span></span><span>${money(sale.tax_amount)}</span></div>` : ''}
            <div class="row mt8" style="justify-content:space-between;border-top:2px solid var(--border);padding-top:8px">
              <span class="bold">الإجمالي</span><span class="bold" style="font-size:20px">${money(sale.total)}</span></div>
            ${Number(sale.cash_amount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">كاش</span><span>${money(sale.cash_amount)}</span></div>` : ''}
            ${Number(sale.card_amount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">شبكة</span><span>${money(sale.card_amount)}</span></div>` : ''}
            ${Number(sale.credit_amount) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">آجل</span><span class="warn-text bold">${money(sale.credit_amount)}</span></div>` : ''}
            ${Number(sale.change_due) ? `<div class="row mt8" style="justify-content:space-between"><span class="muted">الباقي</span><span>${money(sale.change_due)}</span></div>` : ''}
            ${API.can('reports') ? `<div class="row mt8" style="justify-content:space-between;border-top:1px dashed var(--border);padding-top:8px">
              <span class="muted">الربح</span><span class="ok-text bold">${money(sale.profit)}</span></div>` : ''}
          </div>
        </div>`,
      footer: `
        <button class="btn" data-print>${Icons.print} طباعة إيصال</button>
        <button class="btn" data-a4>${Icons.receipt} فاتورة A4</button>
        ${API.can('sale_void') && sale.status !== 'void' ? `<button class="btn danger" data-void>${Icons.x} إلغاء الفاتورة</button>` : ''}
        <div class="spacer"></div><button class="btn primary" data-close2>${esc(t('close'))}</button>`,
    });
    $('#itbl', m.el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', render: (r) => `${esc(r.name)}<div class="small muted num">${esc(r.barcode || '')}</div>` },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.qty) },
        { title: 'السعر', align: 'end', render: (r) => money(Number(r.qty) ? Number(r.line_total) / Number(r.qty) : 0, false) },
        ...(taxed ? [{ title: 'الضريبة', align: 'end', render: (r) => money(r.tax_amount, false) }] : []),
        { title: 'الإجمالي', align: 'end', render: (r) => `<b>${money(r.line_total, false)}</b>` },
      ],
      rows: sale.items,
    }));
    $('[data-print]', m.el).onclick = () => Receipt.print(sale, { silent: false });
    $('[data-a4]', m.el).onclick = () => Receipt.print(sale, { a4: true, silent: false });
    const vb = $('[data-void]', m.el);
    if (vb) vb.onclick = () => { m.close(); voidInvoice(sale.id); };
    $('[data-close2]', m.el).onclick = m.close;
  }

  async function voidInvoice(id) {
    const reason = await UI.confirm({
      title: 'إلغاء فاتورة',
      message: 'بيتم إرجاع الأصناف للمخزون وتعديل حساب العميل إن وجد. العملية تتسجل باسمك في السجل.',
      confirmText: 'تأكيد الإلغاء',
      input: { label: 'سبب الإلغاء', placeholder: 'مثال: خطأ في الإدخال' },
    });
    if (reason === null) return;
    const r = await API.safe('sales.void', { id, reason });
    if (!r) return;
    UI.ok('تم إلغاء الفاتورة');
    if (container) load();
    App.refreshAlerts();
  }

  async function exportCSV() {
    const res = await API.safe('sales.list', { ...state, limit: 5000 });
    if (!res) return;
    const csv = UI.toCSV(res.rows.map((r) => ({
      invoice_no: r.invoice_no, date: r.created_at, cashier: r.user_name, customer: r.customer_name || '',
      subtotal: r.subtotal, discount: r.discount, tax: r.tax_amount, total: r.total,
      method: r.payment_method, type: r.type, status: r.status,
    })));
    await window.baqala.saveFile({
      defaultName: `الفواتير-${state.from}-${state.to}.csv`,
      filters: [{ name: 'CSV', extensions: ['csv'] }], content: csv,
    });
    UI.ok('تم الحفظ');
  }

  /* ------------------------ التحقق من صحة فاتورة ------------------------ */
  function verifyDialog() {
    const m = UI.modal({
      title: 'تحقق من صحة فاتورة',
      width: 'narrow',
      body: `
        <div class="alert-box info mb12">${Icons.info}<div>
          امسح رمز التحقق المطبوع أسفل الفاتورة بكاميرا الجوال، وانسخ النص الظاهر والصقه هنا.</div></div>
        <div class="field"><label>نص رمز التحقق</label>
          <textarea class="input" id="v-text" rows="8" style="font-family:inherit;line-height:1.7"
            placeholder="الصق هنا النص كامل كما ظهر من مسح الرمز"></textarea></div>
        <div id="v-out" class="mt12"></div>`,
      footer: `<button class="btn" data-close2>${esc(t('close'))}</button>
        <button class="btn primary" data-go>${Icons.shield} تحقق</button>`,
    });
    $('[data-close2]', m.el).onclick = m.close;
    $('[data-go]', m.el).onclick = async () => {
      const text = $('#v-text', m.el).value;
      const out = $('#v-out', m.el);
      if (!text.trim()) { out.innerHTML = ''; return UI.err('الصق نص الرمز أولاً'); }
      out.innerHTML = '<div class="center" style="padding:14px"><span class="spin"></span></div>';
      const r = await API.safe('invoice.check', { text });
      if (!r) { out.innerHTML = ''; return; }
      out.innerHTML = verifyResult(r);
      const ob = $('[data-open-sale]', out);
      if (ob) ob.onclick = () => { m.close(); showInvoice(Number(ob.dataset.openSale)); };
    };
  }

  function verifyResult(r) {
    const p = r.parsed || {};
    const reasons = {
      EMPTY: 'ما فيه نص للتحقق',
      NO_CODE: 'النص ما فيه سطر «تحقق» — غالباً ناقص أو منسوخ جزئياً',
      NO_INVOICE: 'النص ما فيه رقم فاتورة',
      BAD_CODE: 'رمز التحقق لا يطابق البيانات — الفاتورة معدّلة أو من محل ثاني',
    };

    if (!r.ok) {
      return `<div class="alert-box danger">${Icons.alert}<div>
        <b>فاتورة غير صحيحة</b>
        <div class="small mt8">${esc(reasons[r.reason] || 'تعذّر التحقق')}</div>
      </div></div>` + details(p, r);
    }

    const notFound = !r.sale;
    const mismatch = r.sale && r.matches === false;
    const voided = r.sale && r.sale.status === 'void';

    let head;
    if (notFound) {
      head = `<div class="alert-box warn">${Icons.warning}<div>
        <b>التوقيع سليم — لكن الفاتورة مو محفوظة على هذا الجهاز</b>
        <div class="small mt8">صادرة من محلك لكن من جهاز ثاني، أو انحذفت بياناتها.</div></div></div>`;
    } else if (mismatch) {
      head = `<div class="alert-box danger">${Icons.alert}<div>
        <b>الإجمالي لا يطابق المحفوظ</b>
        <div class="small mt8">المطبوع ${esc(p.total)} — والمحفوظ ${esc(UI.money(r.sale.total, false))}</div></div></div>`;
    } else if (voided) {
      head = `<div class="alert-box warn">${Icons.warning}<div>
        <b>فاتورة صحيحة لكنها ملغاة</b>
        <div class="small mt8">تم إلغاؤها لاحقاً من البرنامج.</div></div></div>`;
    } else {
      head = `<div class="alert-box ok">${Icons.check}<div>
        <b>فاتورة صحيحة ومطابقة</b>
        <div class="small mt8">التوقيع سليم والبيانات تطابق الفاتورة المحفوظة.</div></div></div>`;
    }
    return head + details(p, r);
  }

  function details(p, r) {
    const row = (k, v) => v ? `<div class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px dashed var(--border)">
      <span class="muted small">${esc(k)}</span><b class="num">${esc(v)}</b></div>` : '';
    return `<div class="card mt12" style="padding:12px">
      <div class="bold small mb8">${esc(p.store || '')}</div>
      ${row('رقم السجل التجاري', p.cr)}
      ${row('رقم السجل الضريبي', p.taxReg)}
      ${row('الرقم الضريبي', p.vat)}
      ${row('رقم الفاتورة', p.invoice)}
      ${row('التاريخ', p.date)}
      ${row('الإجمالي', p.total)}
      ${r.sale ? `<div class="row mt8"><div class="spacer"></div>
        <button class="btn sm" data-open-sale="${r.sale.id}">فتح الفاتورة</button></div>` : ''}
    </div>`;
  }

  function filterUser(userId, day) {
    state.userId = userId;
    if (day) { state.from = day; state.to = day; state.range = 'custom'; }
    if (container) render(container, {});
  }

  return { render, showInvoice, filterUser };
})();
