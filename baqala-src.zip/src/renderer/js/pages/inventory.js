/* الجرد والمخزون والتنبيهات */
Pages.inventory = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  let tab = 'alerts';
  let container = null;

  async function render(view) {
    container = view;
    view.innerHTML = '';
    const el = h(`<div>
      <div class="toolbar">
        <div class="seg">
          <button data-t="alerts" class="${tab === 'alerts' ? 'active' : ''}">التنبيهات</button>
          <button data-t="count" class="${tab === 'count' ? 'active' : ''}">الجرد</button>
          <button data-t="value" class="${tab === 'value' ? 'active' : ''}">قيمة المخزون</button>
        </div>
        <div class="spacer"></div>
        <button class="btn sm" id="rf">${Icons.refresh} ${esc(t('refresh'))}</button>
      </div>
      <div id="body"></div>
    </div>`);
    view.appendChild(el);
    $$('[data-t]', el).forEach((b) => b.onclick = () => { tab = b.dataset.t; render(view); });
    $('#rf', el).onclick = () => render(view);
    if (tab === 'alerts') await alertsView();
    else if (tab === 'count') await countView();
    else await valueView();
  }

  /* ------------------------------ التنبيهات ------------------------------ */
  async function alertsView() {
    const a = await API.safe('products.alerts');
    if (!a) return;
    const box = $('#body', container);
    box.innerHTML = '';

    const section = (title, rows, kind, cols) => {
      if (!rows.length) return '';
      const card = h(`<div class="card mb16">
        <div class="card-head"><h3>${esc(title)}</h3><span class="badge ${kind}">${rows.length}</span></div>
        <div class="card-body tight"></div></div>`);
      $('.card-body', card).appendChild(UI.table({ compact: true, columns: cols, rows }));
      box.appendChild(card);
      return card;
    };

    const baseCols = [
      { title: 'الصنف', render: (r) => `<div class="bold">${esc(r.name_ar)}</div><div class="small muted">${esc(r.barcode || '')}</div>` },
      { title: 'المتوفر', align: 'center', render: (r) => `<span class="bold num">${UI.qty(r.stock)}</span> ${esc(r.unit || '')}` },
    ];

    if (!a.out.length && !a.low.length && !a.expired.length && !a.expiring.length) {
      box.innerHTML = `<div class="card"><div class="card-body">
        <div class="alert-box ok">${Icons.check}<div>ما فيه تنبيهات — المخزون بحالة جيدة.</div></div></div></div>`;
      return;
    }

    section('أصناف خلصت من المخزون', a.out, 'danger', [
      ...baseCols,
      { title: '', align: 'end', render: (r) => `<button class="btn sm" data-buy="${r.id}">${Icons.truck} أضفها لفاتورة شراء</button>` },
    ]);
    section('أصناف منتهية الصلاحية', a.expired, 'danger', [
      ...baseCols,
      { title: 'انتهت في', align: 'center', render: (r) => `<span class="danger-text bold">${esc(UI.dateStr(r.expiry_date))}</span>` },
      { title: '', align: 'end', render: (r) => `<button class="btn sm danger" data-dmg="${r.id}">${Icons.trash} تسجيل تالف</button>` },
    ]);
    section('كميات قاربت على الخلاص', a.low, 'warn', [
      ...baseCols,
      { title: 'حد التنبيه', align: 'center', render: (r) => UI.qty(r.min_stock) },
      { title: '', align: 'end', render: (r) => `<button class="btn sm" data-buy="${r.id}">${Icons.truck} أضفها لفاتورة شراء</button>` },
    ]);
    section('تنتهي صلاحيتها قريباً', a.expiring, 'info', [
      ...baseCols,
      { title: 'تنتهي في', align: 'center', render: (r) => {
          const days = Math.ceil((new Date(r.expiry_date) - new Date()) / 86400000);
          return `<span class="badge warn">${esc(UI.dateStr(r.expiry_date))} · بعد ${days} يوم</span>`;
        } },
    ]);

    $$('[data-buy]', box).forEach((b) => b.onclick = async () => {
      const p = await API.safe('products.get', { id: Number(b.dataset.buy) });
      if (p) { App.go('purchases'); setTimeout(() => Pages.purchases.newWith(p), 300); }
    });
    $$('[data-dmg]', box).forEach((b) => b.onclick = async () => {
      const p = await API.safe('products.get', { id: Number(b.dataset.dmg) });
      if (p) adjustDialog(p, () => render(container), 'damage');
    });
  }

  /* -------------------------------- الجرد -------------------------------- */
  async function countView() {
    const box = $('#body', container);
    box.innerHTML = `<div class="card">
      <div class="card-head"><h3>الجرد الفعلي</h3><div class="spacer"></div>
        <div class="search-box">${Icons.search}<input class="input" id="cq" placeholder="ابحث عن صنف أو امسح الباركود"></div></div>
      <div class="card-body">
        <div class="alert-box info mb16">${Icons.info}<div>
          اكتب الكمية الموجودة فعلياً في الرف، والبرنامج يسجّل الفرق تلقائياً ويسجّل باسمك في السجل.</div></div>
        <div id="ctbl"></div>
      </div></div>`;

    const load = async (q) => {
      const res = await API.safe('products.list', { q, limit: 200 });
      if (!res) return;
      const wrap = $('#ctbl', box);
      wrap.innerHTML = '';
      wrap.appendChild(UI.table({
        compact: true,
        columns: [
          { title: 'الصنف', render: (r) => `<div class="bold">${esc(r.name_ar)}</div><div class="small muted">${esc(r.barcode || '')}</div>` },
          { title: 'بالنظام', align: 'center', render: (r) => `<span class="num bold">${UI.qty(r.stock)}</span>` },
          { title: 'الموجود فعلياً', align: 'center', width: '130px',
            render: (r) => `<input class="input" data-cnt="${r.id}" style="width:110px;text-align:center" placeholder="—">` },
          { title: 'الفرق', align: 'center', render: (r) => `<span data-diff="${r.id}" class="muted">—</span>` },
          { title: '', align: 'end', render: (r) => `<button class="btn sm" data-save="${r.id}" disabled>${esc(t('save'))}</button>` },
        ],
        rows: res.rows,
        empty: 'اكتب اسم الصنف للبحث',
      }));

      $$('[data-cnt]', wrap).forEach((inp) => {
        const id = Number(inp.dataset.cnt);
        const row = res.rows.find((x) => x.id === id);
        inp.oninput = () => {
          const v = inp.value.trim();
          const diffEl = wrap.querySelector(`[data-diff="${id}"]`);
          const btn = wrap.querySelector(`[data-save="${id}"]`);
          if (v === '' || isNaN(Number(v))) { diffEl.textContent = '—'; diffEl.className = 'muted'; btn.disabled = true; return; }
          const d = Number(v) - Number(row.stock);
          diffEl.textContent = (d > 0 ? '+' : '') + UI.qty(d);
          diffEl.className = d === 0 ? 'muted' : d > 0 ? 'ok-text bold' : 'danger-text bold';
          btn.disabled = d === 0;
        };
        inp.onkeydown = (e) => { if (e.key === 'Enter') wrap.querySelector(`[data-save="${id}"]`).click(); };
      });

      $$('[data-save]', wrap).forEach((b) => b.onclick = async () => {
        const id = Number(b.dataset.save);
        const inp = wrap.querySelector(`[data-cnt="${id}"]`);
        const r = await API.safe('products.adjust', { productId: id, newQty: Number(inp.value), reason: 'adjust', note: 'جرد فعلي' });
        if (r) { UI.ok('تم تعديل الكمية'); load($('#cq', box).value); App.refreshAlerts(); }
      });
    };

    $('#cq', box).oninput = UI.debounce((e) => load(e.target.value), 260);
    load('');
    setTimeout(() => $('#cq', box).focus(), 60);
  }

  /* ---------------------------- قيمة المخزون ---------------------------- */
  async function valueView() {
    const r = await API.safe('reports.inventory', { sort: 'value' });
    if (!r) return;
    const box = $('#body', container);
    box.innerHTML = '';
    box.appendChild(h(`<div class="grid g4 mb16">
      <div class="stat"><div class="lbl">عدد الأصناف</div><div class="val">${r.rows.length}</div></div>
      <div class="stat"><div class="lbl">إجمالي الكميات</div><div class="val">${UI.qty(r.totals.qty)}</div></div>
      <div class="stat"><div class="lbl">قيمة المخزون بالتكلفة</div><div class="val" style="font-size:21px">${money(r.totals.cost, false)}</div></div>
      <div class="stat"><div class="lbl">الربح المتوقع لو انباع كله</div><div class="val ok-text" style="font-size:21px">${money(r.expectedProfit, false)}</div></div>
    </div>`));

    const card = h(`<div class="card"><div class="card-head"><h3>تفاصيل قيمة المخزون</h3><div class="spacer"></div>
      <button class="btn sm" id="ex">${Icons.download} ${esc(t('export'))}</button></div>
      <div class="card-body tight" id="vt"></div></div>`);
    box.appendChild(card);
    $('#vt', card).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', render: (x) => `<div class="bold">${esc(x.name_ar)}</div><div class="small muted">${esc(x.cat_name || '')}</div>` },
        { title: 'الكمية', align: 'center', render: (x) => UI.qty(x.stock) },
        { title: 'التكلفة', align: 'end', render: (x) => money(x.cost_price, false) },
        { title: 'قيمة التكلفة', align: 'end', render: (x) => `<span class="bold">${money(x.cost_value, false)}</span>` },
        { title: 'قيمة البيع', align: 'end', render: (x) => money(x.sale_value, false) },
        { title: 'الربح المتوقع', align: 'end', render: (x) => `<span class="ok-text">${money(x.sale_value - x.cost_value, false)}</span>` },
      ],
      rows: r.rows,
    }));
    $('#ex', card).onclick = async () => {
      const csv = UI.toCSV(r.rows.map((x) => ({
        name: x.name_ar, barcode: x.barcode, category: x.cat_name, stock: x.stock,
        cost_price: x.cost_price, cost_value: x.cost_value, sale_value: x.sale_value,
      })));
      await window.baqala.saveFile({ defaultName: `قيمة-المخزون-${UI.todayStr()}.csv`, filters: [{ name: 'CSV', extensions: ['csv'] }], content: csv });
      UI.ok('تم الحفظ');
    };
  }

  /* --------------------------- تعديل كمية صنف --------------------------- */
  function adjustDialog(p, onDone, forceReason) {
    const m = UI.modal({
      title: `تعديل كمية: ${p.name_ar}`,
      width: 'narrow',
      body: `
        <div class="alert-box info mb16">${Icons.info}<div>الكمية الحالية بالنظام: <b>${UI.qty(p.stock)} ${esc(p.unit || '')}</b></div></div>
        <div class="field mb12"><label>نوع الحركة</label>
          <select class="select" id="a-r">
            <option value="adjust" ${forceReason === 'adjust' ? 'selected' : ''}>تسوية / جرد</option>
            <option value="damage" ${forceReason === 'damage' ? 'selected' : ''}>تالف أو منتهي الصلاحية</option>
            <option value="purchase">إدخال بضاعة</option>
          </select></div>
        <div class="seg mb12" style="width:100%">
          <button data-mode="set" class="active" style="flex:1">تحديد الكمية</button>
          <button data-mode="add" style="flex:1">إضافة / خصم</button>
        </div>
        <div class="field mb12" id="set-wrap"><label>الكمية الجديدة</label>
          <input class="input lg" id="a-new" type="number" step="0.001" value="${esc(p.stock)}"></div>
        <div class="field mb12" id="add-wrap" style="display:none"><label>المقدار (بالسالب للخصم)</label>
          <input class="input lg" id="a-delta" type="number" step="0.001" placeholder="مثال: 10 أو 5-"></div>
        <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="a-note" placeholder="سبب التعديل"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${esc(t('save'))}</button>`,
    });
    let mode = 'set';
    $$('[data-mode]', m.el).forEach((b) => b.onclick = () => {
      mode = b.dataset.mode;
      $$('[data-mode]', m.el).forEach((x) => x.classList.toggle('active', x === b));
      $('#set-wrap', m.el).style.display = mode === 'set' ? '' : 'none';
      $('#add-wrap', m.el).style.display = mode === 'add' ? '' : 'none';
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const payload = {
        productId: p.id,
        reason: $('#a-r', m.el).value,
        note: $('#a-note', m.el).value.trim(),
      };
      if (mode === 'set') payload.newQty = Number($('#a-new', m.el).value);
      else payload.delta = Number($('#a-delta', m.el).value);
      if (mode === 'add' && !payload.delta) return UI.err('اكتب المقدار');
      const r = await API.safe('products.adjust', payload);
      if (!r) return;
      UI.ok('تم تعديل الكمية');
      m.close();
      App.refreshAlerts();
      if (onDone) onDone();
    };
  }

  return { render, adjustDialog };
})();
