/* صفحة النماذج: بيانات وصور السجلات الرسمية للمحل */
Pages.forms = (() => {
  const { h, $, esc } = UI;

  const DOCS = [
    {
      kind: 'cr',
      title: 'عرض صورة السجل التجاري',
      field: 'cr_number',
      label: 'رقم السجل التجاري',
      len: 12,
      required: true,
      icon: () => Icons.idcard,
      note: 'السجل التجاري إلزامي ويُعرض في المحل، ورقمه يُطبع على الفاتورة.',
    },
    {
      kind: 'tax',
      title: 'صورة السجل الضريبي',
      field: 'tax_register',
      label: 'رقم السجل الضريبي',
      len: 20,
      required: false,
      icon: () => Icons.receipt,
      note: 'يُطلب إذا تجاوز الدخل السنوي الحد النظامي أو كان للمحل أكثر من فرع، وصورته اختيارية.',
    },
  ];

  let S = {};
  let comp = {};
  let images = { cr: '', tax: '' };
  let view = null;

  async function render(v) {
    view = v;
    S = (await API.safe('settings.get')) || {};
    API.settings = S;
    comp = (await API.safe('settings.compliance', {}, { silent: true })) || { required: false, income12m: 0, branches: 1 };
    const [cr, tax] = await Promise.all([
      API.safe('settings.doc', { kind: 'cr' }, { silent: true }),
      API.safe('settings.doc', { kind: 'tax' }, { silent: true }),
    ]);
    images = { cr: (cr && cr.image) || '', tax: (tax && tax.image) || '' };
    draw();
  }

  function draw() {
    view.innerHTML = '';
    view.appendChild(h(`<div class="col gap14">
      ${headerCard()}
      <div class="grid g2" id="docs"></div>
    </div>`));
    const wrap = $('#docs', view);
    DOCS.forEach((d) => wrap.appendChild(docCard(d)));
    const gs = $('#go-settings', view);
    if (gs) gs.onclick = () => App.go('settings');
  }

  /* ---------------------------- بطاقة البيانات ---------------------------- */
  function headerCard() {
    const rows = [
      ['اسم المحل', S.store_name || '—', false],
      ['الاسم بالإنجليزي', S.store_name_en || '—', false],
      ['رقم السجل التجاري', S.cr_number || 'غير مُدخل', true],
      ['رقم السجل الضريبي', S.tax_register || (comp.required ? 'مطلوب — غير مُدخل' : 'غير مطلوب حالياً'), true],
      ['الرقم الضريبي (ضريبة القيمة المضافة)', S.vat_number || 'غير مُدخل', true],
      ['رقم الجوال', S.phone || '—', true],
      ['عدد الفروع', S.branches_count || '1', true],
      ['العنوان', S.address || '—', false],
    ];
    return `<div class="card">
      <div class="card-head"><h3>${Icons.store} بيانات المحل الرسمية</h3><div class="spacer"></div>
        ${API.can('settings') ? '<button class="btn sm" id="go-settings">تعديل البيانات</button>' : ''}</div>
      <div class="card-body">
        <div class="grid g2">
          ${rows.map(([k, v, isNum]) => `<div class="row" style="justify-content:space-between;gap:10px;padding:7px 0;border-bottom:1px dashed var(--border)">
            <span class="muted small">${esc(k)}</span>
            <b class="${isNum ? 'num' : ''}" style="text-align:end">${esc(v)}</b>
          </div>`).join('')}
        </div>
        ${comp.required && !S.tax_register ? `<div class="alert-box warn mt12">${Icons.warning}<div>
          لازم تضيف رقم السجل الضريبي من الإعدادات ← بيانات المحل.</div></div>` : ''}
      </div></div>`;
  }

  /* ----------------------------- بطاقة وثيقة ----------------------------- */
  function docCard(d) {
    const img = images[d.kind];
    const number = S[d.field] || '';
    const canEdit = API.can('settings');
    const el = h(`<div class="card">
      <div class="card-head"><h3>${d.icon()} ${esc(d.title)}</h3><div class="spacer"></div>
        <span class="badge ${img ? 'ok' : ''}">${img ? 'الصورة متوفرة' : 'بدون صورة'}</span></div>
      <div class="card-body">
        <div class="row" style="justify-content:space-between;align-items:baseline">
          <span class="muted small">${esc(d.label)}</span>
          <b class="num" style="font-size:19px;letter-spacing:.5px">${esc(number || '—')}</b>
        </div>
        <div class="hint mt8">${esc(d.note)}</div>

        <div class="mt12" id="box-${d.kind}"
             style="border:2px dashed var(--border);border-radius:14px;min-height:210px;display:grid;place-items:center;overflow:hidden;background:var(--surface-2)">
          ${img
            ? `<img src="${esc(img)}" alt="${esc(d.title)}" style="width:100%;max-height:330px;object-fit:contain;cursor:zoom-in" data-zoom>`
            : `<div class="col" style="align-items:center;gap:6px;padding:26px">
                 <span class="muted">${Icons.doc}</span>
                 <span class="muted small">ما فيه صورة مرفوعة</span>
               </div>`}
        </div>

        <div class="row gap6 mt12">
          ${img ? `<button class="btn sm" data-view>${Icons.zoom} عرض</button>
                   <button class="btn sm" data-print>${Icons.print} طباعة</button>` : ''}
          ${canEdit ? `<button class="btn sm ${img ? '' : 'primary'}" data-pick>${Icons.upload} ${img ? 'تغيير الصورة' : 'رفع صورة'}</button>` : ''}
          <div class="spacer"></div>
          ${img && canEdit ? `<button class="btn sm danger" data-del>${Icons.trash} حذف</button>` : ''}
        </div>
      </div></div>`);

    const zoom = $('[data-zoom]', el);
    if (zoom) zoom.onclick = () => showFull(d);
    const bv = $('[data-view]', el); if (bv) bv.onclick = () => showFull(d);
    const bp = $('[data-print]', el); if (bp) bp.onclick = () => printDoc(d);
    const bk = $('[data-pick]', el); if (bk) bk.onclick = () => pick(d);
    const bd = $('[data-del]', el); if (bd) bd.onclick = () => remove(d);
    return el;
  }

  /* ------------------------------- العمليات ------------------------------- */
  function showFull(d) {
    UI.modal({
      title: `${d.title} — ${S[d.field] || ''}`,
      width: 'wide',
      body: `<div style="text-align:center"><img src="${esc(images[d.kind])}" style="max-width:100%;max-height:74vh;object-fit:contain"></div>`,
      footer: `<button class="btn" data-close>إغلاق</button>`,
    });
  }

  async function printDoc(d) {
    const doc = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8">
      <title>${esc(d.title)}</title>
      <style>
        @page { size: A4; margin: 12mm; }
        body { font-family: 'Cairo','Tajawal',sans-serif; text-align:center; color:#000; margin:0; }
        h2 { margin: 0 0 4px; font-size:20px; }
        .n { direction:ltr; font-size:18px; letter-spacing:1px; margin:6px 0 14px; }
        img { max-width:100%; max-height:225mm; object-fit:contain; }
      </style></head><body>
      <h2>${esc(S.store_name || '')}</h2>
      <div>${esc(d.title)}</div>
      <div class="n">${esc(S[d.field] || '')}</div>
      <img src="${esc(images[d.kind])}">
      </body></html>`;
    const res = await window.baqala.print(doc, { silent: false, width: 210 });
    if (res && !res.ok) UI.err('تعذّرت الطباعة: ' + ((res.error && res.error.ar) || ''));
  }

  async function pick(d) {
    const r = await window.baqala.openFile({
      filters: [{ name: 'صور', extensions: ['png', 'jpg', 'jpeg', 'webp'] }],
      encoding: 'base64',
    });
    if (!r || !r.ok || r.data.canceled) return;
    const name = String(r.data.name || '').toLowerCase();
    const mime = name.endsWith('.png') ? 'image/png' : (name.endsWith('.webp') ? 'image/webp' : 'image/jpeg');
    const raw = `data:${mime};base64,${r.data.content}`;
    let dataUrl = raw;
    try { dataUrl = await shrink(raw); } catch (e) { console.error('shrink', e); }
    if (dataUrl.length > 1400000) return UI.err('الصورة كبيرة جداً، صوّر السجل بجودة أقل أو اقتصّ الصورة');
    const ok = await API.safe('settings.setDoc', { kind: d.kind, image: dataUrl });
    if (!ok) return;
    UI.ok('تم حفظ الصورة');
    render(view);
  }

  async function remove(d) {
    const yes = await UI.confirm({
      title: 'حذف الصورة',
      message: `متأكد من حذف صورة ${d.title.replace('عرض صورة ', '')}؟ الرقم يبقى محفوظاً.`,
      confirmText: 'حذف', danger: true,
    });
    if (!yes) return;
    const ok = await API.safe('settings.setDoc', { kind: d.kind, image: '' });
    if (!ok) return;
    UI.ok('تم حذف الصورة');
    render(view);
  }

  /** تصغير الصورة قبل الحفظ حتى لا تكبر قاعدة البيانات */
  function shrink(dataUrl, maxSide = 1600, quality = 0.84) {
    return new Promise((resolve, reject) => {
      const im = new Image();
      im.onload = () => {
        try {
          const scale = Math.min(1, maxSide / Math.max(im.width, im.height));
          if (scale >= 1 && dataUrl.length < 900000) return resolve(dataUrl);
          const c = document.createElement('canvas');
          c.width = Math.round(im.width * scale);
          c.height = Math.round(im.height * scale);
          const g = c.getContext('2d');
          g.fillStyle = '#fff';
          g.fillRect(0, 0, c.width, c.height);
          g.drawImage(im, 0, 0, c.width, c.height);
          resolve(c.toDataURL('image/jpeg', quality));
        } catch (e) { reject(e); }
      };
      im.onerror = () => reject(new Error('تعذّر قراءة الصورة'));
      im.src = dataUrl;
    });
  }

  return { render };
})();
