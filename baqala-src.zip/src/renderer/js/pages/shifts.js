/* الورديات والصندوق */
Pages.shifts = (() => {
  const { h, $, $$, esc, money } = UI;
  let container = null;

  async function render(view) {
    container = view;
    const cur = await API.safe('shifts.current');
    const list = API.can('reports') ? ((await API.safe('shifts.list', { limit: 60 })) || []) : [];

    view.innerHTML = '';
    const el = h(`<div class="col gap14">
      <div id="cur"></div>
      ${list.length ? `<div class="card"><div class="card-head"><h3>سجل الورديات</h3></div>
        <div class="card-body tight" id="hist"></div></div>` : ''}
    </div>`);
    view.appendChild(el);

    if (cur) {
      const sum = await API.safe('shifts.summary', { shiftId: cur.id });
      $('#cur', el).innerHTML = '';
      $('#cur', el).appendChild(currentCard(sum));
    } else {
      $('#cur', el).innerHTML = `<div class="card"><div class="card-body">
        <div class="empty">${Icons.clock}
          <div class="t">ما عندك وردية مفتوحة</div>
          <div class="small mb16">افتح وردية عشان يحسب البرنامج الكاش اللي المفروض يكون بالدرج نهاية اليوم.</div>
          <button class="btn primary" id="open-sh">${Icons.plus} فتح وردية</button></div></div></div>`;
      $('#open-sh', el).onclick = openDialog;
    }

    if (list.length) {
      $('#hist', el).appendChild(UI.table({
        compact: true,
        columns: [
          { title: 'الموظف', key: 'user_name' },
          { title: 'الفتح', render: (r) => UI.dateTimeStr(r.opened_at) },
          { title: 'الإقفال', render: (r) => r.closed_at ? UI.dateTimeStr(r.closed_at) : '<span class="badge ok dot">مفتوحة</span>' },
          { title: 'رصيد البداية', align: 'end', render: (r) => money(r.opening_cash, false) },
          { title: 'المتوقع', align: 'end', render: (r) => r.expected_cash !== null ? money(r.expected_cash, false) : '—' },
          { title: 'المعدود', align: 'end', render: (r) => r.closing_cash !== null ? money(r.closing_cash, false) : '—' },
          { title: 'الفرق', align: 'end', render: (r) => r.difference === null || r.difference === undefined ? '—'
              : `<b class="${Math.abs(r.difference) < 0.01 ? 'ok-text' : 'danger-text'}">${money(r.difference, false)}</b>` },
          { title: '', align: 'end', render: (r) => `<button class="btn ghost icon sm" data-v="${r.id}">${Icons.eye}</button>` },
        ],
        rows: list,
      }));
      $$('[data-v]', el).forEach((b) => b.onclick = () => detail(Number(b.dataset.v)));
    }
  }

  function currentCard(s) {
    const el = h(`<div class="col gap14">
      <div class="card">
        <div class="card-head"><h3>الوردية الحالية</h3>
          <span class="badge ok dot">مفتوحة من ${esc(UI.timeStr(s.shift.opened_at))}</span>
          <div class="spacer"></div>
          <button class="btn sm" id="cash-in">${Icons.arrowDown} إيداع</button>
          <button class="btn sm" id="cash-out">${Icons.arrowUp} سحب</button>
          <button class="btn primary sm" id="close-sh">${Icons.lock} إقفال الوردية</button>
        </div>
        <div class="card-body">
          <div class="grid g4 mb16">
            <div class="stat"><div class="lbl">عدد الفواتير</div><div class="val">${s.sales}</div></div>
            <div class="stat"><div class="lbl">إجمالي المبيعات</div><div class="val" style="font-size:21px">${money(s.salesTotal, false)}</div></div>
            <div class="stat"><div class="lbl">الربح</div><div class="val ok-text" style="font-size:21px">${money(s.profit, false)}</div></div>
            <div class="stat accent"><div class="lbl">الكاش المتوقع بالدرج</div>
              <div class="val" style="font-size:21px">${money(s.expectedCash, false)}</div>
              <div class="ico-box">${Icons.cash}</div></div>
          </div>
          <div class="grid g2">
            <div>
              <div class="bold small mb8">تفاصيل الحركة</div>
              ${line('رصيد بداية الوردية', s.shift.opening_cash)}
              ${line('مبيعات كاش', s.cash, 'ok')}
              ${line('تحصيل ديون كاش', s.collected, 'ok')}
              ${line('إيداعات على الدرج', s.cashIn, 'ok')}
              ${line('مرتجعات', -s.returnsTotal, 'danger')}
              ${line('مصروفات', -s.expenses, 'danger')}
              ${line('سحوبات من الدرج', -s.cashOut, 'danger')}
              <div class="row" style="justify-content:space-between;padding:10px 0;border-top:2px solid var(--border);margin-top:6px">
                <span class="bold">المفروض بالدرج</span><span class="bold" style="font-size:18px">${money(s.expectedCash)}</span></div>
            </div>
            <div>
              <div class="bold small mb8">طرق الدفع</div>
              ${line('كاش', s.cash)}
              ${line('شبكة', s.card)}
              ${line('آجل على الحساب', s.credit, 'warn')}
              ${line('ضريبة محصّلة', s.tax)}
            </div>
          </div>
        </div>
      </div>
    </div>`);

    $('#close-sh', el).onclick = () => closeDialog(s);
    $('#cash-in', el).onclick = () => cashDialog('in');
    $('#cash-out', el).onclick = () => cashDialog('out');
    return el;
  }

  function line(label, val, cls) {
    return `<div class="row" style="justify-content:space-between;padding:6px 0;border-bottom:1px solid var(--border)">
      <span class="muted small">${esc(label)}</span>
      <span class="${cls ? cls + '-text' : ''}">${money(val, false)}</span></div>`;
  }

  function openDialog() {
    const m = UI.modal({
      title: 'فتح وردية',
      width: 'narrow',
      body: `<div class="field mb12"><label>الكاش الموجود بالدرج الآن</label>
          <input class="input lg" id="o-c" type="number" step="0.01" value="0"></div>
        <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="o-n"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>فتح</button>`,
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const r = await API.safe('shifts.open', { openingCash: Number($('#o-c', m.el).value) || 0, note: $('#o-n', m.el).value.trim() });
      if (!r) return;
      UI.ok('تم فتح الوردية');
      m.close();
      render(container);
    };
  }

  function closeDialog(s) {
    const m = UI.modal({
      title: 'إقفال الوردية',
      body: `
        <div class="alert-box info mb16">${Icons.info}<div>
          عدّ الكاش الموجود بالدرج واكتب المبلغ، والبرنامج يقارنه بالمتوقع ويسجّل الفرق.</div></div>
        <div class="row gap14 mb16">
          <div class="stat" style="flex:1"><div class="lbl">المتوقع</div>
            <div class="val" style="font-size:22px">${money(s.expectedCash, false)}</div></div>
          <div class="field" style="flex:1"><label>المعدود فعلياً</label>
            <input class="input lg" id="c-c" type="number" step="0.01" value="${esc(s.expectedCash)}"></div>
        </div>
        <div id="diff" class="alert-box ok mb16">${Icons.check}<div>الصندوق مضبوط</div></div>
        <div class="field"><label>${esc(t('notes'))}</label><input class="input" id="c-n" placeholder="سبب الفرق إن وجد"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button>
               <button class="btn primary" data-ok>${Icons.lock} إقفال</button>`,
    });
    const upd = () => {
      const d = (Number($('#c-c', m.el).value) || 0) - s.expectedCash;
      const box = $('#diff', m.el);
      if (Math.abs(d) < 0.01) { box.className = 'alert-box ok mb16'; box.innerHTML = `${Icons.check}<div>الصندوق مضبوط تماماً</div>`; }
      else if (d > 0) { box.className = 'alert-box warn mb16'; box.innerHTML = `${Icons.warning}<div>زيادة بالدرج: <b>${money(d)}</b></div>`; }
      else { box.className = 'alert-box danger mb16'; box.innerHTML = `${Icons.alert}<div>عجز بالدرج: <b>${money(Math.abs(d))}</b></div>`; }
    };
    $('#c-c', m.el).oninput = upd;
    upd();
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const r = await API.safe('shifts.close', {
        shiftId: s.shift.id, closingCash: Number($('#c-c', m.el).value) || 0, note: $('#c-n', m.el).value.trim(),
      });
      if (!r) return;
      m.close();
      UI.ok('تم إقفال الوردية');
      summaryDialog(r);
      render(container);
    };
  }

  function summaryDialog(s) {
    const m = UI.modal({
      title: 'ملخص الوردية',
      width: 'narrow',
      body: `
        <div class="grid g2 mb16">
          <div class="stat"><div class="lbl">الفواتير</div><div class="val">${s.sales}</div></div>
          <div class="stat"><div class="lbl">المبيعات</div><div class="val" style="font-size:20px">${money(s.salesTotal, false)}</div></div>
        </div>
        ${line('المتوقع بالدرج', s.expectedCash)}
        ${line('المعدود', s.closingCash)}
        <div class="row" style="justify-content:space-between;padding:10px 0;border-top:2px solid var(--border)">
          <span class="bold">الفرق</span>
          <span class="bold ${Math.abs(s.difference) < 0.01 ? 'ok-text' : 'danger-text'}" style="font-size:19px">${money(s.difference)}</span></div>`,
      footer: `<button class="btn" data-print>${Icons.print} طباعة</button>
               <div class="spacer"></div><button class="btn primary" data-close2>${esc(t('close'))}</button>`,
    });
    $('[data-print]', m.el).onclick = () => printShift(s);
    $('[data-close2]', m.el).onclick = m.close;
  }

  function printShift(s) {
    const st = API.settings;
    const html = `<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><style>
      @page{size:80mm auto;margin:0} body{font-family:'Cairo',sans-serif;width:80mm;padding:5mm 4mm;font-size:12px}
      .c{text-align:center} .r{display:flex;justify-content:space-between;padding:3px 0;border-bottom:1px dotted #bbb}
      .g{font-weight:700;font-size:15px;border-top:1.5px solid #000;border-bottom:1.5px solid #000;padding:5px 0;margin:5px 0}
      h2{font-size:15px;margin:6px 0}
    </style></head><body>
      <div class="c"><div style="font-size:17px;font-weight:700">${UI.esc(st.store_name || '')}</div>
        <h2>تقرير إقفال وردية</h2>
        <div>${UI.esc(s.shift.user_name || API.user.name)}</div>
        <div>${UI.esc(UI.dateTimeStr(s.shift.opened_at))} — ${UI.esc(UI.dateTimeStr(new Date().toISOString()))}</div></div>
      <div class="r"><span>عدد الفواتير</span><span>${s.sales}</span></div>
      <div class="r"><span>إجمالي المبيعات</span><span>${money(s.salesTotal, false)}</span></div>
      <div class="r"><span>مبيعات كاش</span><span>${money(s.cash, false)}</span></div>
      <div class="r"><span>مبيعات شبكة</span><span>${money(s.card, false)}</span></div>
      <div class="r"><span>بيع آجل</span><span>${money(s.credit, false)}</span></div>
      <div class="r"><span>مرتجعات</span><span>${money(s.returnsTotal, false)}</span></div>
      <div class="r"><span>مصروفات</span><span>${money(s.expenses, false)}</span></div>
      <div class="r"><span>رصيد البداية</span><span>${money(s.shift.opening_cash, false)}</span></div>
      <div class="g" style="display:flex;justify-content:space-between"><span>المتوقع بالدرج</span><span>${money(s.expectedCash, false)}</span></div>
      <div class="r"><span>المعدود</span><span>${money(s.closingCash, false)}</span></div>
      <div class="g" style="display:flex;justify-content:space-between"><span>الفرق</span><span>${money(s.difference, false)}</span></div>
      <div class="c" style="margin-top:10px">توقيع الموظف: ____________</div>
    </body></html>`;
    window.baqala.print(html, { silent: false, width: 80 });
  }

  function cashDialog(type) {
    const m = UI.modal({
      title: type === 'in' ? 'إيداع في الدرج' : 'سحب من الدرج',
      width: 'narrow',
      body: `<div class="field mb12"><label>${esc(t('amount'))}</label>
          <input class="input lg" id="cm-a" type="number" step="0.01"></div>
        <div class="field"><label>السبب</label><input class="input" id="cm-r"></div>`,
      footer: `<button class="btn" data-cancel>${esc(t('cancel'))}</button><button class="btn primary" data-ok>${esc(t('confirm'))}</button>`,
    });
    $('[data-cancel]', m.el).onclick = m.close;
    $('[data-ok]', m.el).onclick = async () => {
      const r = await API.safe('shifts.cashMove', {
        type, amount: Number($('#cm-a', m.el).value), reason: $('#cm-r', m.el).value.trim(),
      });
      if (!r) return;
      UI.ok('تم التسجيل');
      m.close();
      render(container);
    };
  }

  async function detail(id) {
    const s = await API.safe('shifts.summary', { shiftId: id });
    if (!s) return;
    UI.modal({
      title: `وردية ${UI.dateStr(s.shift.opened_at)}`,
      body: `
        <div class="grid g2 mb16">
          <div class="stat"><div class="lbl">الفواتير</div><div class="val">${s.sales}</div></div>
          <div class="stat"><div class="lbl">المبيعات</div><div class="val" style="font-size:20px">${money(s.salesTotal, false)}</div></div>
        </div>
        ${line('كاش', s.cash)}${line('شبكة', s.card)}${line('آجل', s.credit)}
        ${line('مرتجعات', s.returnsTotal)}${line('مصروفات', s.expenses)}
        ${line('المتوقع', s.expectedCash)}${line('المعدود', s.shift.closing_cash || 0)}
        <div class="row" style="justify-content:space-between;padding:10px 0;border-top:2px solid var(--border)">
          <span class="bold">الفرق</span><span class="bold">${money(s.shift.difference || 0)}</span></div>`,
      footer: null,
    });
  }

  return { render };
})();
