/* لوحة تحكم صاحب البقالة */
Pages.dashboard = (() => {
  const { h, $, $$, esc, money, moneyHTML } = UI;
  let day = UI.todayStr();

  async function render(view, { topExtra }) {
    const d = await API.safe('reports.dashboard', { day });
    if (!d) return;

    topExtra.innerHTML = '';
    const dayPick = h(`<input type="date" class="input" style="width:150px" value="${esc(day)}">`);
    dayPick.onchange = async (e) => { day = e.target.value; await render(view, { topExtra }); };
    const rf = h(`<button class="btn ghost icon sm" title="${esc(t('refresh'))}">${Icons.refresh}</button>`);
    rf.onclick = () => render(view, { topExtra });
    topExtra.appendChild(dayPick);
    topExtra.appendChild(rf);

    const T = d.today, Y = d.yesterday, M = d.month;
    const trend = (a, b) => {
      if (!b) return '';
      const p = ((a - b) / b) * 100;
      const up = p >= 0;
      return `<span class="trend ${up ? 'up' : 'down'}">${up ? '▲' : '▼'} ${Math.abs(p).toFixed(0)}%</span>`;
    };
    const alertCount = d.alerts.counts.out + d.alerts.counts.expired + d.alerts.counts.low + d.alerts.counts.expiring;

    view.innerHTML = '';
    const el = h(`<div class="col gap14">

      <!-- الأرقام الرئيسية -->
      <div class="grid g4">
        <div class="stat accent">
          <div class="lbl">${esc(t('daily_income'))}</div>
          <div class="val">${money(T.netSales, false)} <small>${esc(API.settings.currency_ar || Riyal.CHAR)}</small></div>
          <div class="sub">${esc(UI.dayName(day))} ${esc(UI.dateStr(day))} · ${T.invoices} فاتورة ${trend(T.netSales, Y.netSales)}</div>
          <div class="ico-box">${Icons.coins}</div>
        </div>
        <div class="stat">
          <div class="lbl">${esc(t('net_profit'))} اليوم</div>
          <div class="val ${T.netProfit >= 0 ? 'ok-text' : 'danger-text'}">${money(T.netProfit, false)}</div>
          <div class="sub">مجمل الربح ${money(T.grossProfit)} − مصروفات ${money(T.expenses)}</div>
          <div class="ico-box" style="background:var(--ok-bg);color:var(--ok)">${Icons.chart}</div>
        </div>
        <div class="stat">
          <div class="lbl">${esc(t('avg_invoice'))}</div>
          <div class="val">${money(T.avgInvoice, false)}</div>
          <div class="sub">${UI.qty(T.itemsSold)} قطعة مباعة</div>
          <div class="ico-box" style="background:var(--info-bg);color:var(--info)">${Icons.receipt}</div>
        </div>
        <div class="stat">
          <div class="lbl">مبيعات الشهر</div>
          <div class="val">${money(M.netSales, false)}</div>
          <div class="sub">${M.invoices} فاتورة · ربح ${money(M.netProfit)}</div>
          <div class="ico-box" style="background:var(--warn-bg);color:var(--warn)">${Icons.calendar}</div>
        </div>
      </div>

      <!-- طرق الدفع والديون -->
      <div class="grid g4">
        <div class="stat"><div class="lbl">${Icons.cash} ${esc(t('cash'))}</div><div class="val" style="font-size:20px">${money(T.cash, false)}</div></div>
        <div class="stat"><div class="lbl">${Icons.card} ${esc(t('card'))}</div><div class="val" style="font-size:20px">${money(T.card, false)}</div></div>
        <div class="stat"><div class="lbl">${Icons.credit} بيع آجل اليوم</div><div class="val" style="font-size:20px">${money(T.credit, false)}</div></div>
        <div class="stat"><div class="lbl">${Icons.alert} تنبيهات المخزون</div>
          <div class="val ${alertCount ? 'warn-text' : ''}" style="font-size:20px">${alertCount}</div>
          <div class="sub">${d.alerts.counts.out} منتهي · ${d.alerts.counts.expired} منتهي الصلاحية</div></div>
      </div>

      <div class="grid" style="grid-template-columns:1.6fr 1fr">
        <!-- الرسم البياني -->
        <div class="card">
          <div class="card-head"><h3>مبيعات آخر ٧ أيام</h3><div class="spacer"></div>
            <span class="small muted">الإجمالي ${money(d.series.reduce((s, x) => s + x.total, 0))}</span></div>
          <div class="card-body" id="chart"></div>
        </div>

        <!-- الديون -->
        <div class="card">
          <div class="card-head"><h3>الديون</h3></div>
          <div class="card-body">
            <div class="row mb12" style="justify-content:space-between">
              <div><div class="small muted">لك عند العملاء</div>
                <div class="bold danger-text" style="font-size:20px">${money(d.debts.customersDebt)}</div>
                <div class="small muted">${d.debts.customersCount} عميل</div></div>
              <div style="text-align:end"><div class="small muted">عليك للموردين</div>
                <div class="bold warn-text" style="font-size:20px">${money(d.debts.suppliersDebt)}</div>
                <div class="small muted">${d.debts.suppliersCount} مورد</div></div>
            </div>
            <div class="divider"></div>
            <div class="small bold mb8">أعلى العملاء ديناً</div>
            ${d.debts.topCustomers.length ? d.debts.topCustomers.slice(0, 5).map((c) => `
              <div class="row" style="justify-content:space-between;padding:5px 0">
                <span>${esc(c.name)}</span><span class="bold danger-text">${money(c.balance)}</span></div>`).join('')
              : '<div class="small muted">ما فيه ديون على العملاء</div>'}
          </div>
        </div>
      </div>

      <!-- أداء الموظفين -->
      <div class="card">
        <div class="card-head"><h3>وش سوّى الموظفين اليوم</h3><div class="spacer"></div>
          <button class="btn sm" id="go-activity">${Icons.history} سجل النشاط</button></div>
        <div class="card-body tight" id="staff"></div>
      </div>

      <div class="grid g2">
        <!-- الأكثر مبيعاً -->
        <div class="card">
          <div class="card-head"><h3>الأكثر مبيعاً هذا الشهر</h3></div>
          <div class="card-body tight" id="top"></div>
        </div>
        <!-- تنبيهات -->
        <div class="card">
          <div class="card-head"><h3>تحتاج انتباهك</h3><div class="spacer"></div>
            <button class="btn sm" id="go-inv">${esc(t('inventory'))}</button></div>
          <div class="card-body" id="alerts"></div>
        </div>
      </div>

      <!-- آخر الفواتير والنشاط -->
      <div class="grid g2">
        <div class="card">
          <div class="card-head"><h3>آخر الفواتير</h3></div>
          <div class="card-body tight" id="recent"></div>
        </div>
        <div class="card">
          <div class="card-head"><h3>آخر الحركات</h3></div>
          <div class="card-body tight" id="acts" style="max-height:340px;overflow:auto"></div>
        </div>
      </div>
    </div>`);
    view.appendChild(el);

    /* الرسم */
    $('#chart', el).appendChild(UI.barChart(d.series, { valueKey: 'total', labelKey: 'day' }));

    /* الموظفون */
    const staff = d.staff.filter((s) => s.user.active || s.invoices);
    $('#staff', el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الموظف', render: (r) => `<div class="row gap6">
            <div class="avatar" style="width:26px;height:26px;font-size:11px;background:${esc(r.user.color || UI.colorFor(r.user.name))}">${esc(UI.initials(r.user.name))}</div>
            <div><div class="bold" style="font-size:13px">${esc(r.user.name)}</div>
              <div class="small muted">${esc(App.roleName(r.user.role))}</div></div></div>` },
        { title: 'فواتير', align: 'center', render: (r) => `<span class="num">${r.invoices}</span>` },
        { title: 'المبيعات', align: 'end', render: (r) => moneyHTML(r.total) },
        { title: 'كاش', align: 'end', render: (r) => moneyHTML(r.cash) },
        { title: 'شبكة', align: 'end', render: (r) => moneyHTML(r.card) },
        { title: 'آجل', align: 'end', render: (r) => r.credit ? `<span class="warn-text">${money(r.credit)}</span>` : '-' },
        { title: 'إرجاع', align: 'center', render: (r) => r.returns ? `<span class="badge warn">${r.returns}</span>` : '-' },
        { title: 'إلغاء', align: 'center', render: (r) => r.voids ? `<span class="badge danger">${r.voids}</span>` : '-' },
        { title: 'الوردية', align: 'center', render: (r) => r.shift
            ? (r.shift.status === 'open' ? '<span class="badge ok dot">مفتوحة</span>' : '<span class="badge">مقفلة</span>')
            : '<span class="muted small">-</span>' },
        { title: 'آخر حركة', align: 'center', render: (r) => r.lastAction ? `<span class="small">${esc(UI.timeStr(r.lastAction))}</span>` : '-' },
        { title: '', align: 'end', render: (r) => `<button class="btn ghost sm" data-staff="${r.user.id}">${Icons.eye}</button>` },
      ],
      rows: staff,
      empty: 'ما فيه حركة اليوم',
    }));
    $$('[data-staff]', el).forEach((b) => b.onclick = () => staffDetail(staff.find((s) => s.user.id === Number(b.dataset.staff))));

    /* الأكثر مبيعاً */
    $('#top', el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الصنف', key: 'name' },
        { title: 'الكمية', align: 'center', render: (r) => UI.qty(r.qty) },
        { title: 'المبيعات', align: 'end', render: (r) => moneyHTML(r.total) },
        { title: 'الربح', align: 'end', render: (r) => `<span class="ok-text">${money(r.profit)}</span>` },
      ],
      rows: d.topProducts,
      empty: 'ما فيه مبيعات بعد',
    }));

    /* التنبيهات */
    const a = d.alerts;
    $('#alerts', el).innerHTML = alertCount ? `
      ${a.out.length ? `<div class="alert-box danger mb8">${Icons.alert}<div>
        <b>${a.out.length} صنف خلص من المخزون</b>
        <div class="small">${esc(a.out.slice(0, 4).map((x) => x.name_ar).join('، '))}${a.out.length > 4 ? ' …' : ''}</div></div></div>` : ''}
      ${a.expired.length ? `<div class="alert-box danger mb8">${Icons.warning}<div>
        <b>${a.expired.length} صنف منتهي الصلاحية</b>
        <div class="small">${esc(a.expired.slice(0, 4).map((x) => x.name_ar).join('، '))}</div></div></div>` : ''}
      ${a.low.length ? `<div class="alert-box warn mb8">${Icons.warning}<div>
        <b>${a.low.length} صنف قارب على الخلاص</b>
        <div class="small">${esc(a.low.slice(0, 4).map((x) => `${x.name_ar} (${UI.qty(x.stock)})`).join('، '))}</div></div></div>` : ''}
      ${a.expiring.length ? `<div class="alert-box info">${Icons.calendar}<div>
        <b>${a.expiring.length} صنف تنتهي صلاحيته قريباً</b>
        <div class="small">${esc(a.expiring.slice(0, 4).map((x) => `${x.name_ar} (${UI.dateStr(x.expiry_date)})`).join('، '))}</div></div></div>` : ''}
    ` : `<div class="alert-box ok">${Icons.check}<div>كل شيء تمام، ما فيه تنبيهات على المخزون.</div></div>`;

    /* آخر الفواتير */
    $('#recent', el).appendChild(UI.table({
      compact: true,
      columns: [
        { title: 'الفاتورة', render: (r) => `<span class="num">${esc(r.invoice_no)}</span>` },
        { title: 'الوقت', render: (r) => UI.timeStr(r.created_at) },
        { title: 'الكاشير', key: 'user_name' },
        { title: 'المبلغ', align: 'end', render: (r) => r.status === 'void'
            ? `<span class="muted" style="text-decoration:line-through">${money(r.total)}</span>`
            : moneyHTML(r.total) },
      ],
      rows: d.recentSales,
      onRowClick: (r) => Pages.sales.showInvoice(r.id),
      empty: 'ما فيه فواتير اليوم',
    }));

    /* آخر الحركات */
    $('#acts', el).innerHTML = d.recentActivity.length ? d.recentActivity.map((x) => `
      <div style="padding:9px 14px;border-bottom:1px solid var(--border)">
        <div class="row" style="justify-content:space-between">
          <span class="small bold">${esc(x.user_name || 'النظام')}</span>
          <span class="small muted">${esc(UI.timeStr(x.created_at))}</span></div>
        <div class="small muted">${esc(x.details || x.action)}</div>
      </div>`).join('') : UI.emptyState('ما فيه حركات');

    $('#go-activity', el).onclick = () => App.go('activity');
    $('#go-inv', el).onclick = () => App.go('inventory');
  }

  function staffDetail(s) {
    if (!s) return;
    const m = UI.modal({
      title: `${s.user.name} — ${UI.dateStr(day)}`,
      width: 'wide',
      body: `
        <div class="grid g4 mb16">
          <div class="stat"><div class="lbl">الفواتير</div><div class="val">${s.invoices}</div></div>
          <div class="stat"><div class="lbl">المبيعات</div><div class="val">${money(s.total, false)}</div></div>
          <div class="stat"><div class="lbl">الربح</div><div class="val ok-text">${money(s.profit, false)}</div></div>
          <div class="stat"><div class="lbl">عدد الحركات</div><div class="val">${s.actions}</div></div>
        </div>
        <div class="grid g3 mb16">
          <div class="card" style="padding:12px"><div class="small muted">كاش</div><div class="bold">${money(s.cash)}</div></div>
          <div class="card" style="padding:12px"><div class="small muted">شبكة</div><div class="bold">${money(s.card)}</div></div>
          <div class="card" style="padding:12px"><div class="small muted">آجل</div><div class="bold">${money(s.credit)}</div></div>
        </div>
        ${s.shift ? `<div class="alert-box info mb16">${Icons.clock}<div>
          الوردية: من ${esc(UI.timeStr(s.shift.opened_at))}
          ${s.shift.closed_at ? ' إلى ' + esc(UI.timeStr(s.shift.closed_at)) : ' (ما زالت مفتوحة)'}
          ${s.shift.difference !== null && s.shift.difference !== undefined
            ? ` · فرق الصندوق: <b>${money(s.shift.difference)}</b>` : ''}</div></div>` : ''}
        <div class="bold mb8">أكثر الأصناف اللي باعها</div>
        ${s.topItems.length ? s.topItems.map((x) => `
          <div class="row" style="justify-content:space-between;padding:5px 0;border-bottom:1px solid var(--border)">
            <span>${esc(x.name)}</span><span class="bold num">${UI.qty(x.q)}</span></div>`).join('')
          : '<div class="muted small">ما باع شيء اليوم</div>'}
        <div class="row gap6 mt16">
          <button class="btn sm" id="sd-log">${Icons.history} سجل حركاته</button>
          <button class="btn sm" id="sd-inv">${Icons.receipt} فواتيره</button>
        </div>`,
      footer: null,
    });
    $('#sd-log', m.el).onclick = () => { m.close(); App.go('activity'); setTimeout(() => Pages.activity.filterUser(s.user.id, day), 300); };
    $('#sd-inv', m.el).onclick = () => { m.close(); App.go('sales'); setTimeout(() => Pages.sales.filterUser(s.user.id, day), 300); };
  }

  return { render };
})();
