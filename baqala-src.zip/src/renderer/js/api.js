/* جسر الاتصال مع النواة */
const API = (() => {
  let token = localStorage.getItem('baqala_token') || '';
  let user = null;
  try { user = JSON.parse(localStorage.getItem('baqala_user') || 'null'); } catch (_) {}
  let settings = {};
  let appInfo = {};

  function setSession(tk, u) {
    token = tk || '';
    user = u || null;
    if (tk) localStorage.setItem('baqala_token', tk); else localStorage.removeItem('baqala_token');
    if (u) localStorage.setItem('baqala_user', JSON.stringify(u)); else localStorage.removeItem('baqala_user');
  }

  function unwrap(res) {
    if (!res) throw { code: 'NO_RESPONSE', ar: 'ما وصل رد من البرنامج', en: 'No response' };
    if (res.ok) return res.data;
    const e = res.error || { code: 'ERROR', ar: 'خطأ', en: 'Error' };
    throw e;
  }

  async function login(username, password) {
    const data = unwrap(await window.baqala.login({ username, password }));
    setSession(data.token, data.user);
    return data;
  }

  async function logout() {
    try { await window.baqala.logout({ token }); } catch (_) {}
    setSession('', null);
  }

  /** الاستدعاء الأساسي - يرمي الخطأ ليتعامل معه المستدعي */
  async function call(action, payload) {
    const res = await window.baqala.call(token, action, payload || {});
    return unwrap(res);
  }

  /** استدعاء آمن: يعرض التنبيه ويرجع null عند الخطأ */
  async function safe(action, payload, opts = {}) {
    try {
      return await call(action, payload);
    } catch (e) {
      if (e.code === 'UNAUTHENTICATED') {
        setSession('', null);
        if (window.App) App.showLogin();
        return null;
      }
      if (!opts.silent) UI.err(I18N.current() === 'en' ? (e.en || e.ar) : (e.ar || e.en));
      if (opts.rethrow) throw e;
      return null;
    }
  }

  function msg(e) { return I18N.current() === 'en' ? (e.en || e.ar || 'Error') : (e.ar || e.en || 'خطأ'); }

  async function loadSettings() {
    settings = (await safe('settings.get')) || {};
    return settings;
  }

  async function loadInfo() {
    const r = await window.baqala.info();
    appInfo = r.ok ? r.data : {};
    return appInfo;
  }

  function can(perm) {
    if (!user) return false;
    if (user.role === 'owner') return true;
    return (user.permissions || []).includes(perm);
  }

  return {
    get token() { return token; },
    get user() { return user; },
    get settings() { return settings; },
    get info() { return appInfo; },
    set settings(v) { settings = v; },
    setSession, login, logout, call, safe, msg, loadSettings, loadInfo, can,
  };
})();
