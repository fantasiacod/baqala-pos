/* ترجمة الواجهة - عربي / إنجليزي */
const I18N = (() => {
  const AR = {
    app_name: 'بقالتي', app_sub: 'نظام المحاسبة والمخزون',
    /* عام */
    save: 'حفظ', cancel: 'إلغاء', close: 'إغلاق', delete: 'حذف', edit: 'تعديل', add: 'إضافة',
    search: 'بحث', print: 'طباعة', export: 'تصدير', import: 'استيراد', confirm: 'تأكيد',
    yes: 'نعم', no: 'لا', all: 'الكل', none: 'لا شيء', total: 'الإجمالي', name: 'الاسم',
    phone: 'الجوال', notes: 'ملاحظات', date: 'التاريخ', time: 'الوقت', from: 'من', to: 'إلى',
    today: 'اليوم', yesterday: 'أمس', week: 'هذا الأسبوع', month: 'هذا الشهر', year: 'هذه السنة',
    custom: 'فترة مخصصة', loading: 'جاري التحميل', no_data: 'ما فيه بيانات', actions: 'إجراءات',
    back: 'رجوع', next: 'التالي', refresh: 'تحديث', apply: 'تطبيق', reset: 'إعادة ضبط',
    amount: 'المبلغ', qty: 'الكمية', price: 'السعر', status: 'الحالة', type: 'النوع',
    more: 'المزيد', details: 'التفاصيل', balance: 'الرصيد', remaining: 'المتبقي', paid: 'المدفوع',
    /* التنقل */
    nav_sales: 'المبيعات', nav_inventory: 'المخزون', nav_accounts: 'الحسابات', nav_admin: 'الإدارة',
    pos: 'الكاشير', dashboard: 'لوحة التحكم', products: 'الأصناف', inventory: 'الجرد والمخزون',
    purchases: 'المشتريات', suppliers: 'الموردون', customers: 'العملاء', debts: 'الديون',
    sales_list: 'الفواتير', reports: 'التقارير', users: 'الموظفون', activity: 'سجل النشاط',
    shifts: 'الورديات', settings: 'الإعدادات', expenses: 'المصروفات', forms: 'النماذج',
    /* الدخول */
    login: 'تسجيل الدخول', logout: 'تسجيل الخروج', username: 'اسم المستخدم', password: 'كلمة المرور',
    login_btn: 'دخول', welcome: 'أهلاً بك', wrong_login: 'بيانات الدخول غير صحيحة',
    change_password: 'تغيير كلمة المرور', old_password: 'كلمة المرور الحالية', new_password: 'كلمة المرور الجديدة',
    /* الكاشير */
    scan_hint: 'امسح الباركود أو اكتب اسم الصنف…', cart: 'السلة', cart_empty: 'السلة فاضية - امسح صنف للبدء',
    subtotal: 'المجموع', discount: 'الخصم', vat: 'ضريبة القيمة المضافة', grand_total: 'الإجمالي',
    pay: 'الدفع', cash: 'كاش', card: 'شبكة', credit: 'آجل', mixed: 'مختلط',
    received: 'المستلم', change: 'الباقي', complete_sale: 'إتمام البيع', new_sale: 'فاتورة جديدة',
    hold: 'تعليق', clear_cart: 'تفريغ السلة', customer: 'العميل', walk_in: 'عميل نقدي',
    reprint: 'إعادة طباعة آخر فاتورة', item_not_found: 'الصنف غير موجود',
    add_manual: 'إضافة صنف يدوي', return_invoice: 'فاتورة إرجاع',
    /* الأصناف */
    product: 'الصنف', barcode: 'الباركود', category: 'التصنيف', unit: 'الوحدة',
    cost_price: 'سعر التكلفة', sale_price: 'سعر البيع', stock: 'الكمية', min_stock: 'حد التنبيه',
    expiry: 'تاريخ الانتهاء', new_product: 'صنف جديد', taxable: 'خاضع للضريبة',
    low_stock: 'كمية منخفضة', out_of_stock: 'منتهي', expiring_soon: 'قرب انتهاء الصلاحية', expired: 'منتهي الصلاحية',
    profit: 'الربح', margin: 'هامش الربح',
    /* التقارير */
    daily_income: 'دخل اليوم', net_sales: 'صافي المبيعات', invoices: 'عدد الفواتير',
    avg_invoice: 'متوسط الفاتورة', gross_profit: 'مجمل الربح', net_profit: 'صافي الربح',
    /* الإعدادات */
    store_info: 'بيانات المحل', appearance: 'المظهر', theme: 'الوضع', light: 'فاتح', dark: 'داكن',
    accent_color: 'اللون الرئيسي', font: 'نوع الخط', font_size: 'حجم الخط', language: 'اللغة',
    tax_settings: 'إعدادات الضريبة', enable_tax: 'تفعيل ضريبة القيمة المضافة', vat_number: 'الرقم الضريبي',
    backup: 'نسخة احتياطية', restore: 'استعادة',
  };

  const EN = {
    app_name: 'Baqala', app_sub: 'Accounting & Inventory',
    save: 'Save', cancel: 'Cancel', close: 'Close', delete: 'Delete', edit: 'Edit', add: 'Add',
    search: 'Search', print: 'Print', export: 'Export', import: 'Import', confirm: 'Confirm',
    yes: 'Yes', no: 'No', all: 'All', none: 'None', total: 'Total', name: 'Name',
    phone: 'Phone', notes: 'Notes', date: 'Date', time: 'Time', from: 'From', to: 'To',
    today: 'Today', yesterday: 'Yesterday', week: 'This week', month: 'This month', year: 'This year',
    custom: 'Custom range', loading: 'Loading', no_data: 'No data', actions: 'Actions',
    back: 'Back', next: 'Next', refresh: 'Refresh', apply: 'Apply', reset: 'Reset',
    amount: 'Amount', qty: 'Qty', price: 'Price', status: 'Status', type: 'Type',
    more: 'More', details: 'Details', balance: 'Balance', remaining: 'Remaining', paid: 'Paid',
    nav_sales: 'Sales', nav_inventory: 'Inventory', nav_accounts: 'Accounts', nav_admin: 'Admin',
    pos: 'Point of Sale', dashboard: 'Dashboard', products: 'Products', inventory: 'Stock',
    purchases: 'Purchases', suppliers: 'Suppliers', customers: 'Customers', debts: 'Debts',
    sales_list: 'Invoices', reports: 'Reports', users: 'Staff', activity: 'Activity log',
    shifts: 'Shifts', settings: 'Settings', expenses: 'Expenses', forms: 'Documents',
    login: 'Sign in', logout: 'Sign out', username: 'Username', password: 'Password',
    login_btn: 'Sign in', welcome: 'Welcome', wrong_login: 'Invalid credentials',
    change_password: 'Change password', old_password: 'Current password', new_password: 'New password',
    scan_hint: 'Scan barcode or type product name…', cart: 'Cart', cart_empty: 'Cart is empty - scan an item to start',
    subtotal: 'Subtotal', discount: 'Discount', vat: 'VAT', grand_total: 'Total',
    pay: 'Payment', cash: 'Cash', card: 'Card', credit: 'Credit', mixed: 'Mixed',
    received: 'Received', change: 'Change', complete_sale: 'Complete sale', new_sale: 'New sale',
    hold: 'Hold', clear_cart: 'Clear cart', customer: 'Customer', walk_in: 'Walk-in',
    reprint: 'Reprint last receipt', item_not_found: 'Item not found',
    add_manual: 'Add manual item', return_invoice: 'Return invoice',
    product: 'Product', barcode: 'Barcode', category: 'Category', unit: 'Unit',
    cost_price: 'Cost', sale_price: 'Price', stock: 'Stock', min_stock: 'Reorder level',
    expiry: 'Expiry date', new_product: 'New product', taxable: 'Taxable',
    low_stock: 'Low stock', out_of_stock: 'Out of stock', expiring_soon: 'Expiring soon', expired: 'Expired',
    profit: 'Profit', margin: 'Margin',
    daily_income: "Today's income", net_sales: 'Net sales', invoices: 'Invoices',
    avg_invoice: 'Avg. invoice', gross_profit: 'Gross profit', net_profit: 'Net profit',
    store_info: 'Store info', appearance: 'Appearance', theme: 'Theme', light: 'Light', dark: 'Dark',
    accent_color: 'Accent color', font: 'Font', font_size: 'Font size', language: 'Language',
    tax_settings: 'Tax settings', enable_tax: 'Enable VAT', vat_number: 'VAT number',
    backup: 'Backup', restore: 'Restore',
  };

  let lang = 'ar';
  const dicts = { ar: AR, en: EN };

  function setLang(l) {
    lang = dicts[l] ? l : 'ar';
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
    document.body.className = lang === 'ar' ? 'rtl' : 'ltr';
  }
  function t(key, fallback) {
    return dicts[lang][key] || dicts.ar[key] || fallback || key;
  }
  function current() { return lang; }
  function isRTL() { return lang === 'ar'; }

  return { t, setLang, current, isRTL };
})();
const t = I18N.t;
