/* ------------------------------------------------------------------
   قص الصور إلى مقاس ثابت.

   المستخدم يختار أي صورة مهما كان مقاسها، ويقصّها بالسحب والتكبير
   داخل إطار مربّع، فتطلع بالمقاس المطلوب بالضبط (شعار المحل مثلاً).

   Cropper.open(dataUrl, { size, round, title })  →  Promise<dataUrl|null>
------------------------------------------------------------------- */
const Cropper = (() => {
  const { $, esc } = UI;

  const VIEW = 300;          // حجم إطار المعاينة على الشاشة
  const MAX_ZOOM = 5;

  /** تدوير الصورة ٩٠ درجة داخل لوحة مخفية وإرجاعها كصورة جديدة */
  function rotate90(img) {
    const c = document.createElement('canvas');
    c.width = img.height; c.height = img.width;
    const x = c.getContext('2d');
    x.translate(c.width / 2, c.height / 2);
    x.rotate(Math.PI / 2);
    x.drawImage(img, -img.width / 2, -img.height / 2);
    return load(c.toDataURL('image/png'));
  }

  function load(src) {
    return new Promise((res, rej) => {
      const im = new Image();
      im.onload = () => res(im);
      im.onerror = () => rej(new Error('تعذّرت قراءة الصورة'));
      im.src = src;
    });
  }

  /**
   * يفتح شاشة القص.
   * @param {string} src صورة كـ data URL
   * @param {object} opts { size: مقاس الناتج بالبكسل, round: إطار دائري, title }
   * @returns {Promise<string|null>} صورة PNG بالمقاس المطلوب، أو null إذا ألغى
   */
  async function open(src, opts = {}) {
    const size = opts.size || 400;
    const round = !!opts.round;
    let img;
    try { img = await load(src); } catch (e) { UI.err(e.message); return null; }

    return new Promise((resolve) => {
      let done = false;
      const finish = (v) => { if (done) return; done = true; m.close(); resolve(v); };

      const m = UI.modal({
        title: opts.title || 'قص الشعار',
        width: 'narrow',
        closeOnBackdrop: false,
        body: `
          <div class="center">
            <div id="cr-stage" style="position:relative;width:${VIEW}px;height:${VIEW}px;margin:0 auto;
                 border-radius:${round ? '50%' : '14px'};overflow:hidden;background:var(--bg-2);
                 border:2px solid var(--border);cursor:grab;touch-action:none">
              <canvas id="cr-canvas" width="${VIEW}" height="${VIEW}"
                      style="display:block;width:${VIEW}px;height:${VIEW}px"></canvas>
            </div>
            <div class="muted small mt8">اسحب الصورة لتحريكها، وكبّرها بالشريط أو بعجلة الفأرة</div>
          </div>
          <div class="row gap8 mt12" style="align-items:center">
            <span class="muted small">تصغير</span>
            <input type="range" id="cr-zoom" min="100" max="${MAX_ZOOM * 100}" value="100" style="flex:1">
            <span class="muted small">تكبير</span>
          </div>
          <div class="row gap6 mt8" style="justify-content:center">
            <button class="btn sm" id="cr-rot">${Icons.refresh} تدوير ٩٠°</button>
            <button class="btn sm" id="cr-fit">ملء الإطار</button>
            <button class="btn sm" id="cr-all">الصورة كاملة</button>
          </div>
          <div class="muted small mt12 center">الناتج: ${size} × ${size} بكسل</div>`,
        footer: `<button class="btn" id="cr-cancel">إلغاء</button>
                 <button class="btn primary" id="cr-ok">${Icons.check} حفظ</button>`,
        onClose: () => { if (!done) { done = true; resolve(null); } },
      });

      const stage = $('#cr-stage', m.el);
      const cv = $('#cr-canvas', m.el);
      const ctx = cv.getContext('2d');
      const zoomEl = $('#cr-zoom', m.el);

      // "cover" يملأ الإطار، و"contain" يعرض الصورة كاملة داخله
      const coverScale = () => Math.max(VIEW / img.width, VIEW / img.height);
      const containScale = () => Math.min(VIEW / img.width, VIEW / img.height);

      let zoom = 1;          // مضروب في coverScale
      let x = 0, y = 0;      // موضع الزاوية العليا للصورة داخل الإطار
      let letterbox = false; // وضع «الصورة كاملة»: يسمح بفراغ حول الصورة

      const drawW = () => img.width * (letterbox ? containScale() : coverScale()) * zoom;
      const drawH = () => img.height * (letterbox ? containScale() : coverScale()) * zoom;

      function clamp() {
        const w = drawW(), h = drawH();
        if (w >= VIEW) x = Math.min(0, Math.max(VIEW - w, x));
        else x = Math.min(VIEW - w, Math.max(0, x));   // أصغر من الإطار: يبقى داخله
        if (h >= VIEW) y = Math.min(0, Math.max(VIEW - h, y));
        else y = Math.min(VIEW - h, Math.max(0, y));
      }

      function center() { x = (VIEW - drawW()) / 2; y = (VIEW - drawH()) / 2; }

      function paint() {
        clamp();
        ctx.clearRect(0, 0, VIEW, VIEW);
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(img, x, y, drawW(), drawH());
      }

      function setZoom(z, ax, ay) {
        const old = zoom;
        zoom = Math.min(MAX_ZOOM, Math.max(1, z));
        if (zoom === old) return;
        // نكبّر حول نقطة الفأرة حتى ما تقفز الصورة
        const cx = ax === undefined ? VIEW / 2 : ax;
        const cy = ay === undefined ? VIEW / 2 : ay;
        const k = zoom / old;
        x = cx - (cx - x) * k;
        y = cy - (cy - y) * k;
        zoomEl.value = Math.round(zoom * 100);
        paint();
      }

      /* ------------------------------- تحكّم ------------------------------ */
      let drag = null;
      stage.addEventListener('pointerdown', (e) => {
        drag = { px: e.clientX, py: e.clientY, x, y };
        stage.setPointerCapture(e.pointerId);
        stage.style.cursor = 'grabbing';
      });
      stage.addEventListener('pointermove', (e) => {
        if (!drag) return;
        x = drag.x + (e.clientX - drag.px);
        y = drag.y + (e.clientY - drag.py);
        paint();
      });
      const endDrag = () => { drag = null; stage.style.cursor = 'grab'; };
      stage.addEventListener('pointerup', endDrag);
      stage.addEventListener('pointercancel', endDrag);
      stage.addEventListener('wheel', (e) => {
        e.preventDefault();
        const r = stage.getBoundingClientRect();
        setZoom(zoom * (e.deltaY < 0 ? 1.12 : 1 / 1.12), e.clientX - r.left, e.clientY - r.top);
      }, { passive: false });

      zoomEl.oninput = () => setZoom(Number(zoomEl.value) / 100);

      $('#cr-fit', m.el).onclick = () => { letterbox = false; zoom = 1; zoomEl.value = 100; center(); paint(); };
      $('#cr-all', m.el).onclick = () => { letterbox = true; zoom = 1; zoomEl.value = 100; center(); paint(); };
      $('#cr-rot', m.el).onclick = async () => {
        try { img = await rotate90(img); } catch (_) { return; }
        zoom = 1; zoomEl.value = 100; center(); paint();
      };

      $('#cr-cancel', m.el).onclick = () => finish(null);
      $('#cr-ok', m.el).onclick = () => finish(render(size, round));

      /* ------------------------------ الناتج ------------------------------ */
      function render(px, circle) {
        const k = px / VIEW;                 // نفس الحسبة بمقاس أكبر
        const out = document.createElement('canvas');
        out.width = px; out.height = px;
        const o = out.getContext('2d');
        o.imageSmoothingQuality = 'high';
        if (circle) {
          o.save();
          o.beginPath();
          o.arc(px / 2, px / 2, px / 2, 0, Math.PI * 2);
          o.clip();
        }
        o.drawImage(img, x * k, y * k, drawW() * k, drawH() * k);
        if (circle) o.restore();
        let url = out.toDataURL('image/png');
        // لو طلع كبير ننزّل المقاس بدل ما نرفض الصورة
        for (let p = px; url.length > 600000 && p > 128; p = Math.round(p * 0.75)) {
          const s = document.createElement('canvas');
          s.width = p; s.height = p;
          s.getContext('2d').drawImage(out, 0, 0, p, p);
          url = s.toDataURL('image/png');
        }
        return url;
      }

      center();
      paint();
    });
  }

  return { open };
})();

if (typeof module !== 'undefined' && module.exports) module.exports = Cropper;
