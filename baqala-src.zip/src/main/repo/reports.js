'use strict';
const db = require('../db');
const products = require('./products');
const parties = require('./parties');
const audit = require('./audit');
const { today, money, num, str } = require('../util');
/* eslint-disable no-param-reassign */

function range(filters = {}) {
  return { from: filters.from || today(), to: filters.to || today() };
}

/* --------------------------- لوحة تحكم المالك --------------------------- */
function dashboard(filters = {}) {
  const day = filters.day || today();
  const d = new Date(day);
  const monthStart = `${day.substring(0, 7)}-01`;
  const weekStart = (() => {
    const x = new Date(d); x.setDate(x.getDate() - 6); return today(x);
  })();
  const yesterday = (() => { const x = new Date(d); x.setDate(x.getDate() - 1); return today(x); })();

  const dayStats = periodStats(day, day);
  const yStats = periodStats(yesterday, yesterday);
  const monthStats = periodStats(monthStart, day);

  // مبيعات آخر 7 أيام للرسم البياني
  const daily = db.get().all(
    `SELECT day,
            COALESCE(SUM(CASE WHEN type='sale' THEN total ELSE -total END),0) total,
            COALESCE(SUM(CASE WHEN type='sale' THEN profit ELSE -profit END),0) profit,
            COUNT(CASE WHEN type='sale' THEN 1 END) invoices
     FROM sales WHERE status='completed' AND day BETWEEN ? AND ?
     GROUP BY day ORDER BY day`, [weekStart, day]);

  // ملء الأيام الفاضية
  const series = [];
  for (let i = 6; i >= 0; i--) {
    const x = new Date(d); x.setDate(x.getDate() - i);
    const key = today(x);
    const found = daily.find((r) => r.day === key);
    series.push({ day: key, total: money(found ? found.total : 0), profit: money(found ? found.profit : 0), invoices: found ? found.invoices : 0 });
  }

  // المبيعات حسب الساعة لليوم
  const hourly = db.get().all(
    `SELECT substr(created_at,12,2) h, COUNT(*) c, COALESCE(SUM(total),0) t
     FROM sales WHERE day=? AND status='completed' AND type='sale' GROUP BY h ORDER BY h`, [day]);

  const topProducts = db.get().all(
    `SELECT si.name, si.product_id, SUM(si.qty) qty, SUM(si.line_total) total,
            SUM(si.line_total - si.tax_amount - si.cost_price*si.qty) profit
     FROM sale_items si JOIN sales s ON s.id=si.sale_id
     WHERE s.day BETWEEN ? AND ? AND s.status='completed' AND s.type='sale'
     GROUP BY si.name ORDER BY total DESC LIMIT 10`, [monthStart, day]);

  const staff = audit.staffDay(day);
  const alerts = products.alerts();
  const debts = parties.debtSummary();

  const inv = db.get().get(
    `SELECT COUNT(*) items, COALESCE(SUM(stock*cost_price),0) cost_value, COALESCE(SUM(stock*sale_price),0) sale_value
     FROM products WHERE active=1 AND track_stock=1`);

  const openShifts = db.get().all(
    `SELECT s.*, u.name user_name FROM shifts s JOIN users u ON u.id=s.user_id WHERE s.status='open'`);

  return {
    day,
    today: dayStats,
    yesterday: yStats,
    month: monthStats,
    series, hourly, topProducts, staff, alerts, debts,
    inventory: { items: inv.items, costValue: money(inv.cost_value), saleValue: money(inv.sale_value) },
    openShifts,
    recentActivity: audit.recent(20),
    recentSales: db.get().all(
      `SELECT s.id,s.invoice_no,s.created_at,s.total,s.payment_method,s.status,s.type,u.name user_name
       FROM sales s LEFT JOIN users u ON u.id=s.user_id WHERE s.day=? ORDER BY s.id DESC LIMIT 12`, [day]),
  };
}

/** أرقام فترة معيّنة */
function periodStats(from, to) {
  from = str(from) || today();
  to = str(to) || today();
  const s = db.get().get(
    `SELECT COUNT(*) invoices, COALESCE(SUM(total),0) total, COALESCE(SUM(profit),0) profit,
            COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(cash_amount),0) cash,
            COALESCE(SUM(card_amount),0) card, COALESCE(SUM(credit_amount),0) credit,
            COALESCE(SUM(discount),0) discount, COALESCE(SUM(cost_total),0) cost
     FROM sales WHERE status='completed' AND type='sale' AND day BETWEEN ? AND ?`, [from, to]);
  const r = db.get().get(
    `SELECT COUNT(*) c, COALESCE(SUM(total),0) t, COALESCE(SUM(profit),0) p
     FROM sales WHERE status='completed' AND type='return' AND day BETWEEN ? AND ?`, [from, to]);
  const e = db.get().get('SELECT COALESCE(SUM(amount),0) t FROM expenses WHERE day BETWEEN ? AND ?', [from, to]);
  const items = db.get().get(
    `SELECT COALESCE(SUM(si.qty),0) q FROM sale_items si JOIN sales s ON s.id=si.sale_id
     WHERE s.status='completed' AND s.type='sale' AND s.day BETWEEN ? AND ?`, [from, to]);
  const pur = db.get().get('SELECT COALESCE(SUM(total),0) t, COUNT(*) c FROM purchases WHERE day BETWEEN ? AND ?', [from, to]);

  const gross = money(s.total - r.t);
  const netProfit = money(s.profit - r.p - e.t);
  return {
    from, to,
    invoices: s.invoices,
    total: money(s.total),
    returns: r.c, returnsTotal: money(r.t),
    netSales: gross,
    tax: money(s.tax),
    cash: money(s.cash), card: money(s.card), credit: money(s.credit),
    discount: money(s.discount),
    cost: money(s.cost),
    grossProfit: money(s.profit - r.p),
    expenses: money(e.t),
    netProfit,
    itemsSold: money(items.q, 3),
    avgInvoice: s.invoices ? money(s.total / s.invoices) : 0,
    purchases: money(pur.t), purchaseCount: pur.c,
  };
}

/* ------------------------------ تقرير المبيعات ----------------------------- */
function sales(filters = {}) {
  const { from, to } = range(filters);
  const stats = periodStats(from, to);
  const byDay = db.get().all(
    `SELECT day, COUNT(*) invoices, COALESCE(SUM(total),0) total, COALESCE(SUM(profit),0) profit,
            COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(cash_amount),0) cash, COALESCE(SUM(card_amount),0) card,
            COALESCE(SUM(credit_amount),0) credit
     FROM sales WHERE status='completed' AND type='sale' AND day BETWEEN ? AND ?
     GROUP BY day ORDER BY day DESC`, [from, to]);
  const byUser = db.get().all(
    `SELECT u.id, u.name, COUNT(*) invoices, COALESCE(SUM(s.total),0) total, COALESCE(SUM(s.profit),0) profit
     FROM sales s JOIN users u ON u.id=s.user_id
     WHERE s.status='completed' AND s.type='sale' AND s.day BETWEEN ? AND ?
     GROUP BY u.id ORDER BY total DESC`, [from, to]);
  const byMethod = db.get().all(
    `SELECT payment_method m, COUNT(*) c, COALESCE(SUM(total),0) t
     FROM sales WHERE status='completed' AND type='sale' AND day BETWEEN ? AND ?
     GROUP BY payment_method`, [from, to]);
  const byCategory = db.get().all(
    `SELECT COALESCE(c.name_ar,'بدون تصنيف') cat, SUM(si.qty) qty, SUM(si.line_total) total
     FROM sale_items si JOIN sales s ON s.id=si.sale_id
     LEFT JOIN products p ON p.id=si.product_id LEFT JOIN categories c ON c.id=p.category_id
     WHERE s.status='completed' AND s.type='sale' AND s.day BETWEEN ? AND ?
     GROUP BY cat ORDER BY total DESC`, [from, to]);
  return { stats, byDay, byUser, byMethod, byCategory };
}

/* ------------------------------ تقرير الأصناف ----------------------------- */
function productsReport(filters = {}) {
  const { from, to } = range(filters);
  const rows = db.get().all(
    `SELECT si.product_id, si.name, si.barcode,
            SUM(si.qty) qty, SUM(si.line_total) total, SUM(si.tax_amount) tax,
            SUM(si.cost_price*si.qty) cost,
            SUM(si.line_total - si.tax_amount - si.cost_price*si.qty) profit,
            COUNT(DISTINCT si.sale_id) invoices
     FROM sale_items si JOIN sales s ON s.id=si.sale_id
     WHERE s.status='completed' AND s.type='sale' AND s.day BETWEEN ? AND ?
     GROUP BY si.name ORDER BY ${filters.sort === 'qty' ? 'qty' : filters.sort === 'profit' ? 'profit' : 'total'} DESC
     LIMIT ${Math.min(num(filters.limit, 200), 2000)}`, [from, to]);
  const dead = db.get().all(
    `SELECT p.id,p.name_ar,p.barcode,p.stock,p.cost_price,p.sale_price
     FROM products p WHERE p.active=1 AND p.stock > 0 AND p.id NOT IN (
       SELECT DISTINCT si.product_id FROM sale_items si JOIN sales s ON s.id=si.sale_id
       WHERE s.day BETWEEN ? AND ? AND si.product_id IS NOT NULL)
     ORDER BY p.stock*p.cost_price DESC LIMIT 100`, [from, to]);
  return { rows, dead, from, to };
}

/* ------------------------------ تقرير المخزون ----------------------------- */
function inventory(filters = {}) {
  const rows = db.get().all(
    `SELECT p.id,p.barcode,p.name_ar,p.unit,p.stock,p.min_stock,p.cost_price,p.sale_price,p.expiry_date,
            c.name_ar cat_name, p.stock*p.cost_price cost_value, p.stock*p.sale_price sale_value
     FROM products p LEFT JOIN categories c ON c.id=p.category_id
     WHERE p.active=1 AND p.track_stock=1 ORDER BY ${filters.sort === 'value' ? 'cost_value DESC' : 'p.name_ar'}`);
  const totals = rows.reduce((a, r) => ({
    cost: money(a.cost + num(r.cost_value)),
    sale: money(a.sale + num(r.sale_value)),
    qty: money(a.qty + num(r.stock), 3),
  }), { cost: 0, sale: 0, qty: 0 });
  return { rows, totals, expectedProfit: money(totals.sale - totals.cost), alerts: products.alerts() };
}

/* ------------------------------ تقرير الضريبة ----------------------------- */
function vat(filters = {}) {
  const { from, to } = range(filters);
  const out = db.get().get(
    `SELECT COUNT(*) invoices, COALESCE(SUM(taxable_amount),0) base, COALESCE(SUM(tax_amount),0) tax,
            COALESCE(SUM(total),0) total
     FROM sales WHERE status='completed' AND type='sale' AND tax_enabled=1 AND day BETWEEN ? AND ?`, [from, to]);
  const ret = db.get().get(
    `SELECT COUNT(*) invoices, COALESCE(SUM(taxable_amount),0) base, COALESCE(SUM(tax_amount),0) tax
     FROM sales WHERE status='completed' AND type='return' AND tax_enabled=1 AND day BETWEEN ? AND ?`, [from, to]);
  const inp = db.get().get(
    `SELECT COUNT(*) invoices, COALESCE(SUM(total-tax_amount),0) base, COALESCE(SUM(tax_amount),0) tax
     FROM purchases WHERE day BETWEEN ? AND ?`, [from, to]);
  const byMonth = db.get().all(
    `SELECT substr(day,1,7) m, COALESCE(SUM(taxable_amount),0) base, COALESCE(SUM(tax_amount),0) tax
     FROM sales WHERE status='completed' AND type='sale' AND tax_enabled=1 AND day BETWEEN ? AND ?
     GROUP BY m ORDER BY m`, [from, to]);
  const outputTax = money(out.tax - ret.tax);
  return {
    from, to,
    outputTax, outputBase: money(out.base - ret.base), outputInvoices: out.invoices,
    inputTax: money(inp.tax), inputBase: money(inp.base), inputInvoices: inp.invoices,
    netDue: money(outputTax - num(inp.tax)),
    returnsTax: money(ret.tax),
    byMonth,
    rate: num(db.getSetting('tax_rate', '15'), 15),
    enabled: db.getSetting('tax_enabled', '0') === '1',
    vatNumber: db.getSetting('vat_number', ''),
  };
}

/* ------------------------------ الأرباح والخسائر ---------------------------- */
function profitLoss(filters = {}) {
  const { from, to } = range(filters);
  const s = periodStats(from, to);
  const exp = db.get().all(
    `SELECT category, SUM(amount) t FROM expenses WHERE day BETWEEN ? AND ? GROUP BY category ORDER BY t DESC`, [from, to]);
  return {
    from, to,
    revenue: s.netSales,
    tax: s.tax,
    revenueExTax: money(s.netSales - s.tax),
    cogs: s.cost,
    grossProfit: s.grossProfit,
    expenses: s.expenses,
    expenseBreakdown: exp,
    netProfit: s.netProfit,
    margin: s.netSales ? money((s.netProfit / s.netSales) * 100) : 0,
    stats: s,
  };
}

module.exports = { dashboard, periodStats, sales, productsReport, inventory, vat, profitLoss };
