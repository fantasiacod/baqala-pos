'use strict';
const crypto = require('crypto');
const db = require('../db');
const audit = require('./audit');
const { nowISO, str, num, fail } = require('../util');

const sessions = new Map(); // token -> {userId, at, device}

function publicUser(u) {
  if (!u) return null;
  let perms = [];
  try { perms = JSON.parse(u.permissions || '[]'); } catch (_) {}
  if (u.role === 'owner') perms = db.ALL_PERMISSIONS.slice();
  return {
    id: u.id, username: u.username, name: u.name, role: u.role,
    permissions: perms, active: !!u.active, color: u.color,
    phone: u.phone, created_at: u.created_at, last_login: u.last_login,
  };
}

/* --------------------------- تسجيل الدخول --------------------------- */
function login({ username, password, device }) {
  const uname = str(username).toLowerCase();
  if (!uname) fail('NO_USER', 'اكتب اسم المستخدم', 'Enter username');
  const u = db.get().get('SELECT * FROM users WHERE lower(username)=?', [uname]);
  if (!u) fail('BAD_CREDENTIALS', 'اسم المستخدم أو كلمة المرور غير صحيحة', 'Invalid username or password');
  if (!u.active) fail('DISABLED', 'هذا الحساب موقوف، راجع صاحب المحل', 'Account is disabled');
  if (!db.verifyPassword(password, u.salt, u.pass_hash))
    fail('BAD_CREDENTIALS', 'اسم المستخدم أو كلمة المرور غير صحيحة', 'Invalid username or password');

  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, { userId: u.id, at: Date.now(), device: device || 'local' });
  db.get().run('UPDATE users SET last_login=? WHERE id=?', [nowISO(), u.id]);

  const user = publicUser(u);
  audit.log({ user, device }, 'login', { entity: 'user', entityId: u.id, details: 'تسجيل دخول' });
  const openShift = db.get().get("SELECT * FROM shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", [u.id]);
  return { token, user, openShift: openShift || null };
}

function logout(ctx, token) {
  if (ctx && ctx.user) audit.log(ctx, 'logout', { entity: 'user', entityId: ctx.user.id, details: 'تسجيل خروج' });
  sessions.delete(token);
  return { ok: true };
}

function resolve(token) {
  const s = sessions.get(token);
  if (!s) return null;
  const u = db.get().get('SELECT * FROM users WHERE id=?', [s.userId]);
  if (!u || !u.active) { sessions.delete(token); return null; }
  return { user: publicUser(u), device: s.device };
}

function can(user, perm) {
  if (!user) return false;
  if (user.role === 'owner') return true;
  return (user.permissions || []).includes(perm);
}

/* --------------------------- إدارة اليوزرات --------------------------- */
function list() {
  // ملاحظة: علامات التنصيص المزدوجة في SQLite تُفهم كاسم عمود، لذلك نستخدم المفردة
  return db.get().all("SELECT * FROM users ORDER BY (role = 'owner') DESC, id").map(publicUser);
}

function create(ctx, data) {
  const username = str(data.username).toLowerCase();
  if (!/^[a-z0-9_.]{3,20}$/.test(username))
    fail('BAD_USERNAME', 'اسم المستخدم لازم يكون حروف إنجليزية أو أرقام من 3 إلى 20 خانة', 'Username must be 3-20 latin letters/numbers');
  if (str(data.password).length < 4)
    fail('BAD_PASSWORD', 'كلمة المرور لازم 4 خانات على الأقل', 'Password must be at least 4 characters');
  const exists = db.get().get('SELECT id FROM users WHERE lower(username)=?', [username]);
  if (exists) fail('DUPLICATE', 'اسم المستخدم مستخدم من قبل', 'Username already exists');

  const role = ['owner', 'manager', 'cashier'].includes(data.role) ? data.role : 'cashier';
  if (role === 'owner' && ctx.user.role !== 'owner')
    fail('FORBIDDEN', 'فقط صاحب المحل يقدر ينشئ حساب مالك', 'Only the owner can create an owner account');

  const perms = Array.isArray(data.permissions) && data.permissions.length
    ? data.permissions.filter((p) => db.ALL_PERMISSIONS.includes(p))
    : db.ROLE_PRESETS[role];

  const { hash, salt } = db.hashPassword(data.password);
  db.get().run(
    `INSERT INTO users(username,name,pass_hash,salt,role,permissions,phone,active,color,created_at,created_by)
     VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
    [username, str(data.name) || username, hash, salt, role, JSON.stringify(perms),
      str(data.phone), data.active === false ? 0 : 1, str(data.color) || '#1a73e8', nowISO(), ctx.user.id]
  );
  const id = db.get().get('SELECT last_insert_rowid() id').id;
  audit.log(ctx, 'user_create', { entity: 'user', entityId: id, details: `إنشاء موظف: ${data.name} (${username}) - صلاحية ${role}` });
  return publicUser(db.get().get('SELECT * FROM users WHERE id=?', [id]));
}

function update(ctx, data) {
  const id = num(data.id);
  const u = db.get().get('SELECT * FROM users WHERE id=?', [id]);
  if (!u) fail('NOT_FOUND', 'الموظف غير موجود', 'User not found');
  if (u.role === 'owner' && ctx.user.id !== u.id && ctx.user.role !== 'owner')
    fail('FORBIDDEN', 'ما تقدر تعدل على حساب المالك', 'Cannot edit the owner account');

  const role = ['owner', 'manager', 'cashier'].includes(data.role) ? data.role : u.role;
  const perms = Array.isArray(data.permissions)
    ? data.permissions.filter((p) => db.ALL_PERMISSIONS.includes(p))
    : JSON.parse(u.permissions || '[]');

  // لا نسمح بإيقاف آخر مالك فعّال
  const nextActive = data.active === undefined ? u.active : (data.active ? 1 : 0);
  if (u.role === 'owner' && !nextActive) {
    const owners = db.get().get("SELECT COUNT(*) c FROM users WHERE role='owner' AND active=1 AND id<>?", [id]).c;
    if (!owners) fail('LAST_OWNER', 'لازم يبقى حساب مالك واحد فعّال على الأقل', 'At least one active owner is required');
  }

  db.get().run(
    `UPDATE users SET name=?, role=?, permissions=?, phone=?, active=?, color=? WHERE id=?`,
    [str(data.name) || u.name, role, JSON.stringify(perms), str(data.phone), nextActive, str(data.color) || u.color, id]
  );

  if (data.password) {
    if (str(data.password).length < 4) fail('BAD_PASSWORD', 'كلمة المرور لازم 4 خانات على الأقل', 'Password too short');
    const { hash, salt } = db.hashPassword(data.password);
    db.get().run('UPDATE users SET pass_hash=?, salt=? WHERE id=?', [hash, salt, id]);
    // إنهاء جلسات الموظف
    for (const [t, s] of sessions) if (s.userId === id) sessions.delete(t);
  }

  audit.log(ctx, 'user_update', { entity: 'user', entityId: id, details: `تعديل بيانات الموظف: ${str(data.name) || u.name}` });
  return publicUser(db.get().get('SELECT * FROM users WHERE id=?', [id]));
}

function remove(ctx, id) {
  id = num(id);
  const u = db.get().get('SELECT * FROM users WHERE id=?', [id]);
  if (!u) fail('NOT_FOUND', 'الموظف غير موجود', 'User not found');
  if (u.role === 'owner') fail('FORBIDDEN', 'ما ينحذف حساب المالك، تقدر توقفه بس', 'Owner account cannot be deleted');
  if (u.id === ctx.user.id) fail('FORBIDDEN', 'ما تقدر تحذف حسابك', 'Cannot delete your own account');
  const salesCount = db.get().get('SELECT COUNT(*) c FROM sales WHERE user_id=?', [id]).c;
  if (salesCount) {
    db.get().run('UPDATE users SET active=0 WHERE id=?', [id]);
    audit.log(ctx, 'user_disable', { entity: 'user', entityId: id, details: `إيقاف الموظف ${u.name} (له فواتير سابقة)` });
    return { ok: true, disabled: true };
  }
  db.get().run('DELETE FROM users WHERE id=?', [id]);
  audit.log(ctx, 'user_delete', { entity: 'user', entityId: id, details: `حذف الموظف ${u.name}` });
  return { ok: true, deleted: true };
}

function changeOwnPassword(ctx, { oldPassword, newPassword }) {
  const u = db.get().get('SELECT * FROM users WHERE id=?', [ctx.user.id]);
  if (!db.verifyPassword(oldPassword, u.salt, u.pass_hash))
    fail('BAD_CREDENTIALS', 'كلمة المرور الحالية غير صحيحة', 'Current password is wrong');
  if (str(newPassword).length < 4) fail('BAD_PASSWORD', 'كلمة المرور الجديدة قصيرة', 'New password too short');
  const { hash, salt } = db.hashPassword(newPassword);
  db.get().run('UPDATE users SET pass_hash=?, salt=? WHERE id=?', [hash, salt, ctx.user.id]);
  audit.log(ctx, 'password_change', { entity: 'user', entityId: ctx.user.id, details: 'تغيير كلمة المرور' });
  return { ok: true };
}

/** للتحقق قبل عملية حساسة (إلغاء فاتورة مثلاً) */
function verifyManager({ username, password, permission }) {
  const u = db.get().get('SELECT * FROM users WHERE lower(username)=?', [str(username).toLowerCase()]);
  if (!u || !u.active || !db.verifyPassword(password, u.salt, u.pass_hash))
    fail('BAD_CREDENTIALS', 'بيانات المشرف غير صحيحة', 'Invalid supervisor credentials');
  const pu = publicUser(u);
  if (permission && !can(pu, permission))
    fail('FORBIDDEN', 'هذا المستخدم ما عنده الصلاحية المطلوبة', 'This user lacks the required permission');
  return pu;
}

module.exports = {
  login, logout, resolve, can, list, create, update, remove,
  changeOwnPassword, verifyManager, publicUser, sessions,
};
