'use strict';
const db = require('../db');
const audit = require('./audit');
const { nowISO, today, money, num, str, fail } = require('../util');

function current(userId) {
  return db.get().get("SELECT * FROM shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", [num(userId)]);
}

function open(ctx, { openingCash, note }) {
  const existing = current(ctx.user.id);
  if (existing) fail('SHIFT_OPEN', 'عندك وردية مفتوحة أصلاً', 'You already have an open shift');
  db.get().run('INSERT INTO shifts(user_id,opened_at,opening_cash,note,status) VALUES (?,?,?,?,\'open\')',
    [ctx.user.id, nowISO(), money(num(openingCash)), str(note)]);
  const id = db.get().get('SELECT last_insert_rowid() id').id;
  audit.log(ctx, 'shift_open', { entity: 'shift', entityId: id, amount: num(openingCash), details: `فتح وردية برصيد ${money(num(openingCash))}` });
  return db.get().get('SELECT * FROM shifts WHERE id=?', [id]);
}

/** ملخص الوردية: مبيعات، كاش، شبكة، آجل، مصروفات، سحب/إيداع */
function summary(shiftId) {
  const sh = db.get().get('SELECT * FROM shifts WHERE id=?', [num(shiftId)]);
  if (!sh) fail('NOT_FOUND', 'الوردية غير موجودة', 'Shift not found');
  const sales = db.get().get(
    `SELECT COUNT(*) c, COALESCE(SUM(total),0) total, COALESCE(SUM(cash_amount),0) cash,
            COALESCE(SUM(card_amount),0) card, COALESCE(SUM(credit_amount),0) credit,
            COALESCE(SUM(profit),0) profit, COALESCE(SUM(tax_amount),0) tax, COALESCE(SUM(change_due),0) change_due
     FROM sales WHERE shift_id=? AND status='completed' AND type='sale'`, [sh.id]);
  const returns = db.get().get(
    `SELECT COUNT(*) c, COALESCE(SUM(total),0) total FROM sales WHERE shift_id=? AND status='completed' AND type='return'`, [sh.id]);
  const expenses = db.get().get('SELECT COALESCE(SUM(amount),0) t, COUNT(*) c FROM expenses WHERE shift_id=?', [sh.id]);
  const cashIn = db.get().get("SELECT COALESCE(SUM(amount),0) t FROM cash_moves WHERE shift_id=? AND type='in'", [sh.id]);
  const cashOut = db.get().get("SELECT COALESCE(SUM(amount),0) t FROM cash_moves WHERE shift_id=? AND type='out'", [sh.id]);
  const collected = db.get().get(
    `SELECT COALESCE(SUM(amount),0) t FROM payments
     WHERE direction='in' AND method='cash' AND user_id=? AND created_at >= ? AND (? IS NULL OR created_at <= ?)`,
    [sh.user_id, sh.opened_at, sh.closed_at, sh.closed_at || nowISO()]);

  const expected = money(
    num(sh.opening_cash) + num(sales.cash) + num(collected.t) + num(cashIn.t)
    - num(returns.total) - num(expenses.t) - num(cashOut.t));

  return {
    shift: sh,
    sales: sales.c, salesTotal: money(sales.total), cash: money(sales.cash), card: money(sales.card),
    credit: money(sales.credit), profit: money(sales.profit), tax: money(sales.tax),
    returns: returns.c, returnsTotal: money(returns.total),
    expenses: money(expenses.t), expensesCount: expenses.c,
    collected: money(collected.t), cashIn: money(cashIn.t), cashOut: money(cashOut.t),
    expectedCash: expected,
  };
}

function close(ctx, { shiftId, closingCash, note }) {
  const sh = db.get().get('SELECT * FROM shifts WHERE id=?', [num(shiftId)]);
  if (!sh) fail('NOT_FOUND', 'الوردية غير موجودة', 'Shift not found');
  if (sh.status === 'closed') fail('CLOSED', 'الوردية مقفلة أصلاً', 'Shift already closed');
  if (sh.user_id !== ctx.user.id && ctx.user.role === 'cashier')
    fail('FORBIDDEN', 'ما تقدر تقفل وردية موظف ثاني', 'Cannot close another user shift');

  const sum = summary(sh.id);
  const closing = money(num(closingCash));
  const diff = money(closing - sum.expectedCash);
  db.get().run('UPDATE shifts SET closed_at=?, closing_cash=?, expected_cash=?, difference=?, note=?, status=\'closed\' WHERE id=?',
    [nowISO(), closing, sum.expectedCash, diff, str(note) || sh.note, sh.id]);
  audit.log(ctx, 'shift_close', {
    entity: 'shift', entityId: sh.id, amount: closing,
    details: `إقفال وردية - المتوقع ${sum.expectedCash} / المعدود ${closing} / الفرق ${diff}`,
  });
  return { ...summary(sh.id), closingCash: closing, difference: diff };
}

function cashMove(ctx, { type, amount, reason }) {
  const sh = current(ctx.user.id);
  const amt = money(num(amount));
  if (amt <= 0) fail('BAD_AMOUNT', 'المبلغ غير صحيح', 'Invalid amount');
  db.get().run('INSERT INTO cash_moves(shift_id,type,amount,reason,user_id,created_at) VALUES (?,?,?,?,?,?)',
    [sh ? sh.id : null, type === 'in' ? 'in' : 'out', amt, str(reason), ctx.user.id, nowISO()]);
  audit.log(ctx, type === 'in' ? 'cash_in' : 'cash_out', {
    entity: 'cash', amount: amt,
    details: `${type === 'in' ? 'إيداع في الدرج' : 'سحب من الدرج'} ${amt}${reason ? ' - ' + reason : ''}`,
  });
  return { ok: true };
}

function list(filters = {}) {
  const w = [];
  const p = [];
  if (filters.userId) { w.push('s.user_id=?'); p.push(num(filters.userId)); }
  if (filters.from) { w.push('substr(s.opened_at,1,10) >= ?'); p.push(filters.from); }
  if (filters.to) { w.push('substr(s.opened_at,1,10) <= ?'); p.push(filters.to); }
  if (filters.status) { w.push('s.status=?'); p.push(filters.status); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  return db.get().all(
    `SELECT s.*, u.name user_name FROM shifts s LEFT JOIN users u ON u.id=s.user_id
     ${where} ORDER BY s.id DESC LIMIT ${Math.min(num(filters.limit, 100), 1000)}`, p);
}

/* ------------------------------ المصروفات ------------------------------ */
function addExpense(ctx, { category, amount, note }) {
  const amt = money(num(amount));
  if (amt <= 0) fail('BAD_AMOUNT', 'المبلغ غير صحيح', 'Invalid amount');
  const sh = current(ctx.user.id);
  db.get().run('INSERT INTO expenses(category,amount,note,user_id,shift_id,created_at,day) VALUES (?,?,?,?,?,?,?)',
    [str(category) || 'أخرى', amt, str(note), ctx.user.id, sh ? sh.id : null, nowISO(), today()]);
  const id = db.get().get('SELECT last_insert_rowid() id').id;
  audit.log(ctx, 'expense_add', { entity: 'expense', entityId: id, amount: amt, details: `مصروف: ${category || 'أخرى'} بمبلغ ${amt}${note ? ' - ' + note : ''}` });
  return { ok: true, id };
}

function listExpenses(filters = {}) {
  const w = [];
  const p = [];
  if (filters.from) { w.push('e.day >= ?'); p.push(filters.from); }
  if (filters.to) { w.push('e.day <= ?'); p.push(filters.to); }
  if (filters.userId) { w.push('e.user_id=?'); p.push(num(filters.userId)); }
  if (filters.category) { w.push('e.category=?'); p.push(filters.category); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const rows = db.get().all(
    `SELECT e.*, u.name user_name FROM expenses e LEFT JOIN users u ON u.id=e.user_id
     ${where} ORDER BY e.id DESC LIMIT ${Math.min(num(filters.limit, 300), 3000)}`, p);
  const agg = db.get().get(`SELECT COALESCE(SUM(amount),0) t, COUNT(*) c FROM expenses e ${where}`, p);
  const byCat = db.get().all(
    `SELECT category, SUM(amount) t, COUNT(*) c FROM expenses e ${where} GROUP BY category ORDER BY t DESC`, p);
  return { rows, total: money(agg.t), count: agg.c, byCategory: byCat };
}

function deleteExpense(ctx, id) {
  const e = db.get().get('SELECT * FROM expenses WHERE id=?', [num(id)]);
  if (!e) fail('NOT_FOUND', 'المصروف غير موجود', 'Expense not found');
  db.get().run('DELETE FROM expenses WHERE id=?', [e.id]);
  audit.log(ctx, 'expense_delete', { entity: 'expense', entityId: e.id, amount: e.amount, details: `حذف مصروف ${e.category} بمبلغ ${e.amount}` });
  return { ok: true };
}

module.exports = { current, open, close, summary, cashMove, list, addExpense, listExpenses, deleteExpense };
