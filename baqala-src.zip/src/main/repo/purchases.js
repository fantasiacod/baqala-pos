'use strict';
const db = require('../db');
const audit = require('./audit');
const products = require('./products');
const { nowISO, today, money, num, str, fail } = require('../util');

/**
 * فاتورة شراء من مورد:
 *  - تزيد كميات الأصناف
 *  - تحدّث سعر التكلفة (وسعر البيع إذا أُرسل)
 *  - المتبقي من الفاتورة يصير دين على المحل للمورد
 */
function create(ctx, payload) {
  const items = Array.isArray(payload.items) ? payload.items : [];
  if (!items.length) fail('EMPTY', 'ما فيه أصناف في فاتورة الشراء', 'Purchase has no items');

  const s = db.settingsAll();
  const taxEnabled = s.tax_enabled === '1';
  const rate = num(s.tax_rate, 15);

  return db.tx(() => {
    let subtotal = 0;
    const lines = items.map((it) => {
      const qty = money(num(it.qty), 3);
      if (qty <= 0) fail('BAD_QTY', 'الكمية لازم أكبر من صفر', 'Quantity must be positive');
      const cost = money(num(it.cost_price));
      const lineTotal = money(qty * cost);
      subtotal = money(subtotal + lineTotal);
      return { ...it, qty, cost, lineTotal };
    });

    const discount = money(num(payload.discount));
    const net = money(Math.max(0, subtotal - discount));
    const taxAmount = payload.tax_amount !== undefined && payload.tax_amount !== null && payload.tax_amount !== ''
      ? money(num(payload.tax_amount))
      : (taxEnabled && payload.add_tax ? money(net * rate / 100) : 0);
    const total = money(net + taxAmount);
    const paid = money(Math.min(num(payload.paid), total));

    const seq = db.nextCounter('purchase');
    const invoiceNo = str(payload.invoice_no) || `${s.purchase_prefix || 'PUR-'}${String(seq).padStart(6, '0')}`;
    const supplierId = num(payload.supplier_id) || null;

    db.get().run(
      `INSERT INTO purchases(invoice_no,supplier_id,user_id,created_at,day,subtotal,discount,tax_amount,total,paid,due_date,status,note)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,'completed',?)`,
      [invoiceNo, supplierId, ctx.user.id, nowISO(), str(payload.day) || today(),
        subtotal, discount, taxAmount, total, paid, str(payload.due_date) || null, str(payload.note)]);
    const purchaseId = db.get().get('SELECT last_insert_rowid() id').id;

    lines.forEach((l) => {
      let productId = num(l.product_id) || null;
      // إنشاء صنف جديد مباشرة من فاتورة الشراء
      if (!productId && str(l.name)) {
        const created = products.save(ctx, {
          barcode: str(l.barcode), name_ar: str(l.name), unit: str(l.unit) || 'حبة',
          cost_price: l.cost, sale_price: num(l.sale_price) || money(l.cost * 1.15),
          category_id: num(l.category_id) || null, expiry_date: str(l.expiry_date), stock: 0,
        });
        productId = created.id;
      }
      db.get().run(
        `INSERT INTO purchase_items(purchase_id,product_id,name,qty,cost_price,sale_price,expiry_date,line_total)
         VALUES (?,?,?,?,?,?,?,?)`,
        [purchaseId, productId, str(l.name), l.qty, l.cost, num(l.sale_price) || null, str(l.expiry_date) || null, l.lineTotal]);

      if (productId) {
        products.applyStock(productId, l.qty, 'purchase', { type: 'purchase', id: purchaseId }, ctx.user.id, invoiceNo);
        const upd = [];
        const vals = [];
        if (l.cost > 0) { upd.push('cost_price=?'); vals.push(l.cost); }
        if (num(l.sale_price) > 0) { upd.push('sale_price=?'); vals.push(money(num(l.sale_price))); }
        if (str(l.expiry_date)) { upd.push('expiry_date=?'); vals.push(str(l.expiry_date)); }
        if (supplierId) { upd.push('supplier_id=?'); vals.push(supplierId); }
        if (upd.length) {
          db.get().run(`UPDATE products SET ${upd.join(',')}, updated_at=? WHERE id=?`, [...vals, nowISO(), productId]);
        }
      }
    });

    // الدين للمورد
    const remaining = money(total - paid);
    if (supplierId) {
      if (remaining > 0.009) db.get().run('UPDATE suppliers SET balance = balance - ? WHERE id=?', [remaining, supplierId]);
      if (paid > 0) {
        db.get().run(
          `INSERT INTO payments(party_type,party_id,direction,amount,method,user_id,created_at,day,ref_type,ref_id,note)
           VALUES ('supplier',?,'out',?,?,?,?,?,'purchase',?,?)`,
          [supplierId, paid, str(payload.method) || 'cash', ctx.user.id, nowISO(), today(), purchaseId, `دفعة مع فاتورة ${invoiceNo}`]);
      }
    }

    audit.log(ctx, 'purchase_create', {
      entity: 'purchase', entityId: purchaseId, amount: total,
      details: `فاتورة شراء ${invoiceNo} - ${lines.length} صنف - الإجمالي ${total} - مدفوع ${paid}${remaining > 0 ? ` - متبقي ${remaining}` : ''}`,
    });

    return byId(purchaseId);
  });
}

function byId(id) {
  const p = db.get().get(
    `SELECT pu.*, s.name supplier_name, s.phone supplier_phone, u.name user_name
     FROM purchases pu LEFT JOIN suppliers s ON s.id=pu.supplier_id LEFT JOIN users u ON u.id=pu.user_id
     WHERE pu.id=?`, [num(id)]);
  if (!p) return null;
  p.items = db.get().all('SELECT * FROM purchase_items WHERE purchase_id=? ORDER BY id', [p.id]);
  return p;
}

function list(filters = {}) {
  const w = [];
  const p = [];
  if (filters.from) { w.push('pu.day >= ?'); p.push(filters.from); }
  if (filters.to) { w.push('pu.day <= ?'); p.push(filters.to); }
  if (filters.supplierId) { w.push('pu.supplier_id = ?'); p.push(num(filters.supplierId)); }
  if (filters.unpaid) w.push('pu.total - pu.paid > 0.009');
  if (filters.q) { w.push('(pu.invoice_no LIKE ? OR s.name LIKE ?)'); p.push(`%${filters.q}%`, `%${filters.q}%`); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const rows = db.get().all(
    `SELECT pu.*, s.name supplier_name, u.name user_name FROM purchases pu
     LEFT JOIN suppliers s ON s.id=pu.supplier_id LEFT JOIN users u ON u.id=pu.user_id
     ${where} ORDER BY pu.id DESC LIMIT ${Math.min(num(filters.limit, 200), 2000)} OFFSET ${num(filters.offset, 0)}`, p);
  const agg = db.get().get(
    `SELECT COUNT(*) c, COALESCE(SUM(pu.total),0) t, COALESCE(SUM(pu.total-pu.paid),0) due
     FROM purchases pu LEFT JOIN suppliers s ON s.id=pu.supplier_id ${where}`, p);
  return { rows, total: agg.c, sum: money(agg.t), due: money(agg.due) };
}

function payInvoice(ctx, { id, amount, method, note }) {
  return db.tx(() => {
    const pu = db.get().get('SELECT * FROM purchases WHERE id=?', [num(id)]);
    if (!pu) fail('NOT_FOUND', 'فاتورة الشراء غير موجودة', 'Purchase not found');
    const remaining = money(num(pu.total) - num(pu.paid));
    const amt = money(Math.min(num(amount), remaining));
    if (amt <= 0) fail('BAD_AMOUNT', 'الفاتورة مسددة بالكامل', 'Invoice already fully paid');

    db.get().run('UPDATE purchases SET paid = paid + ? WHERE id=?', [amt, pu.id]);
    if (pu.supplier_id) {
      db.get().run('UPDATE suppliers SET balance = balance + ? WHERE id=?', [amt, pu.supplier_id]);
      db.get().run(
        `INSERT INTO payments(party_type,party_id,direction,amount,method,user_id,created_at,day,ref_type,ref_id,note)
         VALUES ('supplier',?,'out',?,?,?,?,?,'purchase',?,?)`,
        [pu.supplier_id, amt, str(method) || 'cash', ctx.user.id, nowISO(), today(), pu.id,
          str(note) || `سداد فاتورة ${pu.invoice_no}`]);
    }
    audit.log(ctx, 'purchase_pay', {
      entity: 'purchase', entityId: pu.id, amount: amt,
      details: `سداد ${amt} على فاتورة الشراء ${pu.invoice_no}`,
    });
    return { ok: true, paid: money(num(pu.paid) + amt), remaining: money(remaining - amt) };
  });
}

function remove(ctx, id) {
  return db.tx(() => {
    const pu = byId(id);
    if (!pu) fail('NOT_FOUND', 'فاتورة الشراء غير موجودة', 'Purchase not found');
    pu.items.forEach((l) => {
      if (l.product_id) {
        products.applyStock(l.product_id, -l.qty, 'adjust', { type: 'purchase_delete', id: pu.id },
          ctx.user.id, `حذف فاتورة شراء ${pu.invoice_no}`);
      }
    });
    const remaining = money(num(pu.total) - num(pu.paid));
    if (pu.supplier_id && remaining > 0.009) {
      db.get().run('UPDATE suppliers SET balance = balance + ? WHERE id=?', [remaining, pu.supplier_id]);
    }
    db.get().run('DELETE FROM purchases WHERE id=?', [pu.id]);
    audit.log(ctx, 'purchase_delete', {
      entity: 'purchase', entityId: pu.id, amount: pu.total,
      details: `حذف فاتورة شراء ${pu.invoice_no} بمبلغ ${pu.total}`,
    });
    return { ok: true };
  });
}

module.exports = { create, byId, list, payInvoice, remove };
