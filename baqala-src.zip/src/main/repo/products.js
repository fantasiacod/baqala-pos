'use strict';
const db = require('../db');
const audit = require('./audit');
const { nowISO, today, money, num, str, bool, fail } = require('../util');

/* ------------------------------- التصنيفات ------------------------------- */
function categories() {
  return db.get().all('SELECT * FROM categories ORDER BY sort, id');
}

function saveCategory(ctx, data) {
  const id = num(data.id);
  if (id) {
    db.get().run('UPDATE categories SET name_ar=?, name_en=?, color=? WHERE id=?',
      [str(data.name_ar), str(data.name_en), str(data.color) || '#9e9e9e', id]);
    audit.log(ctx, 'category_update', { entity: 'category', entityId: id, details: `تعديل تصنيف: ${data.name_ar}` });
    return { id };
  }
  const sort = db.get().get('SELECT COALESCE(MAX(sort),0)+1 s FROM categories').s;
  db.get().run('INSERT INTO categories(name_ar,name_en,color,sort) VALUES (?,?,?,?)',
    [str(data.name_ar), str(data.name_en), str(data.color) || '#9e9e9e', sort]);
  const nid = db.get().get('SELECT last_insert_rowid() id').id;
  audit.log(ctx, 'category_create', { entity: 'category', entityId: nid, details: `تصنيف جديد: ${data.name_ar}` });
  return { id: nid };
}

function deleteCategory(ctx, id) {
  id = num(id);
  const used = db.get().get('SELECT COUNT(*) c FROM products WHERE category_id=?', [id]).c;
  if (used) fail('IN_USE', `في ${used} صنف مرتبط بهذا التصنيف، انقلهم أولاً`, 'Category is in use');
  db.get().run('DELETE FROM categories WHERE id=?', [id]);
  audit.log(ctx, 'category_delete', { entity: 'category', entityId: id });
  return { ok: true };
}

/* -------------------------------- المنتجات -------------------------------- */
function list(filters = {}) {
  const w = [];
  const p = [];
  if (!filters.includeInactive) w.push('p.active = 1');
  if (filters.categoryId) { w.push('p.category_id = ?'); p.push(num(filters.categoryId)); }
  if (filters.q) {
    w.push('(p.name_ar LIKE ? OR p.name_en LIKE ? OR p.barcode LIKE ? OR p.id IN (SELECT product_id FROM product_barcodes WHERE barcode LIKE ?))');
    const q = `%${str(filters.q)}%`;
    p.push(q, q, q, q);
  }
  if (filters.lowStock) w.push('p.track_stock=1 AND p.stock <= p.min_stock');
  if (filters.outOfStock) w.push('p.track_stock=1 AND p.stock <= 0');
  if (filters.expiring) {
    const days = num(filters.expiring, 30);
    const d = new Date(); d.setDate(d.getDate() + days);
    w.push("p.expiry_date IS NOT NULL AND p.expiry_date <> '' AND p.expiry_date <= ?");
    p.push(today(d));
  }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const order = {
    name: 'p.name_ar', stock: 'p.stock', price: 'p.sale_price', recent: 'p.id DESC', expiry: 'p.expiry_date',
  }[filters.sort] || 'p.name_ar';
  const limit = Math.min(num(filters.limit, 500), 5000);
  const rows = db.get().all(
    `SELECT p.*, c.name_ar cat_name, c.color cat_color
     FROM products p LEFT JOIN categories c ON c.id = p.category_id
     ${where} ORDER BY ${order} LIMIT ${limit} OFFSET ${num(filters.offset, 0)}`, p);
  const total = db.get().get(`SELECT COUNT(*) c FROM products p ${where}`, p).c;
  return { rows, total };
}

function byId(id) {
  const p = db.get().get(
    `SELECT p.*, c.name_ar cat_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id=?`,
    [num(id)]);
  if (p) p.extraBarcodes = db.get().all('SELECT * FROM product_barcodes WHERE product_id=?', [p.id]);
  return p;
}

/** البحث بالباركود - يدعم الباركودات الإضافية وباركود الميزان */
function findByBarcode(code) {
  const c = str(code);
  if (!c) return null;
  let p = db.get().get('SELECT * FROM products WHERE barcode=? AND active=1', [c]);
  if (p) return { product: p, qty: 1, priceOverride: null };

  const extra = db.get().get(
    'SELECT pb.*, p.id pid FROM product_barcodes pb JOIN products p ON p.id=pb.product_id WHERE pb.barcode=? AND p.active=1', [c]);
  if (extra) {
    p = db.get().get('SELECT * FROM products WHERE id=?', [extra.product_id]);
    return { product: p, qty: num(extra.pack_qty, 1), priceOverride: extra.price || null };
  }

  // باركود ميزان: 2 + كود الصنف (5) + الوزن/السعر (5) + خانة تحقق
  if (/^(2|02)\d{11,12}$/.test(c) && c.length === 13) {
    const itemCode = c.substring(1, 6);
    const valuePart = num(c.substring(6, 12));
    const cand = db.get().get(
      'SELECT * FROM products WHERE active=1 AND (barcode=? OR barcode=? OR id=?)',
      [itemCode, String(num(itemCode)), num(itemCode)]);
    if (cand) {
      const scaleMode = db.getSetting('scale_mode', 'weight'); // weight | price
      if (scaleMode === 'price') {
        const price = valuePart / 100;
        const qty = cand.sale_price > 0 ? money(price / cand.sale_price, 3) : 1;
        return { product: cand, qty, priceOverride: null, scale: true };
      }
      return { product: cand, qty: money(valuePart / 1000, 3), priceOverride: null, scale: true };
    }
  }
  return null;
}

function save(ctx, data) {
  const id = num(data.id);
  const barcode = str(data.barcode) || null;
  if (!str(data.name_ar)) fail('NO_NAME', 'اكتب اسم الصنف', 'Product name is required');

  if (barcode) {
    const dup = db.get().get('SELECT id FROM products WHERE barcode=? AND id<>?', [barcode, id || 0]);
    if (dup) fail('DUP_BARCODE', 'هذا الباركود مسجل على صنف ثاني', 'Barcode already used by another product');
  }

  const fields = {
    barcode,
    name_ar: str(data.name_ar),
    name_en: str(data.name_en),
    category_id: num(data.category_id) || null,
    unit: str(data.unit) || 'حبة',
    cost_price: money(num(data.cost_price)),
    sale_price: money(num(data.sale_price)),
    wholesale_price: money(num(data.wholesale_price)),
    taxable: bool(data.taxable === undefined ? 1 : data.taxable),
    price_includes_tax: bool(data.price_includes_tax === undefined ? 1 : data.price_includes_tax),
    track_stock: bool(data.track_stock === undefined ? 1 : data.track_stock),
    min_stock: num(data.min_stock),
    expiry_date: str(data.expiry_date) || null,
    supplier_id: num(data.supplier_id) || null,
    note: str(data.note),
    active: bool(data.active === undefined ? 1 : data.active),
  };

  if (id) {
    const old = db.get().get('SELECT * FROM products WHERE id=?', [id]);
    if (!old) fail('NOT_FOUND', 'الصنف غير موجود', 'Product not found');
    const cols = Object.keys(fields).map((k) => `${k}=?`).join(',');
    db.get().run(`UPDATE products SET ${cols}, updated_at=? WHERE id=?`,
      [...Object.values(fields), nowISO(), id]);

    // تعديل الكمية يدوياً (جرد) عند إرساله صراحة
    if (data.stock !== undefined && data.stock !== null && num(data.stock) !== num(old.stock)) {
      adjustStock(ctx, { productId: id, newQty: num(data.stock), reason: 'adjust', note: 'تعديل من شاشة الصنف' });
    }
    const changes = [];
    if (old.sale_price !== fields.sale_price) changes.push(`السعر ${old.sale_price} ← ${fields.sale_price}`);
    if (old.cost_price !== fields.cost_price) changes.push(`التكلفة ${old.cost_price} ← ${fields.cost_price}`);
    if (old.name_ar !== fields.name_ar) changes.push(`الاسم ${old.name_ar} ← ${fields.name_ar}`);
    audit.log(ctx, 'product_update', {
      entity: 'product', entityId: id,
      details: `تعديل صنف: ${fields.name_ar}${changes.length ? ' | ' + changes.join(' ، ') : ''}`,
    });
    saveExtraBarcodes(id, data.extraBarcodes);
    return byId(id);
  }

  const keys = Object.keys(fields);
  db.get().run(
    `INSERT INTO products(${keys.join(',')},stock,created_at) VALUES (${keys.map(() => '?').join(',')},?,?)`,
    [...Object.values(fields), num(data.stock), nowISO()]);
  const nid = db.get().get('SELECT last_insert_rowid() id').id;
  if (num(data.stock)) {
    db.get().run(
      `INSERT INTO stock_moves(product_id,qty_change,balance_after,reason,user_id,created_at,note)
       VALUES (?,?,?,'open',?,?,?)`,
      [nid, num(data.stock), num(data.stock), ctx.user.id, nowISO(), 'رصيد افتتاحي']);
  }
  saveExtraBarcodes(nid, data.extraBarcodes);
  audit.log(ctx, 'product_create', {
    entity: 'product', entityId: nid,
    details: `صنف جديد: ${fields.name_ar} - سعر ${fields.sale_price} - كمية ${num(data.stock)}`,
  });
  return byId(nid);
}

function saveExtraBarcodes(productId, arr) {
  if (!Array.isArray(arr)) return;
  db.get().run('DELETE FROM product_barcodes WHERE product_id=?', [productId]);
  arr.forEach((b) => {
    const code = str(b.barcode);
    if (!code) return;
    try {
      db.get().run('INSERT INTO product_barcodes(product_id,barcode,pack_qty,price) VALUES (?,?,?,?)',
        [productId, code, num(b.pack_qty, 1) || 1, b.price ? money(num(b.price)) : null]);
    } catch (_) { /* باركود مكرر - نتجاهله */ }
  });
}

function remove(ctx, id) {
  id = num(id);
  const p = db.get().get('SELECT * FROM products WHERE id=?', [id]);
  if (!p) fail('NOT_FOUND', 'الصنف غير موجود', 'Product not found');
  const used = db.get().get('SELECT COUNT(*) c FROM sale_items WHERE product_id=?', [id]).c;
  if (used) {
    db.get().run('UPDATE products SET active=0 WHERE id=?', [id]);
    audit.log(ctx, 'product_disable', { entity: 'product', entityId: id, details: `إخفاء الصنف ${p.name_ar} (له مبيعات سابقة)` });
    return { ok: true, disabled: true };
  }
  db.get().run('DELETE FROM products WHERE id=?', [id]);
  audit.log(ctx, 'product_delete', { entity: 'product', entityId: id, details: `حذف صنف: ${p.name_ar}` });
  return { ok: true, deleted: true };
}

/* ------------------------------ حركة المخزون ------------------------------ */
function applyStock(productId, qtyChange, reason, ref, userId, note) {
  const p = db.get().get('SELECT id,stock,track_stock,name_ar FROM products WHERE id=?', [productId]);
  if (!p || !p.track_stock) return null;
  const after = money(num(p.stock) + num(qtyChange), 3);
  db.get().run('UPDATE products SET stock=? WHERE id=?', [after, productId]);
  db.get().run(
    `INSERT INTO stock_moves(product_id,qty_change,balance_after,reason,ref_type,ref_id,user_id,created_at,note)
     VALUES (?,?,?,?,?,?,?,?,?)`,
    [productId, money(num(qtyChange), 3), after, reason, ref && ref.type, ref && ref.id, userId, nowISO(), note || null]);
  return after;
}

function adjustStock(ctx, { productId, newQty, delta, reason, note }) {
  const p = db.get().get('SELECT * FROM products WHERE id=?', [num(productId)]);
  if (!p) fail('NOT_FOUND', 'الصنف غير موجود', 'Product not found');
  const change = delta !== undefined && delta !== null
    ? num(delta)
    : money(num(newQty) - num(p.stock), 3);
  if (!change) return { ok: true, unchanged: true };
  const after = applyStock(p.id, change, reason || 'adjust', null, ctx.user.id, note);
  audit.log(ctx, 'stock_adjust', {
    entity: 'product', entityId: p.id, amount: change,
    details: `${reason === 'damage' ? 'تالف' : 'تسوية مخزون'}: ${p.name_ar} ${num(p.stock)} ← ${after}${note ? ' | ' + note : ''}`,
  });
  return { ok: true, stock: after };
}

function moves(productId, limit = 100) {
  return db.get().all(
    `SELECT m.*, u.name user_name FROM stock_moves m LEFT JOIN users u ON u.id=m.user_id
     WHERE m.product_id=? ORDER BY m.id DESC LIMIT ?`, [num(productId), num(limit, 100)]);
}

/* -------------------------------- التنبيهات ------------------------------- */
function alerts() {
  const days = num(db.getSetting('expiry_alert_days', '30'), 30);
  const d = new Date(); d.setDate(d.getDate() + days);
  const low = db.get().all(
    `SELECT id,name_ar,barcode,stock,min_stock,unit FROM products
     WHERE active=1 AND track_stock=1 AND stock <= min_stock AND min_stock > 0
     ORDER BY (stock - min_stock) LIMIT 200`);
  const out = db.get().all(
    `SELECT id,name_ar,barcode,stock,unit FROM products
     WHERE active=1 AND track_stock=1 AND stock <= 0 ORDER BY name_ar LIMIT 200`);
  const expiring = db.get().all(
    `SELECT id,name_ar,barcode,stock,expiry_date,unit FROM products
     WHERE active=1 AND expiry_date IS NOT NULL AND expiry_date <> '' AND expiry_date <= ? AND stock > 0
     ORDER BY expiry_date LIMIT 200`, [today(d)]);
  const expired = expiring.filter((x) => x.expiry_date < today());
  return {
    low, out,
    expiring: expiring.filter((x) => x.expiry_date >= today()),
    expired,
    counts: { low: low.length, out: out.length, expiring: expiring.length - expired.length, expired: expired.length },
  };
}

/* ------------------------------ استيراد وتصدير ----------------------------- */
function importRows(ctx, rows) {
  let created = 0, updated = 0, failed = 0;
  const errors = [];
  db.tx(() => {
    rows.forEach((r, i) => {
      try {
        const barcode = str(r.barcode);
        const existing = barcode ? db.get().get('SELECT * FROM products WHERE barcode=?', [barcode]) : null;
        const payload = {
          id: existing ? existing.id : 0,
          barcode,
          name_ar: str(r.name_ar || r.name),
          name_en: str(r.name_en),
          unit: str(r.unit) || 'حبة',
          cost_price: num(r.cost_price),
          sale_price: num(r.sale_price),
          min_stock: num(r.min_stock),
          expiry_date: str(r.expiry_date),
          taxable: r.taxable === undefined ? 1 : bool(r.taxable),
          category_id: num(r.category_id) || null,
          stock: num(r.stock),
        };
        if (!payload.name_ar) throw new Error('اسم الصنف مفقود');
        save(ctx, payload);
        existing ? updated++ : created++;
      } catch (e) {
        failed++;
        if (errors.length < 30) errors.push(`سطر ${i + 2}: ${e.ar || e.message}`);
      }
    });
  });
  audit.log(ctx, 'products_import', { entity: 'product', details: `استيراد أصناف: ${created} جديد، ${updated} محدّث، ${failed} فشل` });
  return { created, updated, failed, errors };
}

function exportAll() {
  return db.get().all(
    `SELECT p.barcode, p.name_ar, p.name_en, c.name_ar category, p.unit, p.cost_price, p.sale_price,
            p.stock, p.min_stock, p.expiry_date, p.taxable
     FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.active=1 ORDER BY p.name_ar`);
}

module.exports = {
  categories, saveCategory, deleteCategory,
  list, byId, findByBarcode, save, remove,
  applyStock, adjustStock, moves, alerts,
  importRows, exportAll,
};
