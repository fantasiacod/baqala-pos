'use strict';
const fs = require('fs');
const path = require('path');
const db = require('../db');
const { nowISO, today, num, str } = require('../util');

/** تسجيل كل حركة يسويها الموظف */
function log(ctx, action, opts = {}) {
  try {
    db.get().run(
      `INSERT INTO activity_log(user_id,username,user_name,action,entity,entity_id,details,amount,created_at,day,device)
       VALUES (?,?,?,?,?,?,?,?,?,?,?)`,
      [
        ctx && ctx.user ? ctx.user.id : null,
        ctx && ctx.user ? ctx.user.username : null,
        ctx && ctx.user ? ctx.user.name : null,
        action,
        opts.entity || null,
        opts.entityId || null,
        opts.details ? (typeof opts.details === 'string' ? opts.details : JSON.stringify(opts.details)) : null,
        opts.amount === undefined ? null : num(opts.amount),
        nowISO(),
        today(),
        (ctx && ctx.device) || 'local',
      ]
    );
  } catch (e) {
    // لا نوقف العملية بسبب فشل التسجيل
    console.error('audit log failed', e.message);
  }
}

function list(filters = {}) {
  const w = [];
  const p = [];
  if (filters.userId) { w.push('user_id = ?'); p.push(filters.userId); }
  if (filters.from) { w.push('day >= ?'); p.push(filters.from); }
  if (filters.to) { w.push('day <= ?'); p.push(filters.to); }
  if (filters.action) { w.push('action = ?'); p.push(filters.action); }
  if (filters.q) { w.push('(details LIKE ? OR action LIKE ? OR user_name LIKE ?)'); p.push(`%${filters.q}%`, `%${filters.q}%`, `%${filters.q}%`); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const limit = Math.min(num(filters.limit, 300), 2000);
  const rows = db.get().all(
    `SELECT * FROM activity_log ${where} ORDER BY id DESC LIMIT ${limit} OFFSET ${num(filters.offset, 0)}`, p);
  const total = db.get().get(`SELECT COUNT(*) c FROM activity_log ${where}`, p).c;
  return { rows, total };
}

/** ملخص نشاط كل موظف في يوم محدد - "وش سوى اليوم" */
function staffDay(day) {
  const d = day || today();
  const users = db.get().all('SELECT id,name,username,role,color,active FROM users ORDER BY id');
  return users.map((u) => {
    const s = db.get().get(
      `SELECT COUNT(*) invoices, COALESCE(SUM(total),0) total, COALESCE(SUM(profit),0) profit,
              COALESCE(SUM(cash_amount),0) cash, COALESCE(SUM(card_amount),0) card,
              COALESCE(SUM(credit_amount),0) credit
       FROM sales WHERE user_id=? AND day=? AND status='completed' AND type='sale'`, [u.id, d]);
    const r = db.get().get(
      `SELECT COUNT(*) c, COALESCE(SUM(total),0) t FROM sales
       WHERE user_id=? AND day=? AND status='completed' AND type='return'`, [u.id, d]);
    const v = db.get().get(
      `SELECT COUNT(*) c FROM sales WHERE void_by=? AND substr(void_at,1,10)=?`, [u.id, d]);
    const acts = db.get().get(
      'SELECT COUNT(*) c FROM activity_log WHERE user_id=? AND day=?', [u.id, d]);
    const firstLast = db.get().get(
      'SELECT MIN(created_at) f, MAX(created_at) l FROM activity_log WHERE user_id=? AND day=?', [u.id, d]);
    const shift = db.get().get(
      'SELECT * FROM shifts WHERE user_id=? AND substr(opened_at,1,10)=? ORDER BY id DESC LIMIT 1', [u.id, d]);
    const top = db.get().all(
      `SELECT si.name, SUM(si.qty) q FROM sale_items si JOIN sales s ON s.id=si.sale_id
       WHERE s.user_id=? AND s.day=? AND s.status='completed' AND s.type='sale'
       GROUP BY si.name ORDER BY q DESC LIMIT 5`, [u.id, d]);
    return {
      user: u,
      invoices: s.invoices, total: s.total, profit: s.profit,
      cash: s.cash, card: s.card, credit: s.credit,
      returns: r.c, returnsTotal: r.t, voids: v.c,
      actions: acts.c,
      firstAction: firstLast ? firstLast.f : null,
      lastAction: firstLast ? firstLast.l : null,
      shift: shift || null,
      topItems: top,
    };
  });
}

/** آخر الحركات لعرضها في لوحة التحكم */
function recent(limit = 25) {
  return db.get().all('SELECT * FROM activity_log ORDER BY id DESC LIMIT ?', [num(limit, 25)]);
}

function purgeOlderThan(days) {
  const d = new Date();
  d.setDate(d.getDate() - num(days, 365));
  const cut = today(d);
  db.get().run('DELETE FROM activity_log WHERE day < ?', [cut]);
  return { ok: true, cut };
}

/* ------------------------------------------------------------------ */
/*  الأرشفة الأسبوعية: نحفظ السجل القديم في ملف ثم نحذفه من القاعدة     */
/*  حتى لا تكبر قاعدة البيانات ويثقل البرنامج مع الوقت.                */
/* ------------------------------------------------------------------ */
function archiveDir() {
  const dir = path.join(path.dirname(db.getPath()), 'archive-logs');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

const ACTION_AR = {
  login: 'تسجيل دخول', logout: 'تسجيل خروج', password_change: 'تغيير كلمة المرور',
  sale_create: 'فاتورة بيع', sale_return: 'إرجاع', sale_void: 'إلغاء فاتورة',
  product_create: 'إضافة صنف', product_update: 'تعديل صنف', product_delete: 'حذف صنف',
  stock_adjust: 'تعديل كمية', purchase_create: 'فاتورة شراء', purchase_pay: 'سداد مورد',
  payment_in: 'قبض', payment_out: 'صرف', expense_add: 'مصروف',
  shift_open: 'فتح وردية', shift_close: 'إقفال وردية',
  user_create: 'إضافة موظف', user_update: 'تعديل موظف',
  settings_update: 'تعديل إعدادات', backup_create: 'نسخة احتياطية',
};

function csvCell(v) {
  const s = v === null || v === undefined ? '' : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

/**
 * يؤرشف الحركات الأقدم من keepDays في ملف CSV ثم يحذفها.
 * @returns {{archived:number, file:string|null, cut:string}}
 */
function archiveAndPurge(ctx, { keepDays } = {}) {
  const keep = Math.max(1, num(keepDays, 7));
  const d = new Date();
  d.setDate(d.getDate() - keep);
  const cut = today(d);

  const rows = db.get().all(
    'SELECT * FROM activity_log WHERE day < ? ORDER BY id', [cut]);
  if (!rows.length) {
    db.setSetting('last_log_purge', today());
    return { archived: 0, file: null, cut };
  }

  const head = ['التاريخ والوقت', 'الموظف', 'اسم المستخدم', 'الحركة', 'التفاصيل', 'المبلغ', 'الجهاز'];
  const lines = [head.join(',')];
  rows.forEach((r) => {
    lines.push([
      r.created_at, r.user_name || '', r.username || '',
      ACTION_AR[r.action] || r.action, r.details || '',
      r.amount === null || r.amount === undefined ? '' : r.amount,
      r.device || '',
    ].map(csvCell).join(','));
  });

  const from = rows[0].day;
  const to = rows[rows.length - 1].day;
  const name = `سجل-النشاط_${from}_الى_${to}.csv`;
  const file = path.join(archiveDir(), name);
  fs.writeFileSync(file, '﻿' + lines.join('\n'), 'utf8');

  db.get().run('DELETE FROM activity_log WHERE day < ?', [cut]);
  try { db.get().exec('VACUUM'); } catch (_) {}
  db.setSetting('last_log_purge', today());

  log(ctx || { user: { id: 0, username: 'system', name: 'النظام' }, device: 'auto' },
    'log_archive', {
      entity: 'system', amount: rows.length,
      details: `أرشفة ${rows.length} حركة أقدم من ${keep} يوم في الملف: ${name}`,
    });

  return { archived: rows.length, file, name, cut };
}

/** قائمة ملفات الأرشيف المحفوظة */
function archives() {
  const dir = archiveDir();
  return fs.readdirSync(dir).filter((f) => f.endsWith('.csv')).map((f) => {
    const st = fs.statSync(path.join(dir, f));
    return { name: f, path: path.join(dir, f), size: st.size, at: new Date(st.mtimeMs).toISOString() };
  }).sort((a, b) => b.at.localeCompare(a.at));
}

/** تُستدعى دورياً: تؤرشف مرة كل أسبوع */
function weeklyMaintenance() {
  try {
    if (db.getSetting('log_auto_purge', '1') !== '1') return { skipped: true };
    const last = db.getSetting('last_log_purge', '');
    if (last) {
      const diff = (new Date(today()) - new Date(last)) / 86400000;
      if (diff < 7) return { skipped: true, daysSince: diff };
    }
    return archiveAndPurge(null, { keepDays: num(db.getSetting('log_keep_days', '7'), 7) });
  } catch (e) {
    console.error('log maintenance failed', e.message);
    return { error: e.message };
  }
}

/** حجم السجل الحالي - لعرضه في الإعدادات */
function stats() {
  const c = db.get().get('SELECT COUNT(*) c, MIN(day) f, MAX(day) t FROM activity_log');
  let dbSize = 0;
  try { dbSize = fs.statSync(db.getPath()).size; } catch (_) {}
  return {
    rows: c.c, from: c.f, to: c.t, dbSize,
    lastPurge: db.getSetting('last_log_purge', ''),
    keepDays: num(db.getSetting('log_keep_days', '7'), 7),
    autoPurge: db.getSetting('log_auto_purge', '1') === '1',
  };
}

module.exports = {
  log, list, staffDay, recent, purgeOlderThan,
  archiveAndPurge, archives, weeklyMaintenance, stats, archiveDir,
};
