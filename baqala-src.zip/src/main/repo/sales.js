'use strict';
const db = require('../db');
const audit = require('./audit');
const products = require('./products');
const { nowISO, today, money, num, str, fail } = require('../util');

/* ------------------------------------------------------------------ */
/*  حساب الفاتورة                                                      */
/* ------------------------------------------------------------------ */
/**
 * يحسب سطور الفاتورة والضريبة.
 * الإعدادات:
 *   tax_enabled        : تفعيل ضريبة القيمة المضافة (يتحكم فيه المالك)
 *   tax_rate           : النسبة (15 افتراضياً)
 *   prices_include_tax : هل الأسعار المعروضة شاملة الضريبة
 */
function computeInvoice(items, opts = {}) {
  const taxEnabled = opts.taxEnabled ? 1 : 0;
  const rate = num(opts.taxRate, 15);
  const inclusive = opts.pricesIncludeTax ? 1 : 0;
  const r = rate / 100;

  // 1) إجمالي السطور بسعر البيع بعد خصم السطر
  const prepared = items.map((it) => {
    const qty = money(num(it.qty), 3);
    if (qty <= 0) fail('BAD_QTY', 'الكمية لازم تكون أكبر من صفر', 'Quantity must be greater than zero');
    const price = money(num(it.price));
    const lineDiscount = money(Math.max(0, num(it.discount)));
    const gross = money(Math.max(0, price * qty - lineDiscount));
    return { ...it, qty, price, lineDiscount, gross };
  });

  const grossSum = money(prepared.reduce((s, x) => s + x.gross, 0));

  // 2) خصم على مستوى الفاتورة (مبلغ أو نسبة) موزّع بالتناسب
  let invoiceDiscount = 0;
  if (opts.discountPercent) invoiceDiscount = money(grossSum * (num(opts.discountPercent) / 100));
  else if (opts.discountAmount) invoiceDiscount = money(num(opts.discountAmount));
  if (invoiceDiscount < 0) invoiceDiscount = 0;
  if (invoiceDiscount > grossSum) invoiceDiscount = grossSum;
  const factor = grossSum > 0 ? (grossSum - invoiceDiscount) / grossSum : 1;

  // 3) توزيع الضريبة على كل سطر
  let subtotal = 0, taxAmount = 0, total = 0, costTotal = 0, taxableAmount = 0;
  const lines = prepared.map((x) => {
    const lineGross = money(x.gross * factor);
    const taxable = taxEnabled && (x.taxable === undefined ? 1 : (x.taxable ? 1 : 0));
    let net, tax, lineTotal;
    if (taxable) {
      if (inclusive) {
        net = money(lineGross / (1 + r));
        tax = money(lineGross - net);
        lineTotal = lineGross;
      } else {
        net = lineGross;
        tax = money(lineGross * r);
        lineTotal = money(net + tax);
      }
      taxableAmount = money(taxableAmount + net);
    } else {
      net = lineGross; tax = 0; lineTotal = lineGross;
    }
    subtotal = money(subtotal + net);
    taxAmount = money(taxAmount + tax);
    total = money(total + lineTotal);
    const cost = money(num(x.cost_price) * x.qty);
    costTotal = money(costTotal + cost);

    return {
      product_id: x.product_id || null,
      name: str(x.name),
      barcode: str(x.barcode),
      unit: str(x.unit),
      qty: x.qty,
      unit_price: money(x.qty ? net / x.qty : net),   // السعر الصافي للوحدة
      gross_unit_price: x.price,
      cost_price: money(num(x.cost_price)),
      discount: money(x.lineDiscount + (x.gross - lineGross)),
      tax_rate: taxable ? rate : 0,
      tax_amount: tax,
      line_total: lineTotal,
      net: net,
    };
  });

  const totalDiscount = money(prepared.reduce((s, x) => s + x.lineDiscount, 0) + invoiceDiscount);

  return {
    lines,
    subtotal: money(subtotal),
    taxableAmount: money(taxableAmount),
    taxAmount: money(taxAmount),
    total: money(total),
    discount: totalDiscount,
    costTotal: money(costTotal),
    profit: money(subtotal - costTotal),
    taxEnabled, taxRate: rate, pricesIncludeTax: inclusive,
  };
}

/** معاينة سريعة من الواجهة (بدون حفظ) */
function preview(payload) {
  const s = db.settingsAll();
  return computeInvoice(payload.items || [], {
    taxEnabled: s.tax_enabled === '1',
    taxRate: num(s.tax_rate, 15),
    pricesIncludeTax: s.prices_include_tax === '1',
    discountAmount: payload.discountAmount,
    discountPercent: payload.discountPercent,
  });
}

/* ------------------------------------------------------------------ */
/*  إنشاء فاتورة بيع                                                   */
/* ------------------------------------------------------------------ */
function create(ctx, payload) {
  const items = Array.isArray(payload.items) ? payload.items : [];
  if (!items.length) fail('EMPTY', 'الفاتورة فاضية', 'Cart is empty');

  const s = db.settingsAll();
  const allowNegative = s.negative_stock === '1';
  const isReturn = payload.type === 'return';

  return db.tx(() => {
    // تجهيز السطور من قاعدة البيانات (نعتمد على أسعار القاعدة لا على الواجهة)
    const resolved = items.map((it) => {
      let p = null;
      if (it.product_id) p = db.get().get('SELECT * FROM products WHERE id=?', [num(it.product_id)]);
      const qty = money(num(it.qty), 3);
      const price = it.price !== undefined && it.price !== null && it.price !== ''
        ? money(num(it.price))
        : (p ? p.sale_price : 0);
      if (p && p.track_stock && !isReturn && !allowNegative && num(p.stock) < qty) {
        fail('NO_STOCK', `الكمية المتوفرة من "${p.name_ar}" هي ${num(p.stock)} فقط`,
          `Only ${num(p.stock)} of "${p.name_ar}" available`);
      }
      return {
        product_id: p ? p.id : null,
        name: p ? p.name_ar : str(it.name) || 'صنف',
        barcode: p ? p.barcode : str(it.barcode),
        unit: p ? p.unit : str(it.unit),
        qty, price,
        discount: num(it.discount),
        cost_price: p ? p.cost_price : num(it.cost_price),
        taxable: p ? p.taxable : 1,
      };
    });

    const calc = computeInvoice(resolved, {
      taxEnabled: s.tax_enabled === '1',
      taxRate: num(s.tax_rate, 15),
      pricesIncludeTax: s.prices_include_tax === '1',
      discountAmount: payload.discountAmount,
      discountPercent: payload.discountPercent,
    });

    // طرق الدفع
    let cash = money(num(payload.cash));
    let card = money(num(payload.card));
    let credit = 0;
    const total = calc.total;

    if (isReturn) {
      cash = total; card = 0;
    } else {
      const paid = money(cash + card);
      if (payload.payment_method === 'credit' || num(payload.credit) > 0) {
        credit = money(Math.max(0, total - paid));
      }
      if (money(paid + credit) < total - 0.009) {
        fail('UNDERPAID', 'المبلغ المدفوع أقل من إجمالي الفاتورة', 'Paid amount is less than the invoice total');
      }
    }

    const customerId = num(payload.customer_id) || null;
    if (credit > 0) {
      if (!customerId) fail('NO_CUSTOMER', 'البيع الآجل لازم تختار عميل', 'Select a customer for a credit sale');
      const cst = db.get().get('SELECT * FROM customers WHERE id=?', [customerId]);
      if (!cst) fail('NO_CUSTOMER', 'العميل غير موجود', 'Customer not found');
      if (num(cst.credit_limit) > 0 && money(num(cst.balance) + credit) > num(cst.credit_limit)) {
        fail('CREDIT_LIMIT', `تجاوز حد الدين المسموح للعميل (${cst.credit_limit})`, 'Customer credit limit exceeded');
      }
    }

    const change = isReturn ? 0 : money(Math.max(0, money(cash + card) - money(total - credit)));
    // الباقي يُرد من النقد، فالمسجّل هو ما بقي فعلاً في الدرج
    if (change > 0) cash = money(Math.max(0, cash - change));
    const method = isReturn ? 'cash'
      : credit > 0 ? (money(cash + card) > 0 ? 'mixed' : 'credit')
        : (card > 0 && cash > 0) ? 'mixed' : (card > 0 ? 'card' : 'cash');

    const seq = db.nextCounter('sale');
    const prefix = isReturn ? (s.invoice_prefix || 'INV-') + 'R' : (s.invoice_prefix || 'INV-');
    const invoiceNo = `${prefix}${String(seq).padStart(6, '0')}`;
    const created = nowISO();
    const shift = db.get().get("SELECT id FROM shifts WHERE user_id=? AND status='open' ORDER BY id DESC LIMIT 1", [ctx.user.id]);

    db.get().run(
      `INSERT INTO sales(invoice_no,type,user_id,shift_id,customer_id,created_at,day,subtotal,discount,
         taxable_amount,tax_amount,total,cost_total,profit,paid,change_due,payment_method,
         cash_amount,card_amount,credit_amount,tax_enabled,tax_rate,status,ref_sale_id,note)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'completed',?,?)`,
      [invoiceNo, isReturn ? 'return' : 'sale', ctx.user.id, shift ? shift.id : null, customerId,
        created, today(), calc.subtotal, calc.discount, calc.taxableAmount, calc.taxAmount, calc.total,
        calc.costTotal, calc.profit, money(cash + card), change, method,
        cash, card, credit, calc.taxEnabled, calc.taxRate, num(payload.ref_sale_id) || null, str(payload.note)]);

    const saleId = db.get().get('SELECT last_insert_rowid() id').id;

    calc.lines.forEach((l) => {
      db.get().run(
        `INSERT INTO sale_items(sale_id,product_id,name,barcode,unit,qty,unit_price,cost_price,discount,tax_rate,tax_amount,line_total)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
        [saleId, l.product_id, l.name, l.barcode, l.unit, l.qty, l.unit_price, l.cost_price,
          l.discount, l.tax_rate, l.tax_amount, l.line_total]);
      if (l.product_id) {
        products.applyStock(l.product_id, isReturn ? l.qty : -l.qty,
          isReturn ? 'return' : 'sale', { type: 'sale', id: saleId }, ctx.user.id, invoiceNo);
      }
    });

    // الدين على العميل
    if (credit > 0) {
      db.get().run('UPDATE customers SET balance = balance + ? WHERE id=?', [credit, customerId]);
    }
    if (isReturn && customerId && payload.return_to_balance) {
      db.get().run('UPDATE customers SET balance = balance - ? WHERE id=?', [total, customerId]);
    }

    audit.log(ctx, isReturn ? 'sale_return' : 'sale_create', {
      entity: 'sale', entityId: saleId, amount: calc.total,
      details: `${isReturn ? 'إرجاع' : 'فاتورة بيع'} ${invoiceNo} - ${calc.lines.length} صنف - الإجمالي ${calc.total} - ${
        method === 'cash' ? 'كاش' : method === 'card' ? 'شبكة' : method === 'credit' ? 'آجل' : 'مختلط'}`,
    });

    return byId(saleId);
  });
}

/* ------------------------------------------------------------------ */
/*  إلغاء فاتورة                                                       */
/* ------------------------------------------------------------------ */
function voidSale(ctx, { id, reason }) {
  return db.tx(() => {
    const sale = db.get().get('SELECT * FROM sales WHERE id=?', [num(id)]);
    if (!sale) fail('NOT_FOUND', 'الفاتورة غير موجودة', 'Invoice not found');
    if (sale.status === 'void') fail('ALREADY_VOID', 'الفاتورة ملغية أصلاً', 'Invoice is already void');

    const items = db.get().all('SELECT * FROM sale_items WHERE sale_id=?', [sale.id]);
    items.forEach((l) => {
      if (l.product_id) {
        products.applyStock(l.product_id, sale.type === 'return' ? -l.qty : l.qty,
          'adjust', { type: 'void', id: sale.id }, ctx.user.id, `إلغاء ${sale.invoice_no}`);
      }
    });
    if (sale.credit_amount > 0 && sale.customer_id) {
      db.get().run('UPDATE customers SET balance = balance - ? WHERE id=?', [sale.credit_amount, sale.customer_id]);
    }
    db.get().run('UPDATE sales SET status=?, void_reason=?, void_by=?, void_at=? WHERE id=?',
      ['void', str(reason) || 'بدون سبب', ctx.user.id, nowISO(), sale.id]);

    audit.log(ctx, 'sale_void', {
      entity: 'sale', entityId: sale.id, amount: sale.total,
      details: `إلغاء فاتورة ${sale.invoice_no} بمبلغ ${sale.total} - السبب: ${str(reason) || 'بدون سبب'}`,
    });
    return { ok: true };
  });
}

/* ------------------------------------------------------------------ */
/*  استعلامات                                                          */
/* ------------------------------------------------------------------ */
function byId(id) {
  const sale = db.get().get(
    `SELECT s.*, u.name user_name, c.name customer_name, c.phone customer_phone, c.vat_number customer_vat
     FROM sales s LEFT JOIN users u ON u.id=s.user_id LEFT JOIN customers c ON c.id=s.customer_id
     WHERE s.id=?`, [num(id)]);
  if (!sale) return null;
  sale.items = db.get().all('SELECT * FROM sale_items WHERE sale_id=? ORDER BY id', [sale.id]);
  return sale;
}

function byInvoiceNo(no) {
  const r = db.get().get('SELECT id FROM sales WHERE invoice_no=?', [str(no)]);
  return r ? byId(r.id) : null;
}

function list(filters = {}) {
  const w = [];
  const p = [];
  if (filters.from) { w.push('s.day >= ?'); p.push(filters.from); }
  if (filters.to) { w.push('s.day <= ?'); p.push(filters.to); }
  if (filters.userId) { w.push('s.user_id = ?'); p.push(num(filters.userId)); }
  if (filters.customerId) { w.push('s.customer_id = ?'); p.push(num(filters.customerId)); }
  if (filters.type) { w.push('s.type = ?'); p.push(filters.type); }
  if (filters.status) { w.push('s.status = ?'); p.push(filters.status); }
  if (filters.method) { w.push('s.payment_method = ?'); p.push(filters.method); }
  if (filters.shiftId) { w.push('s.shift_id = ?'); p.push(num(filters.shiftId)); }
  if (filters.q) { w.push('(s.invoice_no LIKE ? OR c.name LIKE ?)'); p.push(`%${filters.q}%`, `%${filters.q}%`); }
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const limit = Math.min(num(filters.limit, 100), 2000);
  const rows = db.get().all(
    `SELECT s.*, u.name user_name, c.name customer_name FROM sales s
     LEFT JOIN users u ON u.id=s.user_id LEFT JOIN customers c ON c.id=s.customer_id
     ${where} ORDER BY s.id DESC LIMIT ${limit} OFFSET ${num(filters.offset, 0)}`, p);
  const agg = db.get().get(
    `SELECT COUNT(*) c, COALESCE(SUM(CASE WHEN s.status='completed' AND s.type='sale' THEN s.total ELSE 0 END),0) sales_total,
            COALESCE(SUM(CASE WHEN s.status='completed' AND s.type='return' THEN s.total ELSE 0 END),0) returns_total
     FROM sales s LEFT JOIN customers c ON c.id=s.customer_id ${where}`, p);
  return { rows, total: agg.c, salesTotal: agg.sales_total, returnsTotal: agg.returns_total };
}

/** آخر فاتورة للمستخدم - لإعادة الطباعة السريعة */
function lastForUser(userId) {
  const r = db.get().get("SELECT id FROM sales WHERE user_id=? AND status='completed' ORDER BY id DESC LIMIT 1", [num(userId)]);
  return r ? byId(r.id) : null;
}

module.exports = { computeInvoice, preview, create, voidSale, byId, byInvoiceNo, list, lastForUser };
