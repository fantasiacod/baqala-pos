'use strict';
const db = require('../db');
const audit = require('./audit');
const { nowISO, today, money, num, str, fail } = require('../util');

const TABLE = { customer: 'customers', supplier: 'suppliers' };

function table(type) {
  const t = TABLE[type];
  if (!t) fail('BAD_TYPE', 'نوع الحساب غير صحيح', 'Invalid party type');
  return t;
}

function list(type, filters = {}) {
  const t = table(type);
  const w = [];
  const p = [];
  if (!filters.includeInactive) w.push('active = 1');
  if (filters.q) { w.push('(name LIKE ? OR phone LIKE ?)'); p.push(`%${filters.q}%`, `%${filters.q}%`); }
  if (filters.withDebt) w.push(type === 'customer' ? 'balance > 0.009' : 'balance < -0.009 OR balance > 0.009');
  const where = w.length ? 'WHERE ' + w.join(' AND ') : '';
  const rows = db.get().all(`SELECT * FROM ${t} ${where} ORDER BY name LIMIT ${Math.min(num(filters.limit, 500), 5000)}`, p);
  const agg = db.get().get(`SELECT COUNT(*) c, COALESCE(SUM(balance),0) bal FROM ${t} ${where}`, p);
  return { rows, total: agg.c, totalBalance: money(agg.bal) };
}

function byId(type, id) {
  return db.get().get(`SELECT * FROM ${table(type)} WHERE id=?`, [num(id)]);
}

function save(ctx, type, data) {
  const t = table(type);
  const id = num(data.id);
  if (!str(data.name)) fail('NO_NAME', 'اكتب الاسم', 'Name is required');
  const isCustomer = type === 'customer';

  if (id) {
    const old = db.get().get(`SELECT * FROM ${t} WHERE id=?`, [id]);
    if (!old) fail('NOT_FOUND', 'الحساب غير موجود', 'Not found');
    const cols = isCustomer
      ? 'name=?, phone=?, vat_number=?, address=?, credit_limit=?, note=?, active=?'
      : 'name=?, phone=?, vat_number=?, address=?, note=?, active=?';
    const vals = isCustomer
      ? [str(data.name), str(data.phone), str(data.vat_number), str(data.address), num(data.credit_limit), str(data.note), data.active === false ? 0 : 1]
      : [str(data.name), str(data.phone), str(data.vat_number), str(data.address), str(data.note), data.active === false ? 0 : 1];
    db.get().run(`UPDATE ${t} SET ${cols} WHERE id=?`, [...vals, id]);
    audit.log(ctx, `${type}_update`, { entity: type, entityId: id, details: `تعديل ${isCustomer ? 'عميل' : 'مورد'}: ${data.name}` });
    return byId(type, id);
  }

  const openingBalance = money(num(data.balance));
  if (isCustomer) {
    db.get().run(
      'INSERT INTO customers(name,phone,vat_number,address,balance,credit_limit,note,active,created_at) VALUES (?,?,?,?,?,?,?,1,?)',
      [str(data.name), str(data.phone), str(data.vat_number), str(data.address), openingBalance, num(data.credit_limit), str(data.note), nowISO()]);
  } else {
    db.get().run(
      'INSERT INTO suppliers(name,phone,vat_number,address,balance,note,active,created_at) VALUES (?,?,?,?,?,?,1,?)',
      [str(data.name), str(data.phone), str(data.vat_number), str(data.address), openingBalance, str(data.note), nowISO()]);
  }
  const nid = db.get().get('SELECT last_insert_rowid() id').id;
  audit.log(ctx, `${type}_create`, {
    entity: type, entityId: nid,
    details: `${isCustomer ? 'عميل' : 'مورد'} جديد: ${data.name}${openingBalance ? ` - رصيد افتتاحي ${openingBalance}` : ''}`,
  });
  return byId(type, nid);
}

function remove(ctx, type, id) {
  const t = table(type);
  id = num(id);
  const row = db.get().get(`SELECT * FROM ${t} WHERE id=?`, [id]);
  if (!row) fail('NOT_FOUND', 'الحساب غير موجود', 'Not found');
  if (Math.abs(num(row.balance)) > 0.009)
    fail('HAS_BALANCE', 'ما ينحذف وعليه رصيد، سدّد الحساب أولاً', 'Cannot delete an account with a balance');
  const used = type === 'customer'
    ? db.get().get('SELECT COUNT(*) c FROM sales WHERE customer_id=?', [id]).c
    : db.get().get('SELECT COUNT(*) c FROM purchases WHERE supplier_id=?', [id]).c;
  if (used) {
    db.get().run(`UPDATE ${t} SET active=0 WHERE id=?`, [id]);
    audit.log(ctx, `${type}_disable`, { entity: type, entityId: id, details: `إخفاء ${row.name}` });
    return { ok: true, disabled: true };
  }
  db.get().run(`DELETE FROM ${t} WHERE id=?`, [id]);
  audit.log(ctx, `${type}_delete`, { entity: type, entityId: id, details: `حذف ${row.name}` });
  return { ok: true, deleted: true };
}

/* ------------------------------- السداد -------------------------------- */
/**
 * قبض من عميل (direction=in) أو صرف لمورد (direction=out)
 */
function pay(ctx, { partyType, partyId, amount, method, note, direction }) {
  const t = table(partyType);
  const amt = money(num(amount));
  if (amt <= 0) fail('BAD_AMOUNT', 'المبلغ لازم يكون أكبر من صفر', 'Amount must be greater than zero');
  const row = db.get().get(`SELECT * FROM ${t} WHERE id=?`, [num(partyId)]);
  if (!row) fail('NOT_FOUND', 'الحساب غير موجود', 'Not found');

  const dir = direction || (partyType === 'customer' ? 'in' : 'out');

  return db.tx(() => {
    db.get().run(
      `INSERT INTO payments(party_type,party_id,direction,amount,method,user_id,created_at,day,note)
       VALUES (?,?,?,?,?,?,?,?,?)`,
      [partyType, row.id, dir, amt, str(method) || 'cash', ctx.user.id, nowISO(), today(), str(note)]);
    const pid = db.get().get('SELECT last_insert_rowid() id').id;

    // العميل: القبض ينقص رصيده. المورد: الصرف ينقص ما علينا (رصيده سالب)
    if (partyType === 'customer') {
      db.get().run('UPDATE customers SET balance = balance - ? WHERE id=?', [dir === 'in' ? amt : -amt, row.id]);
    } else {
      db.get().run('UPDATE suppliers SET balance = balance + ? WHERE id=?', [dir === 'out' ? amt : -amt, row.id]);
    }

    audit.log(ctx, dir === 'in' ? 'payment_in' : 'payment_out', {
      entity: partyType, entityId: row.id, amount: amt,
      details: `${dir === 'in' ? 'قبض من' : 'صرف إلى'} ${row.name} مبلغ ${amt}${note ? ' - ' + note : ''}`,
    });
    const updated = db.get().get(`SELECT * FROM ${t} WHERE id=?`, [row.id]);
    return { ok: true, paymentId: pid, balance: updated.balance };
  });
}

function payments(partyType, partyId, limit = 200) {
  return db.get().all(
    `SELECT p.*, u.name user_name FROM payments p LEFT JOIN users u ON u.id=p.user_id
     WHERE p.party_type=? AND p.party_id=? ORDER BY p.id DESC LIMIT ?`,
    [partyType, num(partyId), num(limit, 200)]);
}

/** كشف حساب: الفواتير + الدفعات */
function statement(partyType, partyId, filters = {}) {
  const id = num(partyId);
  const party = byId(partyType, id);
  if (!party) fail('NOT_FOUND', 'الحساب غير موجود', 'Not found');
  const from = filters.from || '2000-01-01';
  const to = filters.to || '2999-12-31';
  const entries = [];

  if (partyType === 'customer') {
    db.get().all(
      `SELECT id,invoice_no,created_at,day,total,credit_amount,type,status FROM sales
       WHERE customer_id=? AND day BETWEEN ? AND ? AND status='completed' AND credit_amount > 0
       ORDER BY id`, [id, from, to]).forEach((s) => {
      entries.push({ kind: 'invoice', date: s.created_at, ref: s.invoice_no, debit: s.credit_amount, credit: 0, note: 'بيع آجل', id: s.id });
    });
  } else {
    db.get().all(
      `SELECT id,invoice_no,created_at,day,total,paid FROM purchases
       WHERE supplier_id=? AND day BETWEEN ? AND ? ORDER BY id`, [id, from, to]).forEach((pu) => {
      const remain = money(num(pu.total) - num(pu.paid));
      if (remain > 0.009) entries.push({ kind: 'invoice', date: pu.created_at, ref: pu.invoice_no, debit: 0, credit: remain, note: 'فاتورة شراء آجلة', id: pu.id });
    });
  }

  db.get().all(
    `SELECT * FROM payments WHERE party_type=? AND party_id=? AND day BETWEEN ? AND ? ORDER BY id`,
    [partyType, id, from, to]).forEach((p) => {
    entries.push({
      kind: 'payment', date: p.created_at, ref: '#' + p.id,
      debit: p.direction === 'out' ? p.amount : 0,
      credit: p.direction === 'in' ? p.amount : 0,
      note: (p.direction === 'in' ? 'سداد نقدي' : 'دفعة للمورد') + (p.note ? ' - ' + p.note : ''),
      id: p.id,
    });
  });

  entries.sort((a, b) => String(a.date).localeCompare(String(b.date)));
  let running = 0;
  entries.forEach((e) => { running = money(running + num(e.debit) - num(e.credit)); e.balance = running; });

  return { party, entries, balance: party.balance };
}

/** ملخص الديون للوحة التحكم */
function debtSummary() {
  const cust = db.get().get('SELECT COALESCE(SUM(balance),0) t, COUNT(*) c FROM customers WHERE balance > 0.009 AND active=1');
  const sup = db.get().get('SELECT COALESCE(SUM(-balance),0) t, COUNT(*) c FROM suppliers WHERE balance < -0.009 AND active=1');
  const topCust = db.get().all('SELECT id,name,phone,balance FROM customers WHERE balance > 0.009 ORDER BY balance DESC LIMIT 10');
  const topSup = db.get().all('SELECT id,name,phone,-balance balance FROM suppliers WHERE balance < -0.009 ORDER BY balance ASC LIMIT 10');
  return {
    customersDebt: money(cust.t), customersCount: cust.c,
    suppliersDebt: money(sup.t), suppliersCount: sup.c,
    topCustomers: topCust, topSuppliers: topSup,
  };
}

module.exports = { list, byId, save, remove, pay, payments, statement, debtSummary };
