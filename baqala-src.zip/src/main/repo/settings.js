'use strict';
const fs = require('fs');
const path = require('path');
const db = require('../db');
const audit = require('./audit');
const zatca = require('../zatca');
const { nowISO, today, num, str, fail } = require('../util');

const LABELS = {
  tax_enabled: 'ضريبة القيمة المضافة',
  tax_rate: 'نسبة الضريبة',
  vat_number: 'الرقم الضريبي',
  store_name: 'اسم المحل',
  store_name_en: 'اسم المحل بالإنجليزي',
  cr_number: 'رقم السجل التجاري',
  tax_register: 'رقم السجل الضريبي',
  branches_count: 'عدد الفروع',
  phone: 'رقم الجوال',
  accent: 'اللون الرئيسي',
  font_family: 'الخط',
  theme: 'الوضع',
  lang: 'اللغة',
  currency_ar: 'رمز العملة',
};

/* صور الوثائق تُحفظ في الإعدادات لكنها كبيرة، فلا نرسلها مع كل طلب */
const DOC_KEYS = { cr: 'cr_image', tax: 'tax_image' };
const MAX_DOC_BYTES = 1400000;    // ~1.4 ميجابايت لصورة الوثيقة

/** حد الدخل السنوي اللي يوجب إضافة السجل الضريبي */
const INCOME_THRESHOLD = 100000;

function digits(v) { return String(v === null || v === undefined ? '' : v).replace(/[^\d]/g, ''); }

/** توحيد رقم الجوال السعودي إلى 10 أرقام تبدأ بـ 05 */
function normalizePhone(v) {
  let d = digits(v);
  if (d.startsWith('00966')) d = d.slice(5);
  else if (d.startsWith('966')) d = d.slice(3);
  if (d.length === 9 && d.startsWith('5')) d = '0' + d;
  return d;
}

function validatePhone(v) {
  const d = normalizePhone(v);
  if (!d) return { valid: true, value: '' };
  if (!/^0\d{9}$/.test(d)) {
    return { valid: false, value: d,
      ar: 'رقم الجوال لازم يكون 10 أرقام ويبدأ بصفر، مثال: 0546758750',
      en: 'Mobile number must be 10 digits starting with 0' };
  }
  return { valid: true, value: d };
}

function validateCR(v) {
  const d = digits(v);
  if (!d) return { valid: true, value: '' };
  if (d.length !== 12) {
    return { valid: false, value: d,
      ar: `رقم السجل التجاري لازم يكون 12 رقم بالضبط (المُدخل ${d.length} رقم)`,
      en: 'Commercial registration number must be exactly 12 digits' };
  }
  return { valid: true, value: d };
}

function validateTaxRegister(v) {
  const d = digits(v);
  if (!d) return { valid: true, value: '' };
  if (d.length !== 20) {
    return { valid: false, value: d,
      ar: `رقم السجل الضريبي لازم يكون 20 رقم بالضبط (المُدخل ${d.length} رقم)`,
      en: 'Tax registration number must be exactly 20 digits' };
  }
  return { valid: true, value: d };
}

function all() {
  const s = db.settingsAll();
  s.tax_valid = s.vat_number ? zatca.validateVatNumber(s.vat_number).valid : false;
  // بدل الصور الكبيرة نرسل إشارة فقط، وتُجلب الصورة عند فتح صفحة النماذج
  s.cr_image_set = s.cr_image ? '1' : '0';
  s.tax_image_set = s.tax_image ? '1' : '0';
  delete s.cr_image;
  delete s.tax_image;
  // مفتاح توقيع رمز التحقق سري — لا يُرسل للواجهة أبداً
  delete s.verify_key;
  const c = compliance();
  s.tax_register_required = c.required ? '1' : '0';
  s.income_12m = String(c.income12m);
  return s;
}

/**
 * متى يُطلب السجل الضريبي؟
 * إذا تجاوز دخل آخر اثني عشر شهراً 100,000، أو كان للمحل أكثر من فرع.
 */
function compliance() {
  const to = today();
  const d = new Date(to + 'T00:00:00');
  d.setFullYear(d.getFullYear() - 1);
  const from = d.toISOString().substring(0, 10);
  let income12m = 0;
  try {
    const r = db.get().get(
      `SELECT COALESCE(SUM(total),0) t FROM sales
       WHERE status='completed' AND type='sale' AND day BETWEEN ? AND ?`, [from, to]);
    const ret = db.get().get(
      `SELECT COALESCE(SUM(total),0) t FROM sales
       WHERE status='completed' AND type='return' AND day BETWEEN ? AND ?`, [from, to]);
    income12m = Math.round((num(r.t, 0) - num(ret.t, 0)) * 100) / 100;
  } catch (_) { income12m = 0; }

  const s = db.settingsAll();
  const branches = Math.max(1, num(s.branches_count, 1));
  const byIncome = income12m > INCOME_THRESHOLD;
  const byBranches = branches > 1;
  const value = str(s.tax_register);
  return {
    from, to,
    income12m,
    threshold: INCOME_THRESHOLD,
    branches,
    byIncome,
    byBranches,
    required: byIncome || byBranches,
    has: !!value,
    valid: value ? validateTaxRegister(value).valid : false,
    missing: (byIncome || byBranches) && !value,
  };
}

/** جلب صورة وثيقة (السجل التجاري أو الضريبي) */
function getDoc(kind) {
  const key = DOC_KEYS[str(kind)];
  if (!key) fail('BAD_KIND', 'نوع الوثيقة غير معروف', 'Unknown document kind');
  return { kind, image: db.getSetting(key, '') || '' };
}

/** حفظ أو حذف صورة وثيقة */
function setDoc(ctx, { kind, image }) {
  const key = DOC_KEYS[str(kind)];
  if (!key) fail('BAD_KIND', 'نوع الوثيقة غير معروف', 'Unknown document kind');
  const val = str(image);
  if (val) {
    if (!/^data:image\/(png|jpe?g|webp);base64,/i.test(val)) {
      fail('BAD_IMAGE', 'الملف لازم يكون صورة PNG أو JPG', 'File must be a PNG or JPG image');
    }
    if (val.length > MAX_DOC_BYTES) {
      fail('BIG_IMAGE', 'الصورة كبيرة، اختر صورة أصغر أو صوّرها بجودة أقل', 'Image is too large');
    }
  }
  db.setSetting(key, val);
  const name = kind === 'tax' ? 'السجل الضريبي' : 'السجل التجاري';
  audit.log(ctx, val ? 'doc_upload' : 'doc_delete', {
    entity: 'settings',
    details: (val ? 'إضافة صورة ' : 'حذف صورة ') + name,
  });
  return { ok: true, kind, has: !!val };
}

function update(ctx, patch) {
  if (!patch || typeof patch !== 'object') return all();
  const before = db.settingsAll();
  const changed = [];

  // تفعيل الضريبة يتطلب رقم ضريبي صحيح
  if (patch.tax_enabled === '1' || patch.tax_enabled === 1 || patch.tax_enabled === true) {
    const vat = str(patch.vat_number !== undefined ? patch.vat_number : before.vat_number);
    const v = zatca.validateVatNumber(vat);
    if (!v.valid) {
      fail('BAD_VAT',
        'لتفعيل الضريبة لازم تدخل رقم ضريبي صحيح: 15 رقم يبدأ بـ 3 وينتهي بـ 3',
        'A valid 15-digit VAT number starting and ending with 3 is required');
    }
    patch.vat_number = v.value;
  }

  // صور الوثائق لها مسار خاص (settings.setDoc) ولا تُحفظ من هنا
  delete patch.cr_image;
  delete patch.tax_image;
  // مفتاح التوقيع لا يُعدَّل من الواجهة
  delete patch.verify_key;

  // السجل التجاري: 12 رقم
  if (patch.cr_number !== undefined) {
    const r = validateCR(patch.cr_number);
    if (!r.valid) fail('BAD_CR', r.ar, r.en);
    patch.cr_number = r.value;
  }

  // السجل الضريبي: 20 رقم
  if (patch.tax_register !== undefined) {
    const r = validateTaxRegister(patch.tax_register);
    if (!r.valid) fail('BAD_TAX_REG', r.ar, r.en);
    patch.tax_register = r.value;
  }

  // رقم الجوال: 10 أرقام تبدأ بصفر
  if (patch.phone !== undefined) {
    const r = validatePhone(patch.phone);
    if (!r.valid) fail('BAD_PHONE', r.ar, r.en);
    patch.phone = r.value;
  }

  // عدد الفروع: رقم صحيح من 1 فأكثر
  if (patch.branches_count !== undefined) {
    const n = Math.max(1, Math.min(999, Math.round(num(patch.branches_count, 1))));
    patch.branches_count = String(n);
  }

  Object.entries(patch).forEach(([k, v]) => {
    const val = typeof v === 'boolean' ? (v ? '1' : '0') : String(v);
    if (before[k] !== val) changed.push(`${LABELS[k] || k}: ${before[k] ?? '-'} ← ${val}`);
    db.setSetting(k, val);
  });

  if (changed.length) {
    audit.log(ctx, 'settings_update', { entity: 'settings', details: 'تعديل الإعدادات | ' + changed.join(' ، ') });
  }
  return all();
}

/** تفعيل/إيقاف الضريبة من لوحة المالك مباشرة */
function setTax(ctx, { enabled, vatNumber, rate, includeInPrice }) {
  const patch = {};
  if (vatNumber !== undefined) patch.vat_number = str(vatNumber).replace(/\s/g, '');
  if (rate !== undefined) patch.tax_rate = String(num(rate, 15));
  if (includeInPrice !== undefined) patch.prices_include_tax = includeInPrice ? '1' : '0';
  patch.tax_enabled = enabled ? '1' : '0';
  const out = update(ctx, patch);
  audit.log(ctx, enabled ? 'tax_enable' : 'tax_disable', {
    entity: 'settings',
    details: enabled
      ? `تفعيل ضريبة القيمة المضافة ${out.tax_rate}% بالرقم الضريبي ${out.vat_number}`
      : 'إيقاف ضريبة القيمة المضافة',
  });
  return out;
}

/* -------------------------- النسخ الاحتياطي -------------------------- */
function backupDir() {
  const dir = path.join(path.dirname(db.getPath()), 'backups');
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function backup(ctx, targetPath) {
  const src = db.getPath();
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').substring(0, 19);
  const dest = targetPath || path.join(backupDir(), `baqala-${stamp}.db`);
  // نضمن كتابة كل شيء على القرص قبل النسخ
  try { db.get().exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}
  fs.copyFileSync(src, dest);
  audit.log(ctx, 'backup_create', { entity: 'backup', details: `نسخة احتياطية: ${path.basename(dest)}` });
  rotate();
  return { ok: true, path: dest, size: fs.statSync(dest).size };
}

function rotate() {
  const keep = num(db.getSetting('backup_keep', '20'), 20);
  const dir = backupDir();
  const files = fs.readdirSync(dir).filter((f) => f.endsWith('.db'))
    .map((f) => ({ f, t: fs.statSync(path.join(dir, f)).mtimeMs }))
    .sort((a, b) => b.t - a.t);
  files.slice(keep).forEach((x) => { try { fs.unlinkSync(path.join(dir, x.f)); } catch (_) {} });
}

function listBackups() {
  const dir = backupDir();
  return fs.readdirSync(dir).filter((f) => f.endsWith('.db')).map((f) => {
    const st = fs.statSync(path.join(dir, f));
    return { name: f, path: path.join(dir, f), size: st.size, at: new Date(st.mtimeMs).toISOString() };
  }).sort((a, b) => b.at.localeCompare(a.at));
}

function restore(ctx, filePath) {
  if (!fs.existsSync(filePath)) fail('NOT_FOUND', 'ملف النسخة غير موجود', 'Backup file not found');
  // نسخة أمان قبل الاستعادة
  const safety = path.join(backupDir(), `before-restore-${Date.now()}.db`);
  try { db.get().exec('PRAGMA wal_checkpoint(TRUNCATE)'); } catch (_) {}
  fs.copyFileSync(db.getPath(), safety);
  const target = db.getPath();
  db.close();
  fs.copyFileSync(filePath, target);
  ['-wal', '-shm'].forEach((ext) => { try { fs.unlinkSync(target + ext); } catch (_) {} });
  db.open(target);
  audit.log(ctx, 'backup_restore', { entity: 'backup', details: `استعادة نسخة: ${path.basename(filePath)}` });
  return { ok: true, safetyCopy: safety };
}

/** حذف بيانات الحركات مع الاحتفاظ بالأصناف والمستخدمين */
function resetTransactions(ctx, { confirmText }) {
  if (str(confirmText) !== 'حذف البيانات')
    fail('CONFIRM', 'اكتب "حذف البيانات" للتأكيد', 'Type the confirmation phrase');
  backup(ctx);
  db.tx(() => {
    ['sale_items', 'sales', 'purchase_items', 'purchases', 'payments', 'stock_moves',
      'expenses', 'cash_moves', 'shifts', 'activity_log'].forEach((t) => db.get().run(`DELETE FROM ${t}`));
    db.get().run('UPDATE products SET stock=0');
    db.get().run('UPDATE customers SET balance=0');
    db.get().run('UPDATE suppliers SET balance=0');
    db.get().run("UPDATE counters SET value=0");
  });
  audit.log(ctx, 'data_reset', { entity: 'system', details: 'تصفير بيانات الحركات (مع الاحتفاظ بالأصناف والموظفين)' });
  return { ok: true };
}

module.exports = {
  all, update, setTax, backup, listBackups, restore, backupDir, resetTransactions,
  compliance, getDoc, setDoc,
  validateCR, validateTaxRegister, validatePhone, normalizePhone,
};
