'use strict';
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, powerSaveBlocker } = require('electron');
const path = require('path');
const fs = require('fs');
const os = require('os');

const db = require('./db');
const api = require('./api');
const users = require('./repo/users');
const settingsRepo = require('./repo/settings');
const audit = require('./repo/audit');
const server = require('./server');
const updater = require('./updater');
const { AppError } = require('./util');

const isDev = process.argv.includes('--dev');
let mainWindow = null;
let printWindow = null;
let psBlocker = null;

/* ------------------------------------------------------------------ */
/*  إعدادات التشغيل (وضع الجهاز)                                       */
/* ------------------------------------------------------------------ */
function configPath() { return path.join(app.getPath('userData'), 'config.json'); }

/**
 * عنوان التحديثات الافتراضي — مضبوط مسبقاً داخل البرنامج
 * حتى يوصل التحديث للمستخدم تلقائياً بدون ما يضبط أي شيء.
 * يقدر يغيّره من: الإعدادات ← التحديثات إذا كان عنده سيرفر خاص.
 */
const DEFAULT_UPDATE_URL = 'https://github.com/fantasiacod/baqala-pos/releases/latest/download/';

function defaultConfig() {
  return {
    mode: 'local',            // local | host | client
    serverPort: 7711,
    serverUrl: '',
    dbPath: '',
    deviceName: os.hostname(),
    updateUrl: DEFAULT_UPDATE_URL,
    autoUpdate: true,         // الفحص التلقائي عن تحديث
    updateUrlSetByUser: false,
  };
}

function readConfig() {
  let c;
  try { c = JSON.parse(fs.readFileSync(configPath(), 'utf8')); } catch (_) { return defaultConfig(); }
  // نسخ قديمة كان العنوان فيها فاضي — نضبطه على الافتراضي مرة واحدة
  if (!c.updateUrlSetByUser && !String(c.updateUrl || '').trim()) {
    c.updateUrl = DEFAULT_UPDATE_URL;
    try { writeConfig(c); } catch (_) {}
  }
  return c;
}

function writeConfig(cfg) {
  fs.mkdirSync(path.dirname(configPath()), { recursive: true });
  fs.writeFileSync(configPath(), JSON.stringify(cfg, null, 2), 'utf8');
  return cfg;
}

let config = null;

function dataDir() {
  return config.dbPath ? path.dirname(config.dbPath) : path.join(app.getPath('userData'), 'data');
}

function dbFile() {
  return config.dbPath || path.join(dataDir(), 'baqala.db');
}

/* ------------------------------------------------------------------ */
/*  النافذة                                                            */
/* ------------------------------------------------------------------ */
function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1380,
    height: 880,
    minWidth: 1024,
    minHeight: 650,
    show: false,
    backgroundColor: '#f6f7f9',
    title: 'بقالتي - نظام المحاسبة والمخزون',
    icon: path.join(__dirname, '../../build/icon.ico'),
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });

  Menu.setApplicationMenu(null);
  mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));
  mainWindow.once('ready-to-show', () => {
    mainWindow.maximize();
    mainWindow.show();
    if (isDev) mainWindow.webContents.openDevTools({ mode: 'detach' });
  });
  mainWindow.on('closed', () => { mainWindow = null; });
  // كل ما رجع المستخدم للبرنامج نتحقق من وجود تحديث (بهدوء، مرة كل ساعتين كحد أقصى)
  mainWindow.on('focus', () => { try { updater.checkOnFocus(); } catch (_) {} });

  // فتح الروابط الخارجية في المتصفح
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });
}

/* ------------------------------------------------------------------ */
/*  الطباعة                                                            */
/* ------------------------------------------------------------------ */
async function printHTML(html, { silent = true, width = 80 } = {}) {
  return new Promise((resolve, reject) => {
    const win = new BrowserWindow({
      show: false,
      width: width === 58 ? 240 : 320,
      height: 900,
      webPreferences: { contextIsolation: true, nodeIntegration: false, javascript: true },
    });
    const done = (err, ok) => {
      try { win.destroy(); } catch (_) {}
      err ? reject(err) : resolve(ok);
    };
    win.webContents.on('did-finish-load', () => {
      setTimeout(() => {
        win.webContents.print({
          silent,
          printBackground: true,
          margins: { marginType: 'none' },
          pageSize: { width: (width === 58 ? 58000 : 80000), height: 297000 },
        }, (success, reason) => {
          if (!success && reason && reason !== 'cancelled') return done(new Error(reason));
          done(null, { ok: success, reason });
        });
      }, 350);
    });
    win.webContents.on('did-fail-load', (_e, code, desc) => done(new Error(desc || 'load failed')));
    win.loadURL('data:text/html;charset=utf-8,' + encodeURIComponent(html));
  });
}

/* ------------------------------------------------------------------ */
/*  IPC                                                                */
/* ------------------------------------------------------------------ */
function wrapResult(fn) {
  return async (event, ...args) => {
    try {
      const data = await fn(...args);
      return { ok: true, data };
    } catch (e) {
      if (e instanceof AppError || e.code) {
        return { ok: false, error: { code: e.code || 'ERROR', ar: e.ar || e.message, en: e.en || e.message } };
      }
      console.error('[api error]', e);
      return { ok: false, error: { code: 'ERROR', ar: e.message || 'صار خطأ غير متوقع', en: e.message || 'Unexpected error' } };
    }
  };
}

function registerIpc() {
  ipcMain.handle('auth.login', wrapResult(async (payload) => {
    if (config.mode === 'client') return server.remoteLogin(config.serverUrl, payload);
    return users.login({ ...payload, device: config.deviceName });
  }));

  ipcMain.handle('auth.logout', wrapResult(async ({ token }) => {
    if (config.mode === 'client') return server.remoteCall(config.serverUrl, token, 'auth.logout', {});
    const ctx = users.resolve(token);
    return users.logout(ctx, token);
  }));

  ipcMain.handle('api', wrapResult(async ({ token, action, payload }) => {
    if (config.mode === 'client') return server.remoteCall(config.serverUrl, token, action, payload);
    const ctx = users.resolve(token);
    if (!ctx) throw new AppError('UNAUTHENTICATED', 'انتهت الجلسة، سجّل دخول مرة ثانية', 'Session expired, please sign in again');
    return api.handle(action, payload, { ...ctx, device: config.deviceName });
  }));

  ipcMain.handle('app.info', wrapResult(async () => ({
    version: app.getVersion(),
    platform: process.platform,
    dbPath: config.mode === 'client' ? null : db.getPath(),
    dataDir: dataDir(),
    config,
    serverStatus: server.status(),
    localIPs: server.localIPs(),
  })));

  ipcMain.handle('app.setMode', wrapResult(async (patch) => {
    config = writeConfig({ ...config, ...patch });
    if (config.mode === 'host') {
      await server.start(config.serverPort, { api, users, deviceName: config.deviceName });
    } else {
      await server.stop();
    }
    return { config, serverStatus: server.status() };
  }));

  ipcMain.handle('print.html', wrapResult(async ({ html, silent, width }) => printHTML(html, { silent, width })));

  ipcMain.handle('dialog.save', wrapResult(async ({ defaultName, filters, content, encoding }) => {
    const r = await dialog.showSaveDialog(mainWindow, {
      defaultPath: path.join(app.getPath('documents'), defaultName || 'file.txt'),
      filters: filters || [{ name: 'All', extensions: ['*'] }],
    });
    if (r.canceled || !r.filePath) return { canceled: true };
    if (encoding === 'base64') fs.writeFileSync(r.filePath, Buffer.from(content, 'base64'));
    else fs.writeFileSync(r.filePath, content, 'utf8');
    return { canceled: false, path: r.filePath };
  }));

  ipcMain.handle('dialog.open', wrapResult(async ({ filters, encoding }) => {
    const r = await dialog.showOpenDialog(mainWindow, {
      properties: ['openFile'],
      filters: filters || [{ name: 'All', extensions: ['*'] }],
    });
    if (r.canceled || !r.filePaths.length) return { canceled: true };
    const p = r.filePaths[0];
    const content = encoding === 'base64'
      ? fs.readFileSync(p).toString('base64')
      : fs.readFileSync(p, 'utf8');
    return { canceled: false, path: p, name: path.basename(p), content };
  }));

  ipcMain.handle('shell.openPath', wrapResult(async ({ target }) => {
    await shell.openPath(target);
    return { ok: true };
  }));

  ipcMain.handle('app.relaunch', wrapResult(async () => {
    app.relaunch();
    app.exit(0);
  }));

  /* ----------------------------- التحديثات ----------------------------- */
  ipcMain.handle('update.check', wrapResult(async (opts) => updater.check(opts || {})));
  ipcMain.handle('update.download', wrapResult(async () => updater.download()));
  ipcMain.handle('update.install', wrapResult(async () => updater.install()));
  ipcMain.handle('update.state', wrapResult(async () => ({
    ...updater.current(),
    version: app.getVersion(),
    url: config.updateUrl || '',
    defaultUrl: DEFAULT_UPDATE_URL,
    isDefaultUrl: String(config.updateUrl || '').trim() === DEFAULT_UPDATE_URL,
    autoUpdate: config.autoUpdate !== false,
    packaged: app.isPackaged,
  })));
  ipcMain.handle('update.config', wrapResult(async (patch) => {
    const p = { ...patch };
    if (p.url !== undefined) { p.updateUrl = p.url; delete p.url; }
    // خانة فاضية = ارجع للعنوان الافتراضي بدل ما يتعطّل التحديث
    if (p.updateUrl !== undefined) {
      const v = String(p.updateUrl || '').trim();
      p.updateUrl = v || DEFAULT_UPDATE_URL;
      p.updateUrlSetByUser = !!v && v !== DEFAULT_UPDATE_URL;
    }
    config = writeConfig({ ...config, ...p });
    updater.init(mainWindow, config, { isPackaged: app.isPackaged });
    updater.startAutoCheck();
    return {
      url: config.updateUrl || '',
      isDefaultUrl: String(config.updateUrl || '').trim() === DEFAULT_UPDATE_URL,
      autoUpdate: config.autoUpdate !== false,
    };
  }));
}

/* ------------------------------------------------------------------ */
/*  النسخ الاحتياطي التلقائي                                           */
/* ------------------------------------------------------------------ */
function autoBackup() {
  try {
    if (config.mode === 'client') return;
    if (db.getSetting('backup_auto', '1') !== '1') return;
    const ctx = { user: { id: 0, username: 'system', name: 'النظام' }, device: 'auto' };
    settingsRepo.backup(ctx);
  } catch (e) { console.error('auto backup failed', e.message); }
}

/* ------------------------------------------------------------------ */
/*  الإقلاع                                                            */
/* ------------------------------------------------------------------ */
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
  });

  app.whenReady().then(async () => {
    config = readConfig();
    if (config.mode !== 'client') {
      fs.mkdirSync(dataDir(), { recursive: true });
      db.open(dbFile());
      if (config.mode === 'host') {
        try { await server.start(config.serverPort, { api, users, deviceName: config.deviceName }); }
        catch (e) { console.error('server start failed', e.message); }
      }
    }
    registerIpc();
    createWindow();

    // منع الجهاز من النوم أثناء التشغيل (مهم لجهاز الكاشير)
    try { psBlocker = powerSaveBlocker.start('prevent-app-suspension'); } catch (_) {}

    // نسخة احتياطية كل 6 ساعات
    setInterval(autoBackup, 6 * 60 * 60 * 1000);

    // صيانة السجل: أرشفة أسبوعية تلقائية حتى لا تثقل قاعدة البيانات
    if (config.mode !== 'client') {
      setTimeout(() => { try { audit.weeklyMaintenance(); } catch (_) {} }, 25 * 1000);
      setInterval(() => { try { audit.weeklyMaintenance(); } catch (_) {} }, 12 * 60 * 60 * 1000);
    }

    // التحديث التلقائي
    try {
      updater.init(mainWindow, config, { isPackaged: app.isPackaged });
      updater.startAutoCheck();
    } catch (e) { console.error('updater init failed', e.message); }
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });

  app.on('before-quit', () => {
    autoBackup();
    try { server.stop(); } catch (_) {}
    try { if (psBlocker !== null) powerSaveBlocker.stop(psBlocker); } catch (_) {}
    try { db.close(); } catch (_) {}
  });
}
