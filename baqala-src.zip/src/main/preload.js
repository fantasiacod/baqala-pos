'use strict';
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('baqala', {
  login: (payload) => ipcRenderer.invoke('auth.login', payload),
  logout: (payload) => ipcRenderer.invoke('auth.logout', payload),
  call: (token, action, payload) => ipcRenderer.invoke('api', { token, action, payload }),
  info: () => ipcRenderer.invoke('app.info'),
  setMode: (patch) => ipcRenderer.invoke('app.setMode', patch),
  print: (html, opts = {}) => ipcRenderer.invoke('print.html', { html, silent: opts.silent !== false, width: opts.width || 80 }),
  saveFile: (opts) => ipcRenderer.invoke('dialog.save', opts),
  openFile: (opts) => ipcRenderer.invoke('dialog.open', opts),
  openPath: (target) => ipcRenderer.invoke('shell.openPath', { target }),
  relaunch: () => ipcRenderer.invoke('app.relaunch'),

  /* التحديثات */
  update: {
    check: (opts) => ipcRenderer.invoke('update.check', opts || {}),
    download: () => ipcRenderer.invoke('update.download'),
    install: () => ipcRenderer.invoke('update.install'),
    state: () => ipcRenderer.invoke('update.state'),
    config: (patch) => ipcRenderer.invoke('update.config', patch),
    onEvent: (cb) => {
      const h = (_e, payload) => { try { cb(payload); } catch (_) {} };
      ipcRenderer.on('update:event', h);
      return () => ipcRenderer.removeListener('update:event', h);
    },
  },
});
