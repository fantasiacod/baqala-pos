'use strict';
/**
 * رمز التحقق من صحة الفاتورة.
 *
 * يُطبع على كل فاتورة رمز QR يحتوي بيانات المحل الرسمية (الاسم والسجل التجاري
 * والسجل الضريبي والرقم الضريبي) مع بيانات الفاتورة، وفي آخره «رمز تحقق»
 * وهو توقيع مختصر يُحسب بمفتاح سري خاص بالمحل لا يخرج من الجهاز.
 *
 * الزبون أو المفتّش يمسح الرمز بأي كاميرا فيقرأ البيانات مكتوبة بوضوح،
 * وصاحب المحل يقدر يتأكد من التوقيع من داخل البرنامج (الفواتير ← تحقق من فاتورة)
 * فلو عُدّل أي رقم في النص ما يطابق التوقيع.
 *
 * ملاحظة: هذا رمز خاص بالمحل وليس بديلاً عن رمز هيئة الزكاة والضريبة،
 * فذاك يُطبع مستقلاً عند تفعيل الضريبة.
 */
const crypto = require('crypto');
const { money, str } = require('./util');

/** تسميات الأسطر — ثابتة لأننا نكتب النص ونقرأه بنفس الأسماء */
const L = {
  cr: 'س.ت',
  taxReg: 'س.ض',
  vat: 'الرقم الضريبي',
  invoice: 'فاتورة',
  date: 'التاريخ',
  total: 'الإجمالي',
  code: 'تحقق',
};

/** مفتاح سري عشوائي للمحل، يُولَّد مرة واحدة عند أول تشغيل */
function newKey() {
  return crypto.randomBytes(32).toString('hex');
}

/** تاريخ محلي مختصر: 2026-09-22 19:06 */
function stamp(iso) {
  const d = iso ? new Date(iso) : new Date();
  const x = isNaN(d.getTime()) ? new Date() : d;
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())} ${p(x.getHours())}:${p(x.getMinutes())}`;
}

/** الحقول التي يُحسب عليها التوقيع — بترتيب ثابت */
function fieldsOf(s, sale) {
  return {
    store: str(s.store_name),
    cr: str(s.cr_number),
    taxReg: str(s.tax_register),
    vat: str(s.vat_number),
    invoice: str(sale.invoice_no),
    date: stamp(sale.created_at),
    total: money(sale.total).toFixed(2),
  };
}

/** نص التوقيع القانوني (canonical) — أي تغيير في أي حقل يغيّر الرمز */
function canonical(f) {
  return [f.store, f.cr, f.taxReg, f.vat, f.invoice, f.date, f.total].join('|');
}

/** حروف واضحة بدون التباس (بدون I وO و0 و1) */
const ALPHABET = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';

function sign(canonicalText, key) {
  const mac = crypto.createHmac('sha256', String(key || '')).update(canonicalText, 'utf8').digest();
  let out = '';
  for (let i = 0; i < 10; i++) out += ALPHABET[mac[i] % ALPHABET.length];
  return out.slice(0, 5) + '-' + out.slice(5);
}

/** بناء نص رمز التحقق الذي يُرمَّز داخل الـ QR */
function buildText(s, sale, key) {
  const f = fieldsOf(s, sale);
  const code = sign(canonical(f), key);
  const lines = [];
  lines.push(f.store || 'فاتورة');
  if (str(s.store_name_en)) lines.push(str(s.store_name_en));
  if (f.cr) lines.push(`${L.cr}: ${f.cr}`);
  if (f.taxReg) lines.push(`${L.taxReg}: ${f.taxReg}`);
  if (f.vat) lines.push(`${L.vat}: ${f.vat}`);
  lines.push(`${L.invoice}: ${f.invoice}`);
  lines.push(`${L.date}: ${f.date}`);
  // نستعمل رمز عملة لاتيني داخل الـ QR حتى يظهر صح في أي قارئ
  const cur = /^[A-Za-z.]{1,6}$/.test(str(s.currency_en)) ? str(s.currency_en) : 'SAR';
  lines.push(`${L.total}: ${f.total} ${cur}`);
  lines.push(`${L.code}: ${code}`);
  return { text: lines.join('\n'), code, fields: f };
}

/** قراءة نص ممسوح وإرجاع حقوله */
function parseText(text) {
  const raw = String(text || '').replace(/\r/g, '').trim();
  if (!raw) return null;
  const lines = raw.split('\n').map((x) => x.trim()).filter(Boolean);
  if (!lines.length) return null;

  const out = { store: lines[0], cr: '', taxReg: '', vat: '', invoice: '', date: '', total: '', code: '' };
  const grab = (line) => {
    const i = line.indexOf(':');
    if (i < 0) return null;
    return { label: line.slice(0, i).trim(), value: line.slice(i + 1).trim() };
  };
  lines.slice(1).forEach((line) => {
    const g = grab(line);
    if (!g) return;
    if (g.label === L.cr) out.cr = g.value;
    else if (g.label === L.taxReg) out.taxReg = g.value;
    else if (g.label === L.vat) out.vat = g.value;
    else if (g.label === L.invoice) out.invoice = g.value;
    else if (g.label === L.date) out.date = g.value;
    else if (g.label === L.total) out.total = g.value.replace(/[^\d.]/g, '');
    else if (g.label === L.code) out.code = g.value.toUpperCase();
  });
  return out;
}

/**
 * التحقق من نص ممسوح مقابل مفتاح المحل.
 * @returns {{ok:boolean, reason:string, parsed:object|null, expected:string}}
 */
function check(text, key) {
  const p = parseText(text);
  if (!p) return { ok: false, reason: 'EMPTY', parsed: null, expected: '' };
  if (!p.code) return { ok: false, reason: 'NO_CODE', parsed: p, expected: '' };
  if (!p.invoice) return { ok: false, reason: 'NO_INVOICE', parsed: p, expected: '' };

  const expected = sign(canonical({
    store: p.store, cr: p.cr, taxReg: p.taxReg, vat: p.vat,
    invoice: p.invoice, date: p.date, total: p.total,
  }), key);

  return { ok: expected === p.code, reason: expected === p.code ? 'OK' : 'BAD_CODE', parsed: p, expected };
}

module.exports = { newKey, buildText, parseText, check, sign, canonical, fieldsOf, stamp, LABELS: L };
