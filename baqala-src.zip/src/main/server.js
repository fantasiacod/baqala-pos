'use strict';
/**
 * سيرفر مدمج - يسمح بربط أكثر من جهاز كاشير على نفس قاعدة البيانات.
 *
 *  local  : جهاز واحد، قاعدة البيانات داخل الجهاز (الوضع الافتراضي).
 *  host   : هذا الجهاز هو الرئيسي، يفتح منفذ ويستقبل بقية الكاشيرات على الشبكة.
 *  client : هذا الجهاز كاشير فرعي، يتصل بالجهاز الرئيسي أو بسيرفر على الإنترنت.
 *
 * كل الطلبات تمر على نفس موجّه api.handle فتبقى الصلاحيات والتحقق موحّدة.
 */
const http = require('http');
const os = require('os');
const { AppError } = require('./util');

let srv = null;
let port = 0;
let startedAt = null;
const clients = new Map(); // token -> {user, ip, at}

function localIPs() {
  const out = [];
  const nets = os.networkInterfaces();
  Object.keys(nets).forEach((name) => {
    (nets[name] || []).forEach((n) => {
      if (n.family === 'IPv4' && !n.internal) out.push({ name, address: n.address });
    });
  });
  return out;
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let data = '';
    let size = 0;
    req.on('data', (c) => {
      size += c.length;
      if (size > 8 * 1024 * 1024) { reject(new Error('PAYLOAD_TOO_LARGE')); req.destroy(); return; }
      data += c;
    });
    req.on('end', () => {
      try { resolve(data ? JSON.parse(data) : {}); } catch (e) { reject(new Error('BAD_JSON')); }
    });
    req.on('error', reject);
  });
}

function send(res, status, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, GET, OPTIONS',
  });
  res.end(body);
}

function start(portNumber, deps) {
  return new Promise((resolve, reject) => {
    if (srv) return resolve({ ok: true, port });
    const { api, users, deviceName } = deps;
    port = Number(portNumber) || 7711;

    srv = http.createServer(async (req, res) => {
      if (req.method === 'OPTIONS') return send(res, 204, {});
      const ip = (req.socket.remoteAddress || '').replace('::ffff:', '');

      try {
        if (req.url === '/ping') {
          return send(res, 200, { ok: true, server: deviceName, at: startedAt, clients: clients.size });
        }

        if (req.url === '/login' && req.method === 'POST') {
          const body = await readBody(req);
          const out = users.login({ ...body, device: `${body.device || 'كاشير'} (${ip})` });
          clients.set(out.token, { user: out.user, ip, at: Date.now() });
          return send(res, 200, { ok: true, data: out });
        }

        if (req.url === '/api' && req.method === 'POST') {
          const auth = req.headers.authorization || '';
          const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
          const ctx = users.resolve(token);
          if (!ctx) return send(res, 401, { ok: false, error: { code: 'UNAUTHENTICATED', ar: 'انتهت الجلسة', en: 'Session expired' } });
          const body = await readBody(req);
          if (body.action === 'auth.logout') {
            clients.delete(token);
            return send(res, 200, { ok: true, data: users.logout(ctx, token) });
          }
          const data = api.handle(body.action, body.payload, { ...ctx, device: ctx.device || `كاشير (${ip})` });
          return send(res, 200, { ok: true, data });
        }

        return send(res, 404, { ok: false, error: { code: 'NOT_FOUND', ar: 'المسار غير موجود', en: 'Not found' } });
      } catch (e) {
        const err = (e instanceof AppError || e.code)
          ? { code: e.code || 'ERROR', ar: e.ar || e.message, en: e.en || e.message }
          : { code: 'ERROR', ar: e.message || 'خطأ في السيرفر', en: e.message || 'Server error' };
        return send(res, e.code === 'FORBIDDEN' ? 403 : 400, { ok: false, error: err });
      }
    });

    srv.on('error', (e) => {
      srv = null;
      reject(new Error(e.code === 'EADDRINUSE'
        ? `المنفذ ${port} مستخدم من برنامج ثاني، غيّره من الإعدادات`
        : e.message));
    });

    srv.listen(port, '0.0.0.0', () => {
      startedAt = new Date().toISOString();
      resolve({ ok: true, port });
    });
  });
}

function stop() {
  return new Promise((resolve) => {
    if (!srv) return resolve({ ok: true });
    srv.close(() => { srv = null; startedAt = null; clients.clear(); resolve({ ok: true }); });
    setTimeout(() => { srv = null; resolve({ ok: true }); }, 1500);
  });
}

function status() {
  return {
    running: !!srv,
    port,
    startedAt,
    clients: Array.from(clients.entries()).map(([t, c]) => ({
      token: t.substring(0, 6) + '…', user: c.user.name, ip: c.ip, at: new Date(c.at).toISOString(),
    })),
  };
}

/* ------------------------- جهة العميل (client) ------------------------- */
function normalizeUrl(url) {
  let u = String(url || '').trim();
  if (!u) throw new AppError('NO_SERVER', 'ما فيه عنوان للسيرفر، اضبطه من الإعدادات', 'Server address is not set');
  if (!/^https?:\/\//i.test(u)) u = 'http://' + u;
  return u.replace(/\/+$/, '');
}

async function remoteLogin(url, payload) {
  const base = normalizeUrl(url);
  const r = await fetch(base + '/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ ...payload, device: os.hostname() }),
    signal: AbortSignal.timeout(15000),
  }).catch((e) => { throw new AppError('NO_CONNECTION', 'ما قدرنا نتصل بالجهاز الرئيسي، تأكد إنه شغّال وعلى نفس الشبكة', 'Cannot reach the main device'); });
  const j = await r.json().catch(() => ({ ok: false, error: { code: 'BAD_RESPONSE', ar: 'رد غير مفهوم من السيرفر' } }));
  if (!j.ok) throw new AppError(j.error.code, j.error.ar, j.error.en);
  return j.data;
}

async function remoteCall(url, token, action, payload) {
  const base = normalizeUrl(url);
  const r = await fetch(base + '/api', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + token },
    body: JSON.stringify({ action, payload }),
    signal: AbortSignal.timeout(30000),
  }).catch(() => { throw new AppError('NO_CONNECTION', 'انقطع الاتصال بالجهاز الرئيسي', 'Connection to the main device lost'); });
  const j = await r.json().catch(() => ({ ok: false, error: { code: 'BAD_RESPONSE', ar: 'رد غير مفهوم من السيرفر' } }));
  if (!j.ok) throw new AppError(j.error.code, j.error.ar, j.error.en);
  return j.data;
}

async function ping(url) {
  const base = normalizeUrl(url);
  const r = await fetch(base + '/ping', { signal: AbortSignal.timeout(5000) })
    .catch(() => { throw new AppError('NO_CONNECTION', 'ما وصلنا للسيرفر', 'Cannot reach server'); });
  return r.json();
}

module.exports = { start, stop, status, localIPs, remoteLogin, remoteCall, ping };
