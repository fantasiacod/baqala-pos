'use strict';
/**
 * توليد رمز QR للفاتورة الضريبية المبسطة حسب متطلبات هيئة الزكاة والضريبة والجمارك
 * (المرحلة الأولى - الإصدار). الترميز TLV ثم Base64.
 *
 * الحقول الخمسة الإلزامية:
 *  1 اسم البائع
 *  2 الرقم الضريبي للبائع
 *  3 تاريخ ووقت الفاتورة (ISO 8601)
 *  4 إجمالي الفاتورة شامل الضريبة
 *  5 مبلغ ضريبة القيمة المضافة
 */
function tlv(tag, value) {
  const buf = Buffer.from(String(value), 'utf8');
  if (buf.length > 255) {
    const cut = buf.subarray(0, 255);
    return Buffer.concat([Buffer.from([tag, cut.length]), cut]);
  }
  return Buffer.concat([Buffer.from([tag, buf.length]), buf]);
}

/**
 * @param {object} p
 * @param {string} p.sellerName  اسم المنشأة
 * @param {string} p.vatNumber   الرقم الضريبي (15 رقم)
 * @param {string} p.timestamp   ISO datetime
 * @param {number} p.total       الإجمالي شامل الضريبة
 * @param {number} p.vat         مبلغ الضريبة
 * @returns {string} Base64
 */
function buildQR({ sellerName, vatNumber, timestamp, total, vat }) {
  const fmt = (n) => Number(n || 0).toFixed(2);
  const ts = (() => {
    const d = timestamp ? new Date(timestamp) : new Date();
    return isNaN(d.getTime()) ? new Date().toISOString() : d.toISOString();
  })();
  const payload = Buffer.concat([
    tlv(1, sellerName || ''),
    tlv(2, vatNumber || ''),
    tlv(3, ts),
    tlv(4, fmt(total)),
    tlv(5, fmt(vat)),
  ]);
  return payload.toString('base64');
}

/** التحقق من صيغة الرقم الضريبي السعودي: 15 رقم يبدأ وينتهي بـ 3 */
function validateVatNumber(v) {
  const s = String(v || '').replace(/\s/g, '');
  if (!s) return { valid: false, reason: 'EMPTY' };
  if (!/^\d{15}$/.test(s)) return { valid: false, reason: 'LENGTH' };
  if (!s.startsWith('3') || !s.endsWith('3')) return { valid: false, reason: 'FORMAT' };
  return { valid: true, value: s };
}

module.exports = { buildQR, validateVatNumber, tlv };
