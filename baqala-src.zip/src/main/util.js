'use strict';

/** التاريخ والوقت بتوقيت الجهاز */
function nowISO() { return new Date().toISOString(); }

/** اليوم بصيغة YYYY-MM-DD حسب التوقيت المحلي للجهاز */
function today(d) {
  const x = d ? new Date(d) : new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())}`;
}

function localStamp(d) {
  const x = d ? new Date(d) : new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${x.getFullYear()}-${p(x.getMonth() + 1)}-${p(x.getDate())} ${p(x.getHours())}:${p(x.getMinutes())}:${p(x.getSeconds())}`;
}

/** تقريب مالي دقيق - يتجنب أخطاء الفاصلة العائمة */
function money(n, decimals = 2) {
  const f = Math.pow(10, decimals);
  return Math.round((Number(n) + Number.EPSILON) * f) / f;
}

function num(v, def = 0) {
  const n = Number(v);
  return Number.isFinite(n) ? n : def;
}

function str(v, def = '') {
  if (v === null || v === undefined) return def;
  return String(v).trim();
}

function bool(v) {
  return v === true || v === 1 || v === '1' || v === 'true' ? 1 : 0;
}

class AppError extends Error {
  constructor(code, messageAr, messageEn) {
    super(messageAr || code);
    this.code = code;
    this.ar = messageAr || code;
    this.en = messageEn || messageAr || code;
  }
}

function fail(code, ar, en) { throw new AppError(code, ar, en); }

module.exports = { nowISO, today, localStamp, money, num, str, bool, AppError, fail };
