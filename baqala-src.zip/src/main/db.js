'use strict';
/**
 * طبقة قاعدة البيانات - SQLite
 * تعمل بدون أي مكتبات أصلية (WASM) لذلك تشتغل على أي جهاز ويندوز بدون مشاكل تثبيت.
 */
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { Database } = require('node-sqlite3-wasm');

let db = null;
let dbPath = null;

/* ------------------------------------------------------------------ */
/*  فتح القاعدة                                                        */
/* ------------------------------------------------------------------ */
function open(filePath) {
  dbPath = filePath;
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  db = new Database(filePath);
  db.exec('PRAGMA journal_mode = WAL');
  db.exec('PRAGMA foreign_keys = ON');
  migrate();
  return db;
}

function get() {
  if (!db) throw new Error('DB_NOT_OPEN');
  return db;
}

function close() {
  if (db) { try { db.close(); } catch (_) {} db = null; }
}

function getPath() { return dbPath; }

/* ------------------------------------------------------------------ */
/*  المخطط                                                             */
/* ------------------------------------------------------------------ */
const SCHEMA = `
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);

CREATE TABLE IF NOT EXISTS users (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  username    TEXT NOT NULL UNIQUE,
  name        TEXT NOT NULL,
  pass_hash   TEXT NOT NULL,
  salt        TEXT NOT NULL,
  role        TEXT NOT NULL DEFAULT 'cashier',   -- owner | manager | cashier
  permissions TEXT NOT NULL DEFAULT '[]',
  phone       TEXT,
  active      INTEGER NOT NULL DEFAULT 1,
  color       TEXT,
  created_at  TEXT NOT NULL,
  created_by  INTEGER,
  last_login  TEXT
);

CREATE TABLE IF NOT EXISTS categories (
  id      INTEGER PRIMARY KEY AUTOINCREMENT,
  name_ar TEXT NOT NULL,
  name_en TEXT,
  color   TEXT,
  sort    INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS products (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  barcode        TEXT UNIQUE,
  name_ar        TEXT NOT NULL,
  name_en        TEXT,
  category_id    INTEGER REFERENCES categories(id) ON DELETE SET NULL,
  unit           TEXT DEFAULT 'حبة',
  cost_price     REAL NOT NULL DEFAULT 0,
  sale_price     REAL NOT NULL DEFAULT 0,
  wholesale_price REAL DEFAULT 0,
  taxable        INTEGER NOT NULL DEFAULT 1,
  price_includes_tax INTEGER NOT NULL DEFAULT 1,
  track_stock    INTEGER NOT NULL DEFAULT 1,
  stock          REAL NOT NULL DEFAULT 0,
  min_stock      REAL NOT NULL DEFAULT 0,
  expiry_date    TEXT,
  supplier_id    INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
  note           TEXT,
  active         INTEGER NOT NULL DEFAULT 1,
  created_at     TEXT NOT NULL,
  updated_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_products_barcode ON products(barcode);
CREATE INDEX IF NOT EXISTS idx_products_name ON products(name_ar);
CREATE INDEX IF NOT EXISTS idx_products_cat ON products(category_id);

CREATE TABLE IF NOT EXISTS product_barcodes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  barcode    TEXT NOT NULL UNIQUE,
  pack_qty   REAL NOT NULL DEFAULT 1,
  price      REAL
);

CREATE TABLE IF NOT EXISTS suppliers (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  phone      TEXT,
  vat_number TEXT,
  address    TEXT,
  balance    REAL NOT NULL DEFAULT 0,   -- موجب = لنا عليه ، سالب = علينا له
  note       TEXT,
  active     INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS customers (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  phone       TEXT,
  vat_number  TEXT,
  address     TEXT,
  balance     REAL NOT NULL DEFAULT 0,  -- موجب = عليه دين لنا
  credit_limit REAL NOT NULL DEFAULT 0,
  note        TEXT,
  active      INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shifts (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id       INTEGER NOT NULL REFERENCES users(id),
  opened_at     TEXT NOT NULL,
  closed_at     TEXT,
  opening_cash  REAL NOT NULL DEFAULT 0,
  closing_cash  REAL,
  expected_cash REAL,
  difference    REAL,
  note          TEXT,
  status        TEXT NOT NULL DEFAULT 'open'  -- open | closed
);

CREATE TABLE IF NOT EXISTS sales (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no     TEXT NOT NULL UNIQUE,
  type           TEXT NOT NULL DEFAULT 'sale',  -- sale | return
  user_id        INTEGER NOT NULL REFERENCES users(id),
  shift_id       INTEGER REFERENCES shifts(id),
  customer_id    INTEGER REFERENCES customers(id) ON DELETE SET NULL,
  created_at     TEXT NOT NULL,
  day            TEXT NOT NULL,
  subtotal       REAL NOT NULL DEFAULT 0,  -- قبل الخصم وبدون ضريبة
  discount       REAL NOT NULL DEFAULT 0,
  taxable_amount REAL NOT NULL DEFAULT 0,
  tax_amount     REAL NOT NULL DEFAULT 0,
  total          REAL NOT NULL DEFAULT 0,
  cost_total     REAL NOT NULL DEFAULT 0,
  profit         REAL NOT NULL DEFAULT 0,
  paid           REAL NOT NULL DEFAULT 0,
  change_due     REAL NOT NULL DEFAULT 0,
  payment_method TEXT NOT NULL DEFAULT 'cash', -- cash | card | credit | mixed
  cash_amount    REAL NOT NULL DEFAULT 0,
  card_amount    REAL NOT NULL DEFAULT 0,
  credit_amount  REAL NOT NULL DEFAULT 0,
  tax_enabled    INTEGER NOT NULL DEFAULT 1,
  tax_rate       REAL NOT NULL DEFAULT 15,
  status         TEXT NOT NULL DEFAULT 'completed', -- completed | void
  void_reason    TEXT,
  void_by        INTEGER,
  void_at        TEXT,
  ref_sale_id    INTEGER,
  note           TEXT
);
CREATE INDEX IF NOT EXISTS idx_sales_day ON sales(day);
CREATE INDEX IF NOT EXISTS idx_sales_user ON sales(user_id);
CREATE INDEX IF NOT EXISTS idx_sales_created ON sales(created_at);

CREATE TABLE IF NOT EXISTS sale_items (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  sale_id    INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE,
  product_id INTEGER REFERENCES products(id) ON DELETE SET NULL,
  name       TEXT NOT NULL,
  barcode    TEXT,
  unit       TEXT,
  qty        REAL NOT NULL,
  unit_price REAL NOT NULL,       -- السعر بدون ضريبة
  cost_price REAL NOT NULL DEFAULT 0,
  discount   REAL NOT NULL DEFAULT 0,
  tax_rate   REAL NOT NULL DEFAULT 0,
  tax_amount REAL NOT NULL DEFAULT 0,
  line_total REAL NOT NULL        -- شامل الضريبة بعد الخصم
);
CREATE INDEX IF NOT EXISTS idx_saleitems_sale ON sale_items(sale_id);
CREATE INDEX IF NOT EXISTS idx_saleitems_product ON sale_items(product_id);

CREATE TABLE IF NOT EXISTS purchases (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  invoice_no   TEXT NOT NULL,
  supplier_id  INTEGER REFERENCES suppliers(id) ON DELETE SET NULL,
  user_id      INTEGER NOT NULL REFERENCES users(id),
  created_at   TEXT NOT NULL,
  day          TEXT NOT NULL,
  subtotal     REAL NOT NULL DEFAULT 0,
  discount     REAL NOT NULL DEFAULT 0,
  tax_amount   REAL NOT NULL DEFAULT 0,
  total        REAL NOT NULL DEFAULT 0,
  paid         REAL NOT NULL DEFAULT 0,
  due_date     TEXT,
  status       TEXT NOT NULL DEFAULT 'completed',
  note         TEXT
);
CREATE INDEX IF NOT EXISTS idx_purchases_day ON purchases(day);

CREATE TABLE IF NOT EXISTS purchase_items (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  purchase_id INTEGER NOT NULL REFERENCES purchases(id) ON DELETE CASCADE,
  product_id  INTEGER REFERENCES products(id) ON DELETE SET NULL,
  name        TEXT NOT NULL,
  qty         REAL NOT NULL,
  cost_price  REAL NOT NULL,
  sale_price  REAL,
  expiry_date TEXT,
  line_total  REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS payments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  party_type TEXT NOT NULL,     -- customer | supplier
  party_id   INTEGER NOT NULL,
  direction  TEXT NOT NULL,     -- in (قبض) | out (صرف)
  amount     REAL NOT NULL,
  method     TEXT NOT NULL DEFAULT 'cash',
  user_id    INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL,
  day        TEXT NOT NULL,
  ref_type   TEXT,
  ref_id     INTEGER,
  note       TEXT
);
CREATE INDEX IF NOT EXISTS idx_payments_party ON payments(party_type, party_id);

CREATE TABLE IF NOT EXISTS stock_moves (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  product_id    INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  qty_change    REAL NOT NULL,
  balance_after REAL NOT NULL,
  reason        TEXT NOT NULL,  -- sale | return | purchase | adjust | damage | open
  ref_type      TEXT,
  ref_id        INTEGER,
  user_id       INTEGER REFERENCES users(id),
  created_at    TEXT NOT NULL,
  note          TEXT
);
CREATE INDEX IF NOT EXISTS idx_moves_product ON stock_moves(product_id);

CREATE TABLE IF NOT EXISTS expenses (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  category   TEXT NOT NULL,
  amount     REAL NOT NULL,
  note       TEXT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  shift_id   INTEGER,
  created_at TEXT NOT NULL,
  day        TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_expenses_day ON expenses(day);

CREATE TABLE IF NOT EXISTS cash_moves (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  shift_id   INTEGER REFERENCES shifts(id),
  type       TEXT NOT NULL,   -- in | out
  amount     REAL NOT NULL,
  reason     TEXT,
  user_id    INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS activity_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER,
  username   TEXT,
  user_name  TEXT,
  action     TEXT NOT NULL,
  entity     TEXT,
  entity_id  INTEGER,
  details    TEXT,
  amount     REAL,
  created_at TEXT NOT NULL,
  day        TEXT NOT NULL,
  device     TEXT
);
CREATE INDEX IF NOT EXISTS idx_log_day ON activity_log(day);
CREATE INDEX IF NOT EXISTS idx_log_user ON activity_log(user_id);

CREATE TABLE IF NOT EXISTS counters (
  name  TEXT PRIMARY KEY,
  value INTEGER NOT NULL DEFAULT 0
);
`;

/* ------------------------------------------------------------------ */
/*  الإعدادات الافتراضية                                               */
/* ------------------------------------------------------------------ */
const DEFAULT_SETTINGS = {
  // بيانات المنشأة
  store_name: 'بقالة',
  store_name_en: 'Grocery Store',
  vat_number: '',
  cr_number: '',          // السجل التجاري: 12 رقم
  tax_register: '',       // السجل الضريبي: 20 رقم (يُطلب عند تجاوز الدخل أو تعدد الفروع)
  branches_count: '1',
  address: '',
  phone: '',
  logo: '',
  cr_image: '',           // صورة السجل التجاري (تُعرض في صفحة النماذج)
  tax_image: '',          // صورة السجل الضريبي (اختيارية)

  // الضريبة
  tax_enabled: '0',
  tax_rate: '15',
  prices_include_tax: '1',

  // العملة والأرقام — الرمز الافتراضي هو رمز الريال السعودي الجديد (يونيكود U+20C0)
  currency: 'SAR',
  currency_ar: '⃀',
  currency_en: '⃀',
  decimals: '2',

  // الواجهة
  lang: 'ar',
  theme: 'light',
  accent: '#0f9d58',
  accent2: '#1a73e8',
  font_family: 'Cairo',
  font_scale: '100',
  radius: '14',
  density: 'normal',

  // الفاتورة
  receipt_width: '80',        // 80 ملم أو 58
  receipt_footer: 'شكراً لزيارتكم',
  receipt_show_logo: '1',
  receipt_show_qr: '1',            // رمز هيئة الزكاة والضريبة (عند تفعيل الضريبة)
  receipt_show_verify_qr: '1',     // رمز التحقق من صحة الفاتورة (يظهر دائماً)
  verify_key: '',                  // مفتاح توقيع رمز التحقق — سري ولا يخرج للواجهة
  print_auto: '1',

  // التنبيهات
  low_stock_alert: '1',
  expiry_alert_days: '30',
  negative_stock: '0',

  // المتنوعة
  invoice_prefix: 'INV-',
  purchase_prefix: 'PUR-',
  backup_auto: '1',
  backup_keep: '20',
  setup_done: '0',

  // أرشفة سجل النشاط (حتى لا تكبر قاعدة البيانات)
  log_auto_purge: '1',
  log_keep_days: '7',
  last_log_purge: '',

  // ترقيات تُنفَّذ مرة واحدة
  currency_symbol_v2: '0',
};

const DEFAULT_CATEGORIES = [
  ['مواد غذائية', 'Food', '#f4b400'],
  ['مشروبات', 'Beverages', '#1a73e8'],
  ['ألبان وأجبان', 'Dairy', '#34a853'],
  ['معلبات', 'Canned', '#ea4335'],
  ['منظفات', 'Cleaning', '#9c27b0'],
  ['حلويات وشيبس', 'Snacks', '#ff7043'],
  ['خبز ومعجنات', 'Bakery', '#795548'],
  ['خضار وفواكه', 'Produce', '#0f9d58'],
  ['أدوات منزلية', 'Household', '#607d8b'],
  ['متفرقات', 'Other', '#9e9e9e'],
];

/* ------------------------------------------------------------------ */
/*  الهجرة والتهيئة                                                    */
/* ------------------------------------------------------------------ */
function migrate() {
  db.exec(SCHEMA);

  // الإعدادات الافتراضية
  const now = new Date().toISOString();
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) {
    db.run('INSERT OR IGNORE INTO settings(key,value) VALUES (?,?)', [k, v]);
  }

  // مفتاح توقيع رمز التحقق من الفواتير — يُولَّد مرة واحدة لكل محل
  const vk = db.get('SELECT value FROM settings WHERE key=?', ['verify_key']);
  if (!vk || !String(vk.value || '').trim()) {
    db.run('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
      ['verify_key', require('./verify').newKey()]);
  }

  // ترقية رمز العملة إلى رمز الريال السعودي الجديد (مرة واحدة، ولا تمس الرمز المخصص)
  const curDone = db.get('SELECT value FROM settings WHERE key=?', ['currency_symbol_v2']);
  if (!curDone || curDone.value !== '1') {
    const OLD_AR = ['ر.س', 'ر.س.', 'ريال', 'SR', 'SAR'];
    const OLD_EN = ['SAR', 'SR', 'ر.س'];
    const curAr = db.get('SELECT value FROM settings WHERE key=?', ['currency_ar']);
    const curEn = db.get('SELECT value FROM settings WHERE key=?', ['currency_en']);
    if (curAr && OLD_AR.includes(String(curAr.value).trim())) {
      db.run('UPDATE settings SET value=? WHERE key=?', ['⃀', 'currency_ar']);
    }
    if (curEn && OLD_EN.includes(String(curEn.value).trim())) {
      db.run('UPDATE settings SET value=? WHERE key=?', ['⃀', 'currency_en']);
    }
    db.run('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
      ['currency_symbol_v2', '1']);
  }

  // العدادات
  db.run("INSERT OR IGNORE INTO counters(name,value) VALUES ('sale',0)");
  db.run("INSERT OR IGNORE INTO counters(name,value) VALUES ('purchase',0)");

  // التصنيفات الافتراضية
  const catCount = db.get('SELECT COUNT(*) c FROM categories').c;
  if (!catCount) {
    DEFAULT_CATEGORIES.forEach(([ar, en, color], i) => {
      db.run('INSERT INTO categories(name_ar,name_en,color,sort) VALUES (?,?,?,?)', [ar, en, color, i]);
    });
  }

  // مالك افتراضي
  const userCount = db.get('SELECT COUNT(*) c FROM users').c;
  if (!userCount) {
    const { hash, salt } = hashPassword('1234');
    db.run(
      `INSERT INTO users(username,name,pass_hash,salt,role,permissions,active,created_at,color)
       VALUES (?,?,?,?,?,?,1,?,?)`,
      ['admin', 'صاحب البقالة', hash, salt, 'owner', JSON.stringify(ALL_PERMISSIONS), now, '#0f9d58']
    );
  }
}

/* ------------------------------------------------------------------ */
/*  الصلاحيات                                                          */
/* ------------------------------------------------------------------ */
const ALL_PERMISSIONS = [
  'pos',              // شاشة البيع
  'sale_discount',    // إعطاء خصم
  'sale_return',      // إرجاع
  'sale_void',        // إلغاء فاتورة
  'sale_credit',      // بيع آجل
  'sales_view',       // عرض الفواتير
  'products_view',
  'products_edit',
  'inventory',        // الجرد والتعديل على الكميات
  'purchases',
  'suppliers',
  'customers',
  'debts',
  'expenses',
  'reports',
  'dashboard',
  'users',
  'settings',
  'backup',
  'activity_log',
];

const ROLE_PRESETS = {
  owner: ALL_PERMISSIONS.slice(),
  manager: ALL_PERMISSIONS.filter((p) => !['users', 'settings', 'backup'].includes(p)),
  cashier: ['pos', 'sales_view', 'products_view', 'customers'],
};

/* ------------------------------------------------------------------ */
/*  كلمات المرور                                                       */
/* ------------------------------------------------------------------ */
function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 32).toString('hex');
  return { hash, salt };
}

function verifyPassword(password, salt, expected) {
  try {
    const { hash } = hashPassword(password, salt);
    const a = Buffer.from(hash, 'hex');
    const b = Buffer.from(expected, 'hex');
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  } catch (_) { return false; }
}

/* ------------------------------------------------------------------ */
/*  مساعدات                                                            */
/* ------------------------------------------------------------------ */
function tx(fn) {
  const d = get();
  d.exec('BEGIN');
  try {
    const out = fn(d);
    d.exec('COMMIT');
    return out;
  } catch (e) {
    try { d.exec('ROLLBACK'); } catch (_) {}
    throw e;
  }
}

function nextCounter(name) {
  const d = get();
  d.run('UPDATE counters SET value = value + 1 WHERE name = ?', [name]);
  const row = d.get('SELECT value FROM counters WHERE name = ?', [name]);
  return row ? row.value : 1;
}

function settingsAll() {
  const rows = get().all('SELECT key,value FROM settings');
  const o = {};
  rows.forEach((r) => { o[r.key] = r.value; });
  return o;
}

function setSetting(key, value) {
  get().run('INSERT INTO settings(key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',
    [key, String(value)]);
}

function getSetting(key, def) {
  const r = get().get('SELECT value FROM settings WHERE key=?', [key]);
  return r ? r.value : def;
}

module.exports = {
  open, get, close, getPath, tx, migrate,
  hashPassword, verifyPassword,
  nextCounter, settingsAll, setSetting, getSetting,
  ALL_PERMISSIONS, ROLE_PRESETS, DEFAULT_SETTINGS,
};
