'use strict';
/**
 * موجّه الطلبات المركزي.
 * تمر عليه كل الطلبات سواء من الواجهة مباشرة (IPC) أو من كاشير ثاني على الشبكة (HTTP).
 * وبهذا تكون قواعد الصلاحيات والتحقق موحّدة مهما كان مصدر الطلب.
 */
const db = require('./db');
const users = require('./repo/users');
const products = require('./repo/products');
const sales = require('./repo/sales');
const purchases = require('./repo/purchases');
const parties = require('./repo/parties');
const shifts = require('./repo/shifts');
const reports = require('./repo/reports');
const settingsRepo = require('./repo/settings');
const audit = require('./repo/audit');
const zatca = require('./zatca');
const verify = require('./verify');
const { AppError, num, str } = require('./util');

/** action -> الصلاحية المطلوبة (null = يكفي تسجيل الدخول) */
const PERMS = {
  'pos.scan': 'pos',
  'pos.preview': 'pos',
  'sales.create': 'pos',
  'sales.void': 'sale_void',
  'sales.list': 'sales_view',
  'sales.get': 'sales_view',
  'sales.last': 'pos',

  'products.list': 'products_view',
  'products.get': 'products_view',
  'products.save': 'products_edit',
  'products.delete': 'products_edit',
  'products.import': 'products_edit',
  'products.export': 'products_view',
  'products.alerts': null,
  'products.moves': 'inventory',
  'products.adjust': 'inventory',
  'categories.list': null,
  'categories.save': 'products_edit',
  'categories.delete': 'products_edit',

  'purchases.create': 'purchases',
  'purchases.list': 'purchases',
  'purchases.get': 'purchases',
  'purchases.pay': 'purchases',
  'purchases.delete': 'purchases',

  'parties.list': null,
  'parties.get': null,
  'parties.save': null,
  'parties.delete': null,
  'parties.pay': 'debts',
  'parties.payments': 'debts',
  'parties.statement': 'debts',
  'parties.debtSummary': 'debts',

  'shifts.current': null,
  'shifts.open': 'pos',
  'shifts.close': 'pos',
  'shifts.summary': 'pos',
  'shifts.list': 'reports',
  'shifts.cashMove': 'pos',
  'expenses.add': 'expenses',
  'expenses.list': 'expenses',
  'expenses.delete': 'expenses',

  'reports.dashboard': 'dashboard',
  'reports.sales': 'reports',
  'reports.products': 'reports',
  'reports.inventory': 'reports',
  'reports.vat': 'reports',
  'reports.profitLoss': 'reports',
  'reports.period': 'reports',

  'users.list': 'users',
  'users.create': 'users',
  'users.update': 'users',
  'users.delete': 'users',
  'users.verifyManager': null,
  'users.changeOwnPassword': null,

  'activity.list': 'activity_log',
  'activity.staffDay': 'dashboard',
  'activity.recent': 'dashboard',
  'activity.stats': 'activity_log',
  'activity.archive': 'settings',
  'activity.archives': 'activity_log',

  'settings.get': null,
  'settings.update': 'settings',
  'settings.setTax': 'settings',
  'settings.backup': 'backup',
  'settings.backups': 'backup',
  'settings.restore': 'backup',
  'settings.reset': 'settings',
  'settings.permissions': null,
  'settings.compliance': null,
  'settings.doc': null,
  'settings.setDoc': 'settings',

  'invoice.qr': null,
  'invoice.verifyCode': null,
  'invoice.check': 'sales_view',
};

const HANDLERS = {
  /* ------------------------------ الكاشير ------------------------------ */
  'pos.scan': (ctx, p) => {
    const found = products.findByBarcode(p.code);
    if (found) return found;
    const list = products.list({ q: p.code, limit: 20 });
    return { product: null, suggestions: list.rows };
  },
  'pos.preview': (ctx, p) => sales.preview(p),
  'sales.create': (ctx, p) => {
    if (!users.can(ctx.user, 'sale_discount') && (num(p.discountAmount) > 0 || num(p.discountPercent) > 0))
      throw new AppError('FORBIDDEN', 'ما عندك صلاحية إعطاء خصم', 'You are not allowed to give discounts');
    if (p.type === 'return' && !users.can(ctx.user, 'sale_return'))
      throw new AppError('FORBIDDEN', 'ما عندك صلاحية الإرجاع', 'You are not allowed to process returns');
    if ((p.payment_method === 'credit' || num(p.credit) > 0) && !users.can(ctx.user, 'sale_credit'))
      throw new AppError('FORBIDDEN', 'ما عندك صلاحية البيع الآجل', 'You are not allowed to sell on credit');
    return sales.create(ctx, p);
  },
  'sales.void': (ctx, p) => sales.voidSale(ctx, p),
  'sales.list': (ctx, p) => {
    // الكاشير يشوف فواتيره فقط ما لم يكن عنده صلاحية التقارير
    if (!users.can(ctx.user, 'reports') && ctx.user.role === 'cashier') p = { ...p, userId: ctx.user.id };
    return sales.list(p);
  },
  'sales.get': (ctx, p) => sales.byId(p.id),
  'sales.last': (ctx) => sales.lastForUser(ctx.user.id),

  /* ------------------------------ الأصناف ------------------------------ */
  'products.list': (ctx, p) => products.list(p),
  'products.get': (ctx, p) => products.byId(p.id),
  'products.save': (ctx, p) => products.save(ctx, p),
  'products.delete': (ctx, p) => products.remove(ctx, p.id),
  'products.import': (ctx, p) => products.importRows(ctx, p.rows || []),
  'products.export': () => products.exportAll(),
  'products.alerts': () => products.alerts(),
  'products.moves': (ctx, p) => products.moves(p.productId, p.limit),
  'products.adjust': (ctx, p) => products.adjustStock(ctx, p),
  'categories.list': () => products.categories(),
  'categories.save': (ctx, p) => products.saveCategory(ctx, p),
  'categories.delete': (ctx, p) => products.deleteCategory(ctx, p.id),

  /* ----------------------------- المشتريات ----------------------------- */
  'purchases.create': (ctx, p) => purchases.create(ctx, p),
  'purchases.list': (ctx, p) => purchases.list(p),
  'purchases.get': (ctx, p) => purchases.byId(p.id),
  'purchases.pay': (ctx, p) => purchases.payInvoice(ctx, p),
  'purchases.delete': (ctx, p) => purchases.remove(ctx, p.id),

  /* ------------------------- العملاء والموردين ------------------------- */
  'parties.list': (ctx, p) => parties.list(p.type, p),
  'parties.get': (ctx, p) => parties.byId(p.type, p.id),
  'parties.save': (ctx, p) => {
    const perm = p.type === 'supplier' ? 'suppliers' : 'customers';
    if (!users.can(ctx.user, perm)) throw new AppError('FORBIDDEN', 'ما عندك صلاحية لهذه العملية', 'Not allowed');
    return parties.save(ctx, p.type, p);
  },
  'parties.delete': (ctx, p) => {
    const perm = p.type === 'supplier' ? 'suppliers' : 'customers';
    if (!users.can(ctx.user, perm)) throw new AppError('FORBIDDEN', 'ما عندك صلاحية لهذه العملية', 'Not allowed');
    return parties.remove(ctx, p.type, p.id);
  },
  'parties.pay': (ctx, p) => parties.pay(ctx, { partyType: p.type, partyId: p.id, ...p }),
  'parties.payments': (ctx, p) => parties.payments(p.type, p.id, p.limit),
  'parties.statement': (ctx, p) => parties.statement(p.type, p.id, p),
  'parties.debtSummary': () => parties.debtSummary(),

  /* ------------------------------ الورديات ----------------------------- */
  'shifts.current': (ctx) => shifts.current(ctx.user.id) || null,
  'shifts.open': (ctx, p) => shifts.open(ctx, p),
  'shifts.close': (ctx, p) => shifts.close(ctx, p),
  'shifts.summary': (ctx, p) => shifts.summary(p.shiftId || (shifts.current(ctx.user.id) || {}).id),
  'shifts.list': (ctx, p) => shifts.list(p),
  'shifts.cashMove': (ctx, p) => shifts.cashMove(ctx, p),
  'expenses.add': (ctx, p) => shifts.addExpense(ctx, p),
  'expenses.list': (ctx, p) => shifts.listExpenses(p),
  'expenses.delete': (ctx, p) => shifts.deleteExpense(ctx, p.id),

  /* ------------------------------ التقارير ----------------------------- */
  'reports.dashboard': (ctx, p) => reports.dashboard(p),
  'reports.sales': (ctx, p) => reports.sales(p),
  'reports.products': (ctx, p) => reports.productsReport(p),
  'reports.inventory': (ctx, p) => reports.inventory(p),
  'reports.vat': (ctx, p) => reports.vat(p),
  'reports.profitLoss': (ctx, p) => reports.profitLoss(p),
  'reports.period': (ctx, p) => reports.periodStats(p.from, p.to),

  /* ----------------------------- المستخدمون ---------------------------- */
  'users.list': () => users.list(),
  'users.create': (ctx, p) => users.create(ctx, p),
  'users.update': (ctx, p) => users.update(ctx, p),
  'users.delete': (ctx, p) => users.remove(ctx, p.id),
  'users.verifyManager': (ctx, p) => users.verifyManager(p),
  'users.changeOwnPassword': (ctx, p) => users.changeOwnPassword(ctx, p),

  /* ------------------------------ السجل ------------------------------- */
  'activity.list': (ctx, p) => audit.list(p),
  'activity.staffDay': (ctx, p) => audit.staffDay(p.day),
  'activity.recent': (ctx, p) => audit.recent(p.limit),
  'activity.stats': () => audit.stats(),
  'activity.archive': (ctx, p) => audit.archiveAndPurge(ctx, p),
  'activity.archives': () => audit.archives(),

  /* ----------------------------- الإعدادات ----------------------------- */
  'settings.get': () => settingsRepo.all(),
  'settings.update': (ctx, p) => settingsRepo.update(ctx, p),
  'settings.setTax': (ctx, p) => settingsRepo.setTax(ctx, p),
  'settings.backup': (ctx, p) => settingsRepo.backup(ctx, p && p.path),
  'settings.backups': () => settingsRepo.listBackups(),
  'settings.restore': (ctx, p) => settingsRepo.restore(ctx, p.path),
  'settings.reset': (ctx, p) => settingsRepo.resetTransactions(ctx, p),
  'settings.permissions': () => ({ all: db.ALL_PERMISSIONS, presets: db.ROLE_PRESETS }),
  'settings.compliance': () => settingsRepo.compliance(),
  'settings.doc': (ctx, p) => settingsRepo.getDoc(p.kind),
  'settings.setDoc': (ctx, p) => settingsRepo.setDoc(ctx, p),

  /* ------------------------------ الفاتورة ----------------------------- */

  /** نص رمز التحقق الذي يُطبع كـ QR على الفاتورة */
  'invoice.verifyCode': (ctx, p) => {
    const s = db.settingsAll();
    const sale = {
      invoice_no: str(p.invoice_no),
      created_at: p.created_at,
      total: num(p.total, 0),
    };
    const r = verify.buildText(s, sale, s.verify_key);
    return { text: r.text, code: r.code };
  },

  /** التحقق من نص رمز ممسوح: التوقيع + مطابقته للفاتورة المحفوظة */
  'invoice.check': (ctx, p) => {
    const s = db.settingsAll();
    const res = verify.check(p.text, s.verify_key);
    const out = { ok: res.ok, reason: res.reason, parsed: res.parsed, sale: null, matches: null };
    if (!res.parsed || !res.parsed.invoice) return out;

    const row = db.get().get('SELECT * FROM sales WHERE invoice_no=?', [res.parsed.invoice]);
    if (row) {
      out.sale = {
        id: row.id, invoice_no: row.invoice_no, total: row.total, status: row.status,
        type: row.type, created_at: row.created_at, user_id: row.user_id,
      };
      out.matches = Math.abs(num(row.total, 0) - num(res.parsed.total, -1)) < 0.005;
    }
    return out;
  },

  'invoice.qr': (ctx, p) => {
    const s = db.settingsAll();
    return {
      qr: zatca.buildQR({
        sellerName: s.store_name,
        vatNumber: s.vat_number,
        timestamp: p.timestamp,
        total: p.total,
        vat: p.vat,
      }),
    };
  },
};

/**
 * @param {string} action
 * @param {object} payload
 * @param {object} ctx {user, device}
 */
function handle(action, payload, ctx) {
  const fn = HANDLERS[action];
  if (!fn) throw new AppError('UNKNOWN_ACTION', `عملية غير معروفة: ${action}`, `Unknown action: ${action}`);
  if (!ctx || !ctx.user) throw new AppError('UNAUTHENTICATED', 'لازم تسجل دخول أولاً', 'Please sign in first');
  const perm = PERMS[action];
  if (perm && !users.can(ctx.user, perm)) {
    throw new AppError('FORBIDDEN', 'ما عندك صلاحية لهذه العملية، راجع صاحب المحل', 'You do not have permission for this action');
  }
  return fn(ctx, payload || {});
}

module.exports = { handle, PERMS, HANDLERS };
