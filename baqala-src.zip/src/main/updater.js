'use strict';
/**
 * التحديث التلقائي.
 * يعتمد على electron-updater: البرنامج يسأل سيرفر التحديثات عن آخر إصدار،
 * وإذا لقى إصدار أحدث يعرض للمستخدم شاشة التحديث ثم ينزّله ويثبّته.
 *
 * السيرفر مجرد مجلد على أي استضافة ويب فيه:
 *   latest.yml                      (ينتجه البناء تلقائياً)
 *   BaqalaPOS-Setup-x.y.z.exe
 *   BaqalaPOS-Setup-x.y.z.exe.blockmap
 */
let autoUpdater = null;
try { ({ autoUpdater } = require('electron-updater')); } catch (_) { /* غير مثبّت */ }

let win = null;
let cfg = null;
let state = { status: 'idle', info: null, progress: null, error: null };
let timer = null;

function send(payload) {
  state = { ...state, ...payload };
  try { if (win && !win.isDestroyed()) win.webContents.send('update:event', state); } catch (_) {}
}

function normalizeUrl(u) {
  let s = String(u || '').trim();
  if (!s) return '';
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  return s.replace(/\/+$/, '') + '/';
}

function available() {
  return !!(autoUpdater && cfg && normalizeUrl(cfg.updateUrl));
}

function init(mainWindow, config, { isPackaged }) {
  win = mainWindow;
  cfg = config;
  if (!autoUpdater) return;

  autoUpdater.autoDownload = false;            // ما ننزّل إلا بموافقة المستخدم
  autoUpdater.autoInstallOnAppQuit = true;
  autoUpdater.allowDowngrade = false;
  autoUpdater.logger = null;
  // للتجربة على جهاز التطوير
  if (!isPackaged) autoUpdater.forceDevUpdateConfig = true;

  autoUpdater.on('checking-for-update', () => send({ status: 'checking', error: null }));
  autoUpdater.on('update-available', (info) => send({
    status: 'available', error: null,
    info: { version: info.version, notes: cleanNotes(info.releaseNotes), date: info.releaseDate, size: sizeOf(info) },
  }));
  autoUpdater.on('update-not-available', (info) => send({
    status: 'none', error: null, info: { version: info && info.version },
  }));
  autoUpdater.on('download-progress', (p) => send({
    status: 'downloading',
    progress: { percent: Math.round(p.percent), transferred: p.transferred, total: p.total, speed: p.bytesPerSecond },
  }));
  autoUpdater.on('update-downloaded', (info) => send({
    status: 'downloaded', progress: { percent: 100 },
    info: { version: info.version, notes: cleanNotes(info.releaseNotes) },
  }));
  autoUpdater.on('error', (e) => send({
    status: 'error',
    error: friendlyError(e && e.message ? e.message : String(e)),
  }));
}

function cleanNotes(notes) {
  if (!notes) return '';
  if (typeof notes === 'string') return notes.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 1200);
  if (Array.isArray(notes)) return notes.map((n) => cleanNotes(n && n.note)).filter(Boolean).join('\n').slice(0, 1200);
  return '';
}

function sizeOf(info) {
  try {
    const f = (info.files || [])[0];
    return f && f.size ? f.size : null;
  } catch (_) { return null; }
}

function friendlyError(msg) {
  const m = String(msg);
  if (/ENOTFOUND|EAI_AGAIN|ETIMEDOUT|ECONNREFUSED|net::/i.test(m)) return 'ما قدرنا نوصل لسيرفر التحديثات — تأكد من الإنترنت ومن العنوان في الإعدادات';
  if (/404/.test(m)) return 'ما لقينا ملف التحديثات على العنوان المكتوب (latest.yml مفقود)';
  if (/403|401/.test(m)) return 'السيرفر رفض الطلب — تأكد أن الملفات متاحة للتحميل العام';
  if (/not signed|signature/i.test(m)) return 'ملف التحديث غير موقّع بنفس شهادة البرنامج';
  return m.slice(0, 300);
}

/** فحص يدوي أو تلقائي */
async function check({ silent = false } = {}) {
  if (!autoUpdater) { send({ status: 'error', error: 'وحدة التحديث غير متوفرة في هذه النسخة' }); return state; }
  const url = normalizeUrl(cfg && cfg.updateUrl);
  if (!url) {
    if (!silent) send({ status: 'unset', error: null });
    return state;
  }
  let to = null;
  try {
    autoUpdater.setFeedURL({ provider: 'generic', url });
    // لو تعلّق الاتصال ما نخلي الشاشة تدور للأبد
    await Promise.race([
      autoUpdater.checkForUpdates(),
      new Promise((_, rej) => { to = setTimeout(() => rej(new Error('ETIMEDOUT')), 30000); }),
    ]);
  } catch (e) {
    if (state.status !== 'available' && state.status !== 'downloaded') {
      send({ status: 'error', error: friendlyError(e && e.message) });
    }
  } finally {
    clearTimeout(to);
  }
  return state;
}

async function download() {
  if (!autoUpdater) return state;
  try {
    send({ status: 'downloading', progress: { percent: 0 } });
    await autoUpdater.downloadUpdate();
  } catch (e) {
    send({ status: 'error', error: friendlyError(e && e.message) });
  }
  return state;
}

function install() {
  if (!autoUpdater) return { ok: false };
  setImmediate(() => autoUpdater.quitAndInstall(false, true));
  return { ok: true };
}

/**
 * الفحص التلقائي — زي أي برنامج متطور:
 * بعد ما يفتح البرنامج بـ ٢٠ ثانية، ثم كل ٤ ساعات،
 * وكمان كل ما رجع المستخدم للبرنامج إذا صار أكثر من ساعتين على آخر فحص.
 */
let lastCheckAt = 0;
let interval = null;

async function autoCheck() {
  lastCheckAt = Date.now();
  return check({ silent: true });
}

function startAutoCheck() {
  clearTimeout(timer);
  if (interval) { clearInterval(interval); interval = null; }
  if (!available()) return;
  if (cfg.autoUpdate === false) return;
  timer = setTimeout(autoCheck, 20 * 1000);
  interval = setInterval(autoCheck, 4 * 60 * 60 * 1000);
}

/** يُستدعى لما ترجع نافذة البرنامج للواجهة */
function checkOnFocus() {
  if (!available() || (cfg && cfg.autoUpdate === false)) return;
  if (state.status === 'downloading' || state.status === 'downloaded') return;
  if (Date.now() - lastCheckAt < 2 * 60 * 60 * 1000) return;
  autoCheck();
}

function stop() { clearTimeout(timer); if (interval) clearInterval(interval); }
function current() { return state; }

module.exports = { init, check, download, install, startAutoCheck, checkOnFocus, stop, current, available, normalizeUrl };
